import type { LucideIcon } from "lucide-react";
import { CountUp } from "@/components/ui/count-up";
import { cn } from "@/lib/utils";

export function MetricCard({
  label,
  value,
  icon: Icon,
  hint,
  tone = "neutral",
}: {
  label: string;
  value: number | string;
  icon: LucideIcon;
  hint?: string;
  tone?: "neutral" | "lime" | "danger" | "cyan";
}) {
  return (
    <div className="card relative overflow-hidden p-5">
      <div className="flex items-center justify-between">
        <p className="text-sm text-fg-muted">{label}</p>
        <span
          className={cn(
            "grid size-8 place-items-center rounded-lg border",
            tone === "lime" && "border-lime/30 bg-lime/10 text-lime",
            tone === "danger" && "border-danger/30 bg-danger/10 text-danger",
            tone === "cyan" && "border-cyan/30 bg-cyan/10 text-cyan",
            tone === "neutral" && "border-line-strong text-fg-muted",
          )}
        >
          <Icon className="size-4" aria-hidden />
        </span>
      </div>
      <p className="mt-4 text-3xl font-semibold tracking-tight tabular-nums">
        <CountUp value={String(value)} />
      </p>
      {hint ? <p className="mt-1 text-xs text-fg-subtle">{hint}</p> : null}
    </div>
  );
}
