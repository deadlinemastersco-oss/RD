"use client";

import Link from "next/link";
import { useEffect, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { Bell, CheckCheck, FolderKanban, Inbox, Info } from "lucide-react";
import { markAllNotificationsRead, markNotificationRead } from "@/lib/actions/dashboard";
import type { NotificationRow } from "@/lib/types/database";
import { cn, relativeTime } from "@/lib/utils";

const typeIcon = { inquiry: Inbox, task: FolderKanban } as const;

/** Bell + dropdown notification center in the dashboard top bar. */
export function NotificationCenter({ items }: { items: NotificationRow[] }) {
  const [open, setOpen] = useState(false);
  const [pending, start] = useTransition();
  const router = useRouter();
  const ref = useRef<HTMLDivElement>(null);
  const unread = items.filter((n) => !n.is_read).length;
  const [now] = useState(() => Date.now());

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  function openItem(n: NotificationRow) {
    setOpen(false);
    start(async () => {
      if (!n.is_read) await markNotificationRead(n.id);
      if (n.link?.startsWith("/")) router.push(n.link);
      else router.refresh();
    });
  }

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="relative grid size-9 place-items-center rounded-lg border border-line-strong text-fg-muted transition-colors hover:text-fg"
        aria-label={unread ? `Notifications, ${unread} unread` : "Notifications"}
        aria-expanded={open}
        aria-haspopup="dialog"
      >
        <Bell className="size-4" aria-hidden />
        {unread ? (
          <span className="absolute -top-1 -right-1 grid min-w-4 place-items-center rounded-full bg-lime px-1 font-mono text-[0.6rem] font-semibold text-ink">
            {unread > 9 ? "9+" : unread}
          </span>
        ) : null}
      </button>

      <AnimatePresence>
        {open ? (
          <motion.div
            role="dialog"
            aria-label="Notifications"
            initial={{ opacity: 0, y: -6, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.98 }}
            transition={{ duration: 0.16 }}
            className="absolute top-12 right-0 z-50 w-[min(92vw,24rem)] origin-top-right overflow-hidden rounded-2xl border border-line-strong bg-surface shadow-2xl shadow-black/60"
          >
            <div className="flex items-center justify-between border-b border-line px-4 py-3">
              <p className="text-sm font-medium">Notifications</p>
              {unread ? (
                <button
                  type="button"
                  disabled={pending}
                  onClick={() => start(async () => void (await markAllNotificationsRead()))}
                  className="inline-flex items-center gap-1 text-xs text-fg-muted hover:text-lime disabled:opacity-50"
                >
                  <CheckCheck className="size-3.5" aria-hidden /> Mark all read
                </button>
              ) : null}
            </div>
            {items.length ? (
              <ul className="max-h-96 divide-y divide-line overflow-y-auto">
                {items.map((n) => {
                  const Icon = typeIcon[n.type as keyof typeof typeIcon] ?? Info;
                  return (
                    <li key={n.id}>
                      <button
                        type="button"
                        onClick={() => openItem(n)}
                        className={cn(
                          "flex w-full gap-3 px-4 py-3 text-left hover:bg-fg/[0.03]",
                          !n.is_read && "bg-lime/[0.03]",
                        )}
                      >
                        <Icon
                          className={cn("mt-0.5 size-4 shrink-0", n.is_read ? "text-fg-subtle" : "text-lime")}
                          aria-hidden
                        />
                        <span className="min-w-0 flex-1">
                          <span className="flex items-center gap-2">
                            <span className="truncate text-sm font-medium">{n.title}</span>
                            {!n.is_read ? <span className="sr-only">(unread)</span> : null}
                          </span>
                          {n.message ? <span className="mt-0.5 block text-xs text-fg-muted">{n.message}</span> : null}
                          <span className="mt-1 block font-mono text-[0.65rem] text-fg-subtle">
                            {relativeTime(n.created_at, now)}
                          </span>
                        </span>
                        {!n.is_read ? (
                          <span aria-hidden className="mt-1.5 size-2 shrink-0 rounded-full bg-lime" />
                        ) : null}
                      </button>
                    </li>
                  );
                })}
              </ul>
            ) : (
              <p className="px-4 py-10 text-center text-sm text-fg-muted">You are all caught up.</p>
            )}
            <div className="border-t border-line px-4 py-2.5 text-right">
              <Link
                href="/dashboard/settings#notifications"
                onClick={() => setOpen(false)}
                className="text-xs text-fg-muted hover:text-fg"
              >
                View all
              </Link>
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </div>
  );
}
