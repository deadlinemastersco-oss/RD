"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useTransition } from "react";
import { ListChecks } from "lucide-react";
import { updateTaskStatus } from "@/lib/actions/dashboard";
import type { TaskWithProject } from "@/lib/data/dashboard";
import type { TaskStatus } from "@/lib/types/database";
import { taskPriorityValues, taskStatusValues } from "@/lib/validations/dashboard";
import { DataTable, type Column } from "@/components/ui/data-table";
import { EmptyState } from "@/components/ui/empty-state";
import { StatusBadge } from "@/components/ui/status-badge";
import { useToast } from "@/components/ui/toast";
import { cn, formatDate, humanize } from "@/lib/utils";

const priorityRank = { urgent: 0, high: 1, medium: 2, low: 3 } as const;

export function TasksView({
  tasks,
  staff,
  userId,
  isAdmin,
  scope,
  status,
  priority,
  today,
}: {
  tasks: TaskWithProject[];
  staff: { id: string; label: string }[];
  userId: string;
  isAdmin: boolean;
  scope: "mine" | "all";
  status: string;
  priority: string;
  today: string;
}) {
  const router = useRouter();
  const toast = useToast();
  const [pending, start] = useTransition();
  const name = (id: string | null) => (id === userId ? "You" : (staff.find((s) => s.id === id)?.label ?? "Unassigned"));

  function go(next: Partial<{ scope: string; status: string; priority: string }>) {
    const p = new URLSearchParams({
      scope: next.scope ?? scope,
      status: next.status ?? status,
      priority: next.priority ?? priority,
    });
    router.push(`/dashboard/tasks?${p}`);
  }

  function setStatus(id: string, s: TaskStatus) {
    start(async () => {
      const res = await updateTaskStatus({ id, status: s });
      if (res.ok) {
        toast.success(`Marked ${humanize(s).toLowerCase()}`);
        router.refresh();
      } else toast.error(res.message);
    });
  }

  const columns: Column<TaskWithProject>[] = [
    {
      key: "title",
      header: "Task",
      sortValue: (t) => t.title.toLowerCase(),
      cell: (t) => (
        <div className="min-w-0">
          <p className="truncate font-medium">{t.title}</p>
          <Link
            href={`/dashboard/projects/${t.project_id}`}
            onClick={(e) => e.stopPropagation()}
            className="truncate text-xs text-fg-muted hover:text-lime"
          >
            {t.project_title ?? "Open project"}
          </Link>
        </div>
      ),
    },
    {
      key: "priority",
      header: "Priority",
      hideBelow: "sm",
      sortValue: (t) => priorityRank[t.priority],
      cell: (t) => <StatusBadge status={t.priority} />,
    },
    {
      key: "assignee",
      header: "Assignee",
      hideBelow: "lg",
      cell: (t) => <span className="text-fg-muted">{name(t.assigned_to)}</span>,
    },
    {
      key: "due",
      header: "Due",
      hideBelow: "md",
      sortValue: (t) => t.due_date ?? "9999",
      cell: (t) => {
        const overdue = t.due_date && t.due_date < today && t.status !== "done";
        return (
          <span className={cn("font-mono text-xs whitespace-nowrap", overdue ? "text-danger" : "text-fg-muted")}>
            {overdue ? "Overdue · " : ""}
            {formatDate(t.due_date)}
          </span>
        );
      },
    },
    {
      key: "status",
      header: "Status",
      sortValue: (t) => t.status,
      cell: (t) => (
        <>
          <label htmlFor={`ts-${t.id}`} className="sr-only">
            Status for {t.title}
          </label>
          <select
            id={`ts-${t.id}`}
            className="field h-8 w-36 py-0 pl-2 text-xs"
            value={t.status}
            disabled={pending}
            onClick={(e) => e.stopPropagation()}
            onChange={(e) => setStatus(t.id, e.target.value as TaskStatus)}
          >
            {taskStatusValues.map((s) => (
              <option key={s} value={s}>
                {humanize(s)}
              </option>
            ))}
          </select>
        </>
      ),
    },
  ];

  const selectCls = "field h-9 w-auto py-0 text-sm";

  return (
    <>
      <div className="mb-6 flex flex-wrap items-center gap-3">
        {isAdmin ? (
          <div
            role="tablist"
            aria-label="Task scope"
            className="inline-flex rounded-full border border-line-strong p-1 text-sm"
          >
            {(["mine", "all"] as const).map((s) => (
              <button
                key={s}
                type="button"
                role="tab"
                aria-selected={scope === s}
                onClick={() => go({ scope: s })}
                className={`rounded-full px-4 py-1.5 ${scope === s ? "bg-fg text-ink" : "text-fg-muted hover:text-fg"}`}
              >
                {s === "mine" ? "My tasks" : "All tasks"}
              </button>
            ))}
          </div>
        ) : null}
        <label htmlFor="task-status-filter" className="sr-only">
          Filter by status
        </label>
        <select
          id="task-status-filter"
          className={selectCls}
          value={status}
          onChange={(e) => go({ status: e.target.value })}
        >
          <option value="open">Open (not done)</option>
          <option value="all">All statuses</option>
          {taskStatusValues.map((s) => (
            <option key={s} value={s}>
              {humanize(s)}
            </option>
          ))}
        </select>
        <label htmlFor="task-priority-filter" className="sr-only">
          Filter by priority
        </label>
        <select
          id="task-priority-filter"
          className={selectCls}
          value={priority}
          onChange={(e) => go({ priority: e.target.value })}
        >
          <option value="all">Any priority</option>
          {taskPriorityValues.map((s) => (
            <option key={s} value={s}>
              {humanize(s)}
            </option>
          ))}
        </select>
        <span className="ml-auto font-mono text-xs text-fg-subtle">{tasks.length} tasks</span>
      </div>

      <DataTable
        caption="Tasks"
        rows={tasks}
        columns={columns}
        rowKey={(t) => t.id}
        onRowClick={(t) => router.push(`/dashboard/projects/${t.project_id}`)}
        empty={
          <EmptyState
            icon={ListChecks}
            title="No tasks here"
            description={
              scope === "mine" ? "Nothing matching these filters is assigned to you." : "No tasks match these filters."
            }
          />
        }
      />
    </>
  );
}
