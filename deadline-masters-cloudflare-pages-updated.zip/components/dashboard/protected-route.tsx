import type { ReactNode } from "react";
import { DatabaseZap, ShieldAlert } from "lucide-react";
import { EmptyState } from "@/components/ui/empty-state";
import { ButtonLink } from "@/components/ui/button";
import { getSessionUser, hasRole } from "@/lib/auth";
import type { UserRole } from "@/lib/types/database";

/**
 * Server-side route guard for dashboard sections. Renders an access notice
 * instead of the content when the signed-in user's database role is too low.
 * (The proxy and each page's requireUser() also enforce sign-in.)
 */
export async function ProtectedRoute({ minRole, children }: { minRole: UserRole; children: ReactNode }) {
  const user = await getSessionUser();
  if (!hasRole(user, minRole)) return <AccessDenied minRole={minRole} />;
  return <>{children}</>;
}

export function AccessDenied({ minRole }: { minRole: UserRole }) {
  return (
    <EmptyState
      icon={ShieldAlert}
      title="You do not have access to this area"
      description={
        <>
          This section requires the <strong className="text-fg">{minRole.replace("_", " ")}</strong> role. Ask an admin
          to update your access from the Team page.
        </>
      }
      action={
        <ButtonLink href="/dashboard" variant="outline" size="sm">
          Back to overview
        </ButtonLink>
      }
    />
  );
}

export function SetupRequired({ what = "this data" }: { what?: string }) {
  return (
    <EmptyState
      icon={DatabaseZap}
      title="Database setup needed"
      description={
        <>
          We could not find the tables for {what}. Run the SQL files in{" "}
          <code className="font-mono text-xs">supabase/migrations</code> in your Supabase SQL editor, then refresh. See
          SETUP.md → “Run the database migrations”.
        </>
      }
    />
  );
}

export function PageTitle({
  title,
  description,
  actions,
}: {
  title: string;
  description?: ReactNode;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-2xl font-semibold tracking-[-0.03em] sm:text-3xl">{title}</h1>
        {description ? <div className="mt-1.5 text-sm text-fg-muted">{description}</div> : null}
      </div>
      {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
    </div>
  );
}
