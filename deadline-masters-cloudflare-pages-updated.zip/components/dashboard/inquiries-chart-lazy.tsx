"use client";

import dynamic from "next/dynamic";
import { Skeleton } from "@/components/ui/loading-skeleton";

/** Recharts is only downloaded when the overview is opened. */
export const InquiriesChartLazy = dynamic(() => import("@/components/dashboard/inquiries-chart"), {
  ssr: false,
  loading: () => <Skeleton className="h-64 w-full" />,
});
