"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ExternalLink, LogOut, Menu, X } from "lucide-react";
import { Logo } from "@/components/ui/logo";
import { StatusBadge } from "@/components/ui/status-badge";
import { dashboardNav } from "@/components/dashboard/nav-config";
import { signOut } from "@/lib/actions/auth";
import type { UserRole } from "@/lib/types/database";
import { cn, initials } from "@/lib/utils";

const rank: Record<UserRole, number> = { viewer: 0, team_member: 1, admin: 2 };

type ShellUser = { name: string; email: string | null; role: UserRole; avatarUrl: string | null };

function NavLinks({ role, onNavigate }: { role: UserRole; onNavigate?: () => void }) {
  const pathname = usePathname();
  const items = dashboardNav.filter((i) => rank[role] >= rank[i.minRole]);
  return (
    <ul className="space-y-1">
      {items.map((item) => {
        const active = item.href === "/dashboard" ? pathname === item.href : pathname.startsWith(item.href);
        const Icon = item.icon;
        return (
          <li key={item.href}>
            <Link
              href={item.href}
              onClick={onNavigate}
              aria-current={active ? "page" : undefined}
              className={cn(
                "relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors",
                active ? "text-fg" : "text-fg-muted hover:bg-fg/[0.04] hover:text-fg",
              )}
            >
              {active ? (
                <motion.span
                  layoutId="dash-nav-active"
                  className="absolute inset-0 rounded-xl border border-line-strong bg-fg/[0.06]"
                  transition={{ type: "spring", stiffness: 400, damping: 34 }}
                />
              ) : null}
              <Icon className={cn("relative size-4", active && "text-lime")} aria-hidden />
              <span className="relative">{item.label}</span>
            </Link>
          </li>
        );
      })}
    </ul>
  );
}

function UserBlock({ user }: { user: ShellUser }) {
  return (
    <div className="rounded-2xl border border-line p-3">
      <div className="flex items-center gap-3">
        <span className="grid size-9 shrink-0 place-items-center overflow-hidden rounded-full border border-line-strong bg-surface-2 text-xs font-medium uppercase">
          {initials(user.name)}
        </span>
        <div className="min-w-0">
          <p className="truncate text-sm font-medium">{user.name}</p>
          <p className="truncate text-xs text-fg-subtle">{user.email}</p>
        </div>
      </div>
      <div className="mt-3 flex items-center justify-between">
        <StatusBadge status={user.role} />
        <form action={signOut}>
          <button
            type="submit"
            className="inline-flex items-center gap-1.5 rounded-lg px-2 py-1 text-xs text-fg-muted hover:bg-fg/5 hover:text-fg"
          >
            <LogOut className="size-3.5" aria-hidden /> Sign out
          </button>
        </form>
      </div>
    </div>
  );
}

/** Responsive dashboard frame: fixed sidebar on desktop, drawer on mobile. */
export function DashboardSidebar({
  user,
  topbar,
  children,
}: {
  user: ShellUser;
  topbar: ReactNode;
  children: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- close mobile drawer after navigation
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open]);

  const sidebar = (
    <div className="flex h-full flex-col gap-8 p-5">
      <Logo href="/dashboard" />
      <nav aria-label="Dashboard" className="flex-1">
        <p className="label-mono mb-3 px-3 text-fg-subtle">Workspace</p>
        <NavLinks role={user.role} onNavigate={() => setOpen(false)} />
      </nav>
      <div className="space-y-3">
        <Link href="/" className="flex items-center gap-2 px-3 text-xs text-fg-subtle hover:text-fg">
          <ExternalLink className="size-3.5" aria-hidden /> View website
        </Link>
        <UserBlock user={user} />
      </div>
    </div>
  );

  return (
    <div className="min-h-dvh lg:grid lg:grid-cols-[17rem_1fr]">
      <aside className="sticky top-0 hidden h-dvh border-r border-line bg-surface/60 lg:block">{sidebar}</aside>

      <AnimatePresence>
        {open ? (
          <div
            className="fixed inset-0 z-[60] lg:hidden"
            role="dialog"
            aria-modal="true"
            aria-label="Dashboard navigation"
          >
            <motion.div
              className="absolute inset-0 bg-black/70"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setOpen(false)}
              aria-hidden
            />
            <motion.aside
              className="absolute inset-y-0 left-0 w-72 border-r border-line bg-surface"
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "spring", stiffness: 360, damping: 36 }}
            >
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="absolute top-5 right-4 rounded-lg p-1.5 text-fg-muted hover:text-fg"
                aria-label="Close navigation"
              >
                <X className="size-5" aria-hidden />
              </button>
              {sidebar}
            </motion.aside>
          </div>
        ) : null}
      </AnimatePresence>

      <div className="flex min-w-0 flex-col">
        <header className="glass sticky top-0 z-40 flex h-16 items-center gap-3 border-b border-line px-4 sm:px-6">
          <button
            type="button"
            onClick={() => setOpen(true)}
            className="grid size-9 place-items-center rounded-lg border border-line-strong lg:hidden"
            aria-label="Open navigation"
            aria-expanded={open}
          >
            <Menu className="size-4" aria-hidden />
          </button>
          <div className="lg:hidden">
            <Logo href="/dashboard" className="[&>span]:hidden sm:[&>span]:inline" />
          </div>
          <div className="ml-auto flex items-center gap-2">{topbar}</div>
        </header>
        <main id="main" className="flex-1 px-4 py-8 sm:px-6 lg:px-10">
          {children}
        </main>
      </div>
    </div>
  );
}
