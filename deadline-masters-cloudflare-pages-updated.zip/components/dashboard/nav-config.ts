import { Bell, FolderKanban, Inbox, LayoutDashboard, ListChecks, Settings, Users, type LucideIcon } from "lucide-react";
import type { UserRole } from "@/lib/types/database";

export type DashboardNavItem = { label: string; href: string; icon: LucideIcon; minRole: UserRole };

export const dashboardNav: DashboardNavItem[] = [
  { label: "Overview", href: "/dashboard", icon: LayoutDashboard, minRole: "viewer" },
  { label: "Inquiries", href: "/dashboard/inquiries", icon: Inbox, minRole: "team_member" },
  { label: "Projects", href: "/dashboard/projects", icon: FolderKanban, minRole: "team_member" },
  { label: "Tasks", href: "/dashboard/tasks", icon: ListChecks, minRole: "team_member" },
  { label: "Team", href: "/dashboard/team", icon: Users, minRole: "team_member" },
  { label: "Settings", href: "/dashboard/settings", icon: Settings, minRole: "viewer" },
];

export const notificationIcon = Bell;
