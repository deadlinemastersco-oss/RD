"use client";

import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

type Point = { week: string; contact: number; project: number };

const fmt = new Intl.DateTimeFormat("en-IN", { day: "numeric", month: "short" });

/** Weekly inquiry volume, split by source. Loaded lazily (see inquiries-chart-lazy). */
export default function InquiriesChart({ data }: { data: Point[] }) {
  const rows = data.map((d) => ({ ...d, label: fmt.format(new Date(`${d.week}T00:00:00`)) }));
  const total = data.reduce((s, d) => s + d.contact + d.project, 0);

  return (
    <figure>
      <figcaption className="sr-only">
        Inquiries per week over the last eight weeks, {total} in total. Contact form and diagnostic inquiries are shown
        as separate bars.
      </figcaption>
      <div className="h-64 w-full" aria-hidden>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={rows} margin={{ top: 8, right: 8, left: -20, bottom: 0 }} barGap={2}>
            <CartesianGrid vertical={false} stroke="rgb(237 237 230 / 0.07)" />
            <XAxis dataKey="label" tickLine={false} axisLine={false} tick={{ fill: "#7c7e77", fontSize: 11 }} />
            <YAxis allowDecimals={false} tickLine={false} axisLine={false} tick={{ fill: "#7c7e77", fontSize: 11 }} />
            <Tooltip
              cursor={{ fill: "rgb(237 237 230 / 0.04)" }}
              contentStyle={{
                background: "#13161a",
                border: "1px solid rgb(237 237 230 / 0.16)",
                borderRadius: 12,
                color: "#edede6",
                fontSize: 12,
              }}
            />
            <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12, color: "#a3a59d", paddingTop: 8 }} />
            <Bar
              dataKey="contact"
              name="Contact form"
              stackId="a"
              fill="#c8f34a"
              radius={[0, 0, 0, 0]}
              maxBarSize={28}
            />
            <Bar dataKey="project" name="Diagnostic" stackId="a" fill="#62e1e8" radius={[6, 6, 0, 0]} maxBarSize={28} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </figure>
  );
}
