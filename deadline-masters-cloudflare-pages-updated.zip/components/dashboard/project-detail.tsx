"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { ArrowLeft, CalendarClock, ListChecks, Pencil, Plus, Trash2, User } from "lucide-react";
import {
  createTask,
  deleteProject,
  deleteTask,
  updateProject,
  updateTask,
  updateTaskStatus,
} from "@/lib/actions/dashboard";
import type { ProjectRow, ProjectTaskRow, TaskStatus } from "@/lib/types/database";
import { taskStatusValues } from "@/lib/validations/dashboard";
import { ProjectForm, TaskForm } from "@/components/dashboard/project-forms";
import { Modal } from "@/components/ui/modal";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/ui/empty-state";
import { StatusBadge } from "@/components/ui/status-badge";
import { useToast } from "@/components/ui/toast";
import { cn, formatDate, humanize } from "@/lib/utils";

type StaffOption = { id: string; label: string };

export function ProjectDetail({
  project,
  tasks,
  staff,
  userId,
  isAdmin,
}: {
  project: ProjectRow;
  tasks: ProjectTaskRow[];
  staff: StaffOption[];
  userId: string;
  isAdmin: boolean;
}) {
  const router = useRouter();
  const toast = useToast();
  const [pending, start] = useTransition();
  const [editing, setEditing] = useState(false);
  const [addingTask, setAddingTask] = useState(false);
  const [editTask, setEditTask] = useState<ProjectTaskRow | null>(null);
  const [confirmDeleteProject, setConfirmDeleteProject] = useState(false);
  const [confirmDeleteTask, setConfirmDeleteTask] = useState<ProjectTaskRow | null>(null);

  const isOwner = project.owner_id === userId;
  const canManage = isAdmin || isOwner;
  const name = (id: string | null) => staff.find((s) => s.id === id)?.label ?? "Unassigned";
  const done = tasks.filter((t) => t.status === "done").length;

  const groups = taskStatusValues.map((s) => ({ status: s, items: tasks.filter((t) => t.status === s) }));

  function changeStatus(task: ProjectTaskRow, status: TaskStatus) {
    start(async () => {
      const res = await updateTaskStatus({ id: task.id, status });
      if (res.ok) {
        toast.success(`Moved to ${humanize(status)}`);
        router.refresh();
      } else toast.error(res.message);
    });
  }

  return (
    <>
      <Link
        href="/dashboard/projects"
        className="mb-6 inline-flex items-center gap-2 text-sm text-fg-muted hover:text-fg"
      >
        <ArrowLeft className="size-4" aria-hidden /> Projects
      </Link>

      <div className="card p-6 sm:p-8">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-3">
              <StatusBadge status={project.status} />
              <span className="font-mono text-xs text-fg-subtle">
                {formatDate(project.start_date)} → {formatDate(project.due_date)}
              </span>
            </div>
            <h1 className="mt-4 text-3xl font-semibold tracking-[-0.03em]">{project.title}</h1>
            <p className="mt-1 text-fg-muted">{project.client_name ?? "Internal project"}</p>
            {project.description ? (
              <p className="mt-5 max-w-3xl text-sm leading-relaxed whitespace-pre-wrap text-fg-muted">
                {project.description}
              </p>
            ) : null}
          </div>
          {canManage ? (
            <div className="flex shrink-0 gap-2">
              <Button variant="outline" size="sm" onClick={() => setEditing(true)}>
                <Pencil className="size-3.5" aria-hidden /> Edit
              </Button>
              {isAdmin ? (
                <Button variant="danger" size="sm" onClick={() => setConfirmDeleteProject(true)}>
                  <Trash2 className="size-3.5" aria-hidden /> Delete
                </Button>
              ) : null}
            </div>
          ) : null}
        </div>

        <dl className="mt-8 grid gap-6 border-t border-line pt-6 sm:grid-cols-3">
          <div>
            <dt className="label-mono text-fg-subtle">Owner</dt>
            <dd className="mt-1.5 flex items-center gap-2 text-sm">
              <User className="size-4 text-fg-subtle" aria-hidden /> {name(project.owner_id)}
            </dd>
          </div>
          <div>
            <dt className="label-mono text-fg-subtle">Tasks</dt>
            <dd className="mt-1.5 flex items-center gap-2 text-sm">
              <ListChecks className="size-4 text-fg-subtle" aria-hidden /> {done} of {tasks.length} done
            </dd>
          </div>
          <div>
            <dt className="label-mono text-fg-subtle">Progress</dt>
            <dd className="mt-2">
              <div
                className="h-2 overflow-hidden rounded-full bg-fg/[0.06]"
                role="progressbar"
                aria-label="Project progress"
                aria-valuenow={project.progress}
                aria-valuemin={0}
                aria-valuemax={100}
              >
                <div className="h-full rounded-full bg-lime" style={{ width: `${project.progress}%` }} />
              </div>
              <span className="mt-1 block text-right font-mono text-xs text-fg-muted">{project.progress}%</span>
            </dd>
          </div>
        </dl>
      </div>

      <section className="mt-8" aria-labelledby="tasks-heading">
        <div className="mb-4 flex items-center justify-between">
          <h2 id="tasks-heading" className="text-xl font-semibold tracking-tight">
            Tasks
          </h2>
          {canManage ? (
            <Button size="sm" onClick={() => setAddingTask(true)}>
              <Plus className="size-4" aria-hidden /> Add task
            </Button>
          ) : null}
        </div>

        {tasks.length ? (
          <div className="grid gap-4 md:grid-cols-2 2xl:grid-cols-5">
            {groups.map((g) => (
              <div key={g.status} className="rounded-2xl border border-line bg-surface/40 p-3">
                <div className="mb-3 flex items-center justify-between px-1">
                  <StatusBadge status={g.status} />
                  <span className="font-mono text-xs text-fg-subtle">{g.items.length}</span>
                </div>
                <ul className="space-y-2">
                  {g.items.map((t) => {
                    const mine = t.assigned_to === userId;
                    const canEditStatus = canManage || mine;
                    return (
                      <li key={t.id} className="rounded-xl border border-line bg-surface-2 p-3">
                        <p className="text-sm font-medium">{t.title}</p>
                        {t.description ? (
                          <p className="mt-1 line-clamp-2 text-xs text-fg-muted">{t.description}</p>
                        ) : null}
                        <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-fg-muted">
                          <StatusBadge status={t.priority} />
                          <span className="inline-flex items-center gap-1">
                            <CalendarClock className="size-3" aria-hidden />
                            {formatDate(t.due_date)}
                          </span>
                        </div>
                        <p className={cn("mt-2 truncate text-xs", mine ? "text-lime" : "text-fg-subtle")}>
                          {mine ? "You" : name(t.assigned_to)}
                        </p>
                        <div className="mt-3 flex items-center gap-1">
                          {canEditStatus ? (
                            <>
                              <label htmlFor={`status-${t.id}`} className="sr-only">
                                Status for {t.title}
                              </label>
                              <select
                                id={`status-${t.id}`}
                                value={t.status}
                                disabled={pending}
                                onChange={(e) => changeStatus(t, e.target.value as TaskStatus)}
                                className="field h-8 flex-1 py-0 pl-2 text-xs"
                              >
                                {taskStatusValues.map((s) => (
                                  <option key={s} value={s}>
                                    {humanize(s)}
                                  </option>
                                ))}
                              </select>
                            </>
                          ) : null}
                          {canManage ? (
                            <>
                              <button
                                type="button"
                                onClick={() => setEditTask(t)}
                                className="grid size-8 place-items-center rounded-lg text-fg-subtle hover:bg-fg/5 hover:text-fg"
                                aria-label={`Edit ${t.title}`}
                              >
                                <Pencil className="size-3.5" aria-hidden />
                              </button>
                              <button
                                type="button"
                                onClick={() => setConfirmDeleteTask(t)}
                                className="grid size-8 place-items-center rounded-lg text-fg-subtle hover:bg-danger/10 hover:text-danger"
                                aria-label={`Delete ${t.title}`}
                              >
                                <Trash2 className="size-3.5" aria-hidden />
                              </button>
                            </>
                          ) : null}
                        </div>
                      </li>
                    );
                  })}
                  {!g.items.length ? <li className="px-1 py-4 text-center text-xs text-fg-subtle">Empty</li> : null}
                </ul>
              </div>
            ))}
          </div>
        ) : (
          <EmptyState
            icon={ListChecks}
            title="No tasks yet"
            description={
              canManage ? "Break the project into tasks and assign owners." : "Tasks assigned to you will appear here."
            }
            action={
              canManage ? (
                <Button size="sm" onClick={() => setAddingTask(true)}>
                  <Plus className="size-4" aria-hidden /> Add task
                </Button>
              ) : null
            }
          />
        )}
      </section>

      <Modal open={editing} onClose={() => setEditing(false)} title="Edit project" size="lg">
        <ProjectForm
          staff={staff}
          canAssignOwner={isAdmin}
          submitLabel="Save changes"
          defaultValues={{
            title: project.title,
            client_name: project.client_name ?? "",
            description: project.description ?? "",
            status: project.status,
            progress: project.progress,
            start_date: project.start_date ?? "",
            due_date: project.due_date ?? "",
            owner_id: project.owner_id ?? "",
          }}
          onCancel={() => setEditing(false)}
          onSubmit={async (values) => {
            const res = await updateProject(project.id, values);
            if (res.ok) {
              toast.success(res.message ?? "Saved");
              setEditing(false);
              router.refresh();
            } else toast.error(res.message);
          }}
        />
      </Modal>

      <Modal open={addingTask} onClose={() => setAddingTask(false)} title="Add task">
        <TaskForm
          projectId={project.id}
          staff={staff}
          submitLabel="Add task"
          onCancel={() => setAddingTask(false)}
          onSubmit={async (values) => {
            const res = await createTask(values);
            if (res.ok) {
              toast.success(res.message ?? "Task added");
              setAddingTask(false);
              router.refresh();
            } else toast.error(res.message);
          }}
        />
      </Modal>

      <Modal open={Boolean(editTask)} onClose={() => setEditTask(null)} title="Edit task">
        {editTask ? (
          <TaskForm
            key={editTask.id}
            projectId={project.id}
            staff={staff}
            submitLabel="Save task"
            defaultValues={{
              title: editTask.title,
              description: editTask.description ?? "",
              status: editTask.status,
              priority: editTask.priority,
              assigned_to: editTask.assigned_to ?? "",
              due_date: editTask.due_date ?? "",
            }}
            onCancel={() => setEditTask(null)}
            onSubmit={async (values) => {
              const res = await updateTask(editTask.id, values);
              if (res.ok) {
                toast.success(res.message ?? "Saved");
                setEditTask(null);
                router.refresh();
              } else toast.error(res.message);
            }}
          />
        ) : null}
      </Modal>

      <ConfirmDialog
        open={confirmDeleteProject}
        onClose={() => setConfirmDeleteProject(false)}
        title="Delete this project?"
        description={`“${project.title}” and all ${tasks.length} of its tasks will be permanently deleted.`}
        confirmLabel="Delete project"
        onConfirm={async () => {
          const res = await deleteProject(project.id);
          if (res.ok) {
            toast.success(res.message ?? "Deleted");
            router.push("/dashboard/projects");
          } else toast.error(res.message);
        }}
      />

      <ConfirmDialog
        open={Boolean(confirmDeleteTask)}
        onClose={() => setConfirmDeleteTask(null)}
        title="Delete this task?"
        description={confirmDeleteTask ? `“${confirmDeleteTask.title}” will be permanently deleted.` : ""}
        confirmLabel="Delete task"
        onConfirm={async () => {
          if (!confirmDeleteTask) return;
          const res = await deleteTask(confirmDeleteTask.id);
          if (res.ok) {
            toast.success(res.message ?? "Deleted");
            setConfirmDeleteTask(null);
            router.refresh();
          } else toast.error(res.message);
        }}
      />
    </>
  );
}
