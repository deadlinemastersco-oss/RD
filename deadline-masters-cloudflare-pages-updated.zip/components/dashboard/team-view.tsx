"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Eye, EyeOff, UserPlus, Users } from "lucide-react";
import type { z } from "zod";
import { inviteUser, setTeamMemberPublished, updateUserRole } from "@/lib/actions/dashboard";
import type { ProfileRow, TeamMemberRow, UserRole } from "@/lib/types/database";
import { inviteSchema, roleValues } from "@/lib/validations/dashboard";
import { Modal } from "@/components/ui/modal";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/ui/empty-state";
import { StatusBadge } from "@/components/ui/status-badge";
import { FormField, fieldAria } from "@/components/ui/form-field";
import { useToast } from "@/components/ui/toast";
import { formatDate, humanize, initials } from "@/lib/utils";

const roleHelp: Record<UserRole, string> = {
  admin: "Full access: leads, projects, team, settings and content.",
  team_member: "Sees leads assigned to them, projects they own or have tasks in.",
  viewer: "Signed in, but no access to leads or projects.",
};

export function TeamView({
  profiles,
  publicMembers,
  currentUserId,
  isAdmin,
  inviteEnabled,
}: {
  profiles: ProfileRow[];
  publicMembers: TeamMemberRow[];
  currentUserId: string;
  isAdmin: boolean;
  inviteEnabled: boolean;
}) {
  const router = useRouter();
  const toast = useToast();
  const [pending, start] = useTransition();
  const [inviting, setInviting] = useState(false);
  const [roleChange, setRoleChange] = useState<{ profile: ProfileRow; role: UserRole } | null>(null);

  const invite = useForm<z.input<typeof inviteSchema>>({
    resolver: zodResolver(inviteSchema),
    defaultValues: { email: "", role: "team_member" },
  });

  return (
    <>
      <section aria-labelledby="accounts-heading">
        <div className="mb-4 flex items-center justify-between gap-4">
          <div>
            <h2 id="accounts-heading" className="text-lg font-semibold">
              Workspace accounts
            </h2>
            <p className="text-sm text-fg-muted">People who can sign in to this dashboard.</p>
          </div>
          {isAdmin ? (
            <Button size="sm" onClick={() => setInviting(true)}>
              <UserPlus className="size-4" aria-hidden /> Invite
            </Button>
          ) : null}
        </div>

        {profiles.length ? (
          <ul className="divide-y divide-line overflow-hidden rounded-2xl border border-line">
            {profiles.map((p) => {
              const self = p.id === currentUserId;
              return (
                <li key={p.id} className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
                  <div className="flex min-w-0 flex-1 items-center gap-3">
                    <span className="grid size-10 shrink-0 place-items-center rounded-full border border-line-strong bg-surface-2 text-xs font-medium uppercase">
                      {initials(p.full_name ?? p.email)}
                    </span>
                    <div className="min-w-0">
                      <p className="truncate font-medium">
                        {p.full_name || "Unnamed"} {self ? <span className="text-xs text-fg-subtle">(you)</span> : null}
                      </p>
                      <p className="truncate text-xs text-fg-muted">
                        {p.email} · joined {formatDate(p.created_at)}
                      </p>
                    </div>
                  </div>
                  {isAdmin && !self ? (
                    <div className="flex items-center gap-2">
                      <label htmlFor={`role-${p.id}`} className="sr-only">
                        Role for {p.full_name || p.email}
                      </label>
                      <select
                        id={`role-${p.id}`}
                        className="field h-9 w-40 py-0 text-sm"
                        value={p.role}
                        disabled={pending}
                        onChange={(e) => setRoleChange({ profile: p, role: e.target.value as UserRole })}
                      >
                        {roleValues.map((r) => (
                          <option key={r} value={r}>
                            {humanize(r)}
                          </option>
                        ))}
                      </select>
                    </div>
                  ) : (
                    <StatusBadge status={p.role} />
                  )}
                </li>
              );
            })}
          </ul>
        ) : (
          <EmptyState
            icon={Users}
            title="No teammates visible"
            description="Once teammates sign up and are given team access, they appear here."
          />
        )}

        <dl className="mt-4 grid gap-3 text-xs text-fg-muted sm:grid-cols-3">
          {roleValues.map((r) => (
            <div key={r} className="rounded-xl border border-line p-3">
              <dt>
                <StatusBadge status={r} />
              </dt>
              <dd className="mt-2">{roleHelp[r]}</dd>
            </div>
          ))}
        </dl>
      </section>

      {isAdmin ? (
        <section className="mt-12" aria-labelledby="public-heading">
          <h2 id="public-heading" className="text-lg font-semibold">
            Public team profiles
          </h2>
          <p className="text-sm text-fg-muted">
            Shown on the website&apos;s Team sections. Edit names, bios and photos in Supabase → Table editor →{" "}
            <code className="font-mono text-xs">team_members</code>.
          </p>
          {publicMembers.length ? (
            <ul className="mt-4 grid gap-3 md:grid-cols-2">
              {publicMembers.map((m) => (
                <li key={m.id} className="card flex items-center gap-4 p-4">
                  <span className="grid size-10 shrink-0 place-items-center rounded-full bg-surface-2 font-serif text-lime italic">
                    {initials(m.name)}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium">{m.name}</p>
                    <p className="truncate text-xs text-fg-muted">{m.role}</p>
                  </div>
                  <Button
                    size="sm"
                    variant={m.is_published ? "outline" : "ghost"}
                    disabled={pending}
                    aria-pressed={m.is_published}
                    onClick={() =>
                      start(async () => {
                        const res = await setTeamMemberPublished({ id: m.id, value: !m.is_published });
                        if (res.ok) {
                          toast.success(res.message ?? "Updated");
                          router.refresh();
                        } else toast.error(res.message);
                      })
                    }
                  >
                    {m.is_published ? (
                      <Eye className="size-3.5" aria-hidden />
                    ) : (
                      <EyeOff className="size-3.5" aria-hidden />
                    )}
                    {m.is_published ? "Published" : "Hidden"}
                  </Button>
                </li>
              ))}
            </ul>
          ) : (
            <p className="mt-4 rounded-xl border border-dashed border-line-strong p-4 text-sm text-fg-muted">
              No rows in <code className="font-mono text-xs">team_members</code> yet — the website is showing the
              fallback profiles from <code className="font-mono text-xs">lib/constants/people-and-work.ts</code>. Run{" "}
              <code className="font-mono text-xs">supabase/seed.sql</code> or add rows to manage them here.
            </p>
          )}
        </section>
      ) : null}

      <Modal
        open={inviting}
        onClose={() => setInviting(false)}
        title="Invite a teammate"
        description="They will receive an email to set a password."
      >
        {inviteEnabled ? (
          <form
            noValidate
            className="space-y-5"
            onSubmit={invite.handleSubmit(async (values) => {
              const res = await inviteUser(values);
              if (res.ok) {
                toast.success(res.message ?? "Invite sent");
                invite.reset();
                setInviting(false);
                router.refresh();
              } else toast.error(res.message);
            })}
          >
            <FormField id="invite-email" label="Email" required error={invite.formState.errors.email?.message}>
              <input
                className="field"
                type="email"
                data-autofocus
                {...fieldAria("invite-email", invite.formState.errors.email?.message)}
                {...invite.register("email")}
              />
            </FormField>
            <FormField id="invite-role" label="Role" required>
              <select id="invite-role" className="field" {...invite.register("role")}>
                {roleValues.map((r) => (
                  <option key={r} value={r}>
                    {humanize(r)}
                  </option>
                ))}
              </select>
            </FormField>
            <div className="flex justify-end gap-2">
              <Button type="button" variant="ghost" onClick={() => setInviting(false)}>
                Cancel
              </Button>
              <Button type="submit" loading={invite.formState.isSubmitting}>
                Send invite
              </Button>
            </div>
          </form>
        ) : (
          <div className="space-y-3 text-sm text-fg-muted">
            <p>
              In-app invites need <code className="font-mono text-xs">SUPABASE_SERVICE_ROLE_KEY</code> set on the server
              (never in the browser).
            </p>
            <p>
              Alternatively: Supabase dashboard → Authentication → Users →{" "}
              <strong className="text-fg">Invite user</strong>. Then set their role here once they appear.
            </p>
          </div>
        )}
      </Modal>

      <ConfirmDialog
        open={Boolean(roleChange)}
        onClose={() => setRoleChange(null)}
        tone="primary"
        confirmLabel="Change role"
        title="Change access level?"
        description={
          roleChange
            ? `${roleChange.profile.full_name || roleChange.profile.email} will become ${humanize(roleChange.role).toLowerCase()}. ${roleHelp[roleChange.role]}`
            : ""
        }
        onConfirm={async () => {
          if (!roleChange) return;
          const res = await updateUserRole({ user_id: roleChange.profile.id, role: roleChange.role });
          if (res.ok) {
            toast.success(res.message ?? "Role updated");
            setRoleChange(null);
            router.refresh();
          } else toast.error(res.message);
        }}
      />
    </>
  );
}
