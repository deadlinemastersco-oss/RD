"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { CalendarClock, FolderKanban, Plus, Search } from "lucide-react";
import { createProject } from "@/lib/actions/dashboard";
import type { ProjectRow } from "@/lib/types/database";
import { projectStatusValues } from "@/lib/validations/dashboard";
import { ProjectForm } from "@/components/dashboard/project-forms";
import { Modal } from "@/components/ui/modal";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/ui/empty-state";
import { StatusBadge } from "@/components/ui/status-badge";
import { useToast } from "@/components/ui/toast";
import { cn, formatDate, humanize } from "@/lib/utils";

type StaffOption = { id: string; label: string };

export function ProjectsView({
  projects,
  staff,
  isAdmin,
  status,
  q,
  openNew,
  today,
}: {
  projects: ProjectRow[];
  staff: StaffOption[];
  isAdmin: boolean;
  status: string;
  q: string;
  openNew: boolean;
  today: string;
}) {
  const router = useRouter();
  const toast = useToast();
  const [creating, setCreating] = useState(openNew && isAdmin);
  const ownerName = (id: string | null) => staff.find((s) => s.id === id)?.label ?? "No owner";

  function go(next: { status?: string; q?: string }) {
    const p = new URLSearchParams();
    const s = next.status ?? status;
    const query = next.q ?? q;
    if (s !== "all") p.set("status", s);
    if (query) p.set("q", query);
    router.push(`/dashboard/projects${p.size ? `?${p}` : ""}`);
  }

  return (
    <>
      <div className="mb-6 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div className="flex flex-wrap gap-2" role="group" aria-label="Filter by status">
          {["all", ...projectStatusValues].map((s) => (
            <button
              key={s}
              type="button"
              aria-pressed={status === s}
              onClick={() => go({ status: s })}
              className={cn(
                "rounded-full border px-3 py-1 text-xs transition-colors",
                status === s ? "border-lime bg-lime text-ink" : "border-line-strong text-fg-muted hover:text-fg",
              )}
            >
              {s === "all" ? "All" : humanize(s)}
            </button>
          ))}
        </div>
        <div className="flex gap-2">
          <form
            role="search"
            onSubmit={(e) => {
              e.preventDefault();
              go({ q: String(new FormData(e.currentTarget).get("q") ?? "").trim() });
            }}
            className="relative"
          >
            <label htmlFor="project-search" className="sr-only">
              Search projects
            </label>
            <Search
              className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-fg-subtle"
              aria-hidden
            />
            <input
              id="project-search"
              name="q"
              defaultValue={q}
              placeholder="Search projects…"
              className="field h-9 w-56 pl-9 text-sm"
            />
          </form>
          {isAdmin ? (
            <Button size="sm" onClick={() => setCreating(true)}>
              <Plus className="size-4" aria-hidden /> New project
            </Button>
          ) : null}
        </div>
      </div>

      {projects.length ? (
        <ul className="grid gap-4 md:grid-cols-2 2xl:grid-cols-3">
          {projects.map((p) => {
            const overdue = p.due_date && p.due_date < today && !["completed", "cancelled"].includes(p.status);
            return (
              <li key={p.id}>
                <Link
                  href={`/dashboard/projects/${p.id}`}
                  className="card block h-full p-6 transition-colors hover:border-line-strong"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="truncate text-lg font-semibold tracking-tight">{p.title}</p>
                      <p className="truncate text-sm text-fg-muted">{p.client_name ?? "Internal"}</p>
                    </div>
                    <StatusBadge status={p.status} />
                  </div>
                  <div className="mt-6">
                    <div className="mb-1.5 flex justify-between text-xs text-fg-muted">
                      <span>Progress</span>
                      <span className="font-mono">{p.progress}%</span>
                    </div>
                    <div
                      className="h-1.5 overflow-hidden rounded-full bg-fg/[0.06]"
                      role="progressbar"
                      aria-label={`${p.title} progress`}
                      aria-valuenow={p.progress}
                      aria-valuemin={0}
                      aria-valuemax={100}
                    >
                      <div
                        className="h-full rounded-full bg-lime transition-[width] duration-700"
                        style={{ width: `${p.progress}%` }}
                      />
                    </div>
                  </div>
                  <div className="mt-5 flex items-center justify-between text-xs text-fg-muted">
                    <span className="truncate">{ownerName(p.owner_id)}</span>
                    <span className={cn("inline-flex items-center gap-1.5 font-mono", overdue && "text-danger")}>
                      <CalendarClock className="size-3.5" aria-hidden />
                      {overdue ? "Overdue · " : ""}
                      {formatDate(p.due_date)}
                    </span>
                  </div>
                </Link>
              </li>
            );
          })}
        </ul>
      ) : (
        <EmptyState
          icon={FolderKanban}
          title={q || status !== "all" ? "No projects match" : "No projects yet"}
          description={
            isAdmin
              ? "Create a project to start tracking progress, owners and tasks."
              : "Projects you own or have tasks in will appear here."
          }
          action={
            isAdmin ? (
              <Button size="sm" onClick={() => setCreating(true)}>
                <Plus className="size-4" aria-hidden /> New project
              </Button>
            ) : null
          }
        />
      )}

      <Modal open={creating} onClose={() => setCreating(false)} title="New project" size="lg">
        <ProjectForm
          staff={staff}
          canAssignOwner={isAdmin}
          submitLabel="Create project"
          onCancel={() => setCreating(false)}
          onSubmit={async (values) => {
            const res = await createProject(values);
            if (res.ok) {
              toast.success(res.message ?? "Project created");
              setCreating(false);
              if (res.data?.id) router.push(`/dashboard/projects/${res.data.id}`);
              else router.refresh();
            } else toast.error(res.message);
          }}
        />
      </Modal>
    </>
  );
}
