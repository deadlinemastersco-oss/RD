"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState, useTransition } from "react";
import { Mail, Phone, Search, Trash2, Send } from "lucide-react";
import { addLeadNote, deleteLead, getLeadNotes, updateLead } from "@/lib/actions/dashboard";
import type { Lead } from "@/lib/data/dashboard";
import type { LeadStatus, ProfileRow } from "@/lib/types/database";
import { leadStatusValues } from "@/lib/validations/dashboard";
import { budgetOptions, labelFor, timelineOptions, topicLabel as formatTopic } from "@/lib/constants/forms";
import { DataTable, type Column } from "@/components/ui/data-table";
import { Drawer } from "@/components/ui/modal";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { StatusBadge } from "@/components/ui/status-badge";
import { EmptyState } from "@/components/ui/empty-state";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/toast";
import { formatDate, formatDateTime, humanize } from "@/lib/utils";

type Staff = Pick<ProfileRow, "id" | "full_name" | "email">;
type Note = { id: string; body: string; created_at: string; author_id: string | null };

const topicLabel = (l: Lead) => formatTopic(l.topic);

export function InquiriesView({
  leads,
  staff,
  isAdmin,
  type,
  q,
  status,
  openId,
}: {
  leads: Lead[];
  staff: Staff[];
  isAdmin: boolean;
  type: "contact" | "project";
  q: string;
  status: string;
  openId: string | null;
}) {
  const router = useRouter();
  const [selectedId, setSelectedId] = useState<string | null>(openId);
  const selected = leads.find((l) => l.id === selectedId) ?? null;
  const staffName = (id: string | null) => {
    const s = staff.find((x) => x.id === id);
    return s ? s.full_name || s.email || "Teammate" : "Unassigned";
  };

  function applyFilters(next: { type?: string; q?: string; status?: string }) {
    const params = new URLSearchParams();
    const t = next.type ?? type;
    const s = next.status ?? status;
    const query = next.q ?? q;
    params.set("type", t);
    if (s && s !== "all") params.set("status", s);
    if (query) params.set("q", query);
    router.push(`/dashboard/inquiries?${params.toString()}`);
  }

  const columns: Column<Lead>[] = [
    {
      key: "name",
      header: "Contact",
      sortValue: (l) => l.name.toLowerCase(),
      cell: (l) => (
        <div className="min-w-0">
          <p className="truncate font-medium">{l.name}</p>
          <p className="truncate text-xs text-fg-muted">{l.company || l.email}</p>
        </div>
      ),
    },
    {
      key: "topic",
      header: "Interest",
      hideBelow: "md",
      cell: (l) => <span className="text-fg-muted">{topicLabel(l)}</span>,
    },
    {
      key: "assigned",
      header: "Owner",
      hideBelow: "lg",
      cell: (l) => <span className="text-fg-muted">{staffName(l.assigned_to)}</span>,
    },
    {
      key: "created",
      header: "Received",
      hideBelow: "sm",
      sortValue: (l) => l.created_at,
      cell: (l) => (
        <span className="font-mono text-xs whitespace-nowrap text-fg-muted">{formatDate(l.created_at)}</span>
      ),
    },
    { key: "status", header: "Status", sortValue: (l) => l.status, cell: (l) => <StatusBadge status={l.status} /> },
  ];

  return (
    <>
      <div className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div
          role="tablist"
          aria-label="Inquiry source"
          className="inline-flex rounded-full border border-line-strong p-1 text-sm"
        >
          {(
            [
              ["contact", "Contact form"],
              ["project", "Diagnostic"],
            ] as const
          ).map(([value, label]) => (
            <button
              key={value}
              type="button"
              role="tab"
              aria-selected={type === value}
              onClick={() => applyFilters({ type: value })}
              className={`rounded-full px-4 py-1.5 transition-colors ${type === value ? "bg-fg text-ink" : "text-fg-muted hover:text-fg"}`}
            >
              {label}
            </button>
          ))}
        </div>

        <form
          role="search"
          className="flex flex-1 flex-col gap-2 sm:flex-row lg:max-w-xl"
          onSubmit={(e) => {
            e.preventDefault();
            const fd = new FormData(e.currentTarget);
            applyFilters({ q: String(fd.get("q") ?? "").trim(), status: String(fd.get("status") ?? "all") });
          }}
        >
          <label htmlFor="lead-search" className="sr-only">
            Search inquiries
          </label>
          <div className="relative flex-1">
            <Search
              className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-fg-subtle"
              aria-hidden
            />
            <input
              id="lead-search"
              name="q"
              defaultValue={q}
              placeholder="Search name, email, company…"
              className="field h-10 pl-9 text-sm"
            />
          </div>
          <label htmlFor="lead-status" className="sr-only">
            Filter by status
          </label>
          <select
            id="lead-status"
            name="status"
            defaultValue={status}
            className="field h-10 py-0 text-sm sm:w-44"
            onChange={(e) => applyFilters({ status: e.target.value })}
          >
            <option value="all">All statuses</option>
            {leadStatusValues.map((s) => (
              <option key={s} value={s}>
                {humanize(s)}
              </option>
            ))}
          </select>
          <Button type="submit" variant="outline" size="sm" className="h-10">
            Search
          </Button>
        </form>
      </div>

      <DataTable
        caption={`${type === "contact" ? "Contact form" : "Diagnostic"} inquiries`}
        rows={leads}
        columns={columns}
        rowKey={(l) => l.id}
        onRowClick={(l) => setSelectedId(l.id)}
        empty={
          <EmptyState
            icon={Search}
            title={q || status !== "all" ? "No inquiries match your filters" : "No inquiries yet"}
            description={
              q || status !== "all"
                ? "Try a different search or status."
                : isAdmin
                  ? "New submissions from the website will appear here instantly."
                  : "Leads assigned to you will appear here."
            }
          />
        }
      />

      <LeadDrawer
        lead={selected}
        staff={staff}
        isAdmin={isAdmin}
        staffName={staffName}
        onClose={() => {
          setSelectedId(null);
          if (openId) router.replace(`/dashboard/inquiries?type=${type}`, { scroll: false });
        }}
      />
    </>
  );
}

function LeadDrawer({
  lead,
  staff,
  isAdmin,
  staffName,
  onClose,
}: {
  lead: Lead | null;
  staff: Staff[];
  isAdmin: boolean;
  staffName: (id: string | null) => string;
  onClose: () => void;
}) {
  const router = useRouter();
  const toast = useToast();
  const [pending, start] = useTransition();
  const [notes, setNotes] = useState<Note[] | null>(null);
  const [draft, setDraft] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(false);

  const leadKey = lead ? `${lead.type}:${lead.id}` : null;
  useEffect(() => {
    if (!lead) return;
    let alive = true;
    getLeadNotes(lead.type, lead.id).then((n) => alive && setNotes(n));
    return () => {
      alive = false;
      setNotes(null);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- reload only when a different lead opens
  }, [leadKey]);

  if (!lead) return <Drawer open={false} onClose={onClose} title="" />;

  function patch(p: { status?: LeadStatus; assigned_to?: string | null }) {
    if (!lead) return;
    start(async () => {
      const res = await updateLead({ type: lead.type, id: lead.id, ...p });
      if (res.ok) {
        toast.success(res.message ?? "Saved");
        router.refresh();
      } else toast.error(res.message);
    });
  }

  function saveNote() {
    if (!lead || !draft.trim()) return;
    start(async () => {
      const res = await addLeadNote({ type: lead.type, id: lead.id, body: draft });
      if (res.ok) {
        setDraft("");
        setNotes(await getLeadNotes(lead.type, lead.id));
        toast.success("Note added");
      } else toast.error(res.message);
    });
  }

  const diag =
    lead.diagnostic && typeof lead.diagnostic === "object" && !Array.isArray(lead.diagnostic)
      ? (lead.diagnostic as Record<string, unknown>)
      : null;

  return (
    <>
      <Drawer
        open={Boolean(lead)}
        onClose={onClose}
        title={lead.name}
        description={
          <span className="flex flex-wrap items-center gap-2">
            <StatusBadge status={lead.status} />
            <span className="font-mono text-xs">{formatDateTime(lead.created_at)}</span>
          </span>
        }
      >
        <div className="space-y-8">
          <section aria-label="Contact details" className="grid gap-3 text-sm">
            <a href={`mailto:${lead.email}`} className="flex items-center gap-2 hover:text-lime">
              <Mail className="size-4 text-fg-subtle" aria-hidden /> {lead.email}
            </a>
            {lead.phone ? (
              <a href={`tel:${lead.phone.replace(/\s/g, "")}`} className="flex items-center gap-2 hover:text-lime">
                <Phone className="size-4 text-fg-subtle" aria-hidden /> {lead.phone}
              </a>
            ) : null}
            <dl className="mt-2 grid grid-cols-2 gap-4 rounded-xl border border-line p-4">
              <div>
                <dt className="label-mono text-fg-subtle">Company</dt>
                <dd className="mt-1">{lead.company || "—"}</dd>
              </div>
              <div>
                <dt className="label-mono text-fg-subtle">Interest</dt>
                <dd className="mt-1">{topicLabel(lead)}</dd>
              </div>
              <div>
                <dt className="label-mono text-fg-subtle">Budget</dt>
                <dd className="mt-1">{lead.budget ? labelFor(budgetOptions, lead.budget) : "—"}</dd>
              </div>
              <div>
                <dt className="label-mono text-fg-subtle">Timeline</dt>
                <dd className="mt-1">
                  {lead.type === "contact" ? labelFor(timelineOptions, lead.timeline) : humanize(lead.timeline)}
                </dd>
              </div>
            </dl>
          </section>

          {diag ? (
            <section aria-label="Diagnostic answers">
              <h3 className="label-mono mb-3 text-fg-subtle">Diagnostic answers</h3>
              <ul className="flex flex-wrap gap-2">
                {(["problem", "urgency", "stage", "outcome", "engagement"] as const).map((k) =>
                  typeof diag[k] === "string" ? (
                    <li key={k} className="rounded-full border border-line-strong px-3 py-1 text-xs">
                      <span className="text-fg-subtle">{k}:</span> {humanize(diag[k] as string)}
                    </li>
                  ) : null,
                )}
              </ul>
            </section>
          ) : null}

          {lead.message ? (
            <section aria-label="Message">
              <h3 className="label-mono mb-3 text-fg-subtle">Message</h3>
              {/* Rendered as plain text — never as HTML. */}
              <p className="rounded-xl bg-surface-2 p-4 text-sm leading-relaxed whitespace-pre-wrap">{lead.message}</p>
            </section>
          ) : null}

          <section aria-label="Manage lead" className="grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="lead-status-edit" className="label-mono mb-2 block text-fg-subtle">
                Status
              </label>
              <select
                id="lead-status-edit"
                className="field h-10 py-0 text-sm"
                value={lead.status}
                disabled={pending}
                onChange={(e) => patch({ status: e.target.value as LeadStatus })}
              >
                {leadStatusValues.map((s) => (
                  <option key={s} value={s}>
                    {humanize(s)}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="lead-owner-edit" className="label-mono mb-2 block text-fg-subtle">
                Owner
              </label>
              {isAdmin ? (
                <select
                  id="lead-owner-edit"
                  className="field h-10 py-0 text-sm"
                  value={lead.assigned_to ?? ""}
                  disabled={pending}
                  onChange={(e) => patch({ assigned_to: e.target.value || null })}
                >
                  <option value="">Unassigned</option>
                  {staff.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.full_name || s.email}
                    </option>
                  ))}
                </select>
              ) : (
                <p id="lead-owner-edit" className="py-2 text-sm">
                  {staffName(lead.assigned_to)}
                </p>
              )}
            </div>
          </section>

          <section aria-labelledby="notes-heading">
            <h3 id="notes-heading" className="label-mono mb-3 text-fg-subtle">
              Internal notes
            </h3>
            <div className="space-y-2">
              <label htmlFor="note-draft" className="sr-only">
                Add a note
              </label>
              <textarea
                id="note-draft"
                className="field min-h-20 text-sm"
                placeholder="Call summary, next step, context for the team…"
                value={draft}
                maxLength={4000}
                onChange={(e) => setDraft(e.target.value)}
              />
              <div className="flex justify-end">
                <Button size="sm" onClick={saveNote} loading={pending} disabled={!draft.trim()}>
                  <Send className="size-3.5" aria-hidden /> Add note
                </Button>
              </div>
            </div>
            <ul className="mt-4 space-y-3">
              {notes === null ? (
                <li className="text-sm text-fg-subtle">Loading notes…</li>
              ) : notes.length ? (
                notes.map((n) => (
                  <li key={n.id} className="rounded-xl border border-line p-3">
                    <p className="text-sm whitespace-pre-wrap">{n.body}</p>
                    <p className="mt-2 font-mono text-[0.68rem] text-fg-subtle">
                      {staffName(n.author_id)} · {formatDateTime(n.created_at)}
                    </p>
                  </li>
                ))
              ) : (
                <li className="text-sm text-fg-subtle">No notes yet.</li>
              )}
            </ul>
          </section>

          {isAdmin ? (
            <section className="border-t border-line pt-6">
              <Button variant="danger" size="sm" onClick={() => setConfirmDelete(true)}>
                <Trash2 className="size-3.5" aria-hidden /> Delete lead
              </Button>
            </section>
          ) : null}
        </div>
      </Drawer>

      <ConfirmDialog
        open={confirmDelete}
        onClose={() => setConfirmDelete(false)}
        title="Delete this lead?"
        description={`${lead.name}'s inquiry and its notes will be permanently deleted. This cannot be undone.`}
        onConfirm={async () => {
          const res = await deleteLead({ type: lead.type, id: lead.id });
          if (res.ok) {
            toast.success(res.message ?? "Deleted");
            setConfirmDelete(false);
            onClose();
            router.refresh();
          } else toast.error(res.message);
        }}
      />
    </>
  );
}
