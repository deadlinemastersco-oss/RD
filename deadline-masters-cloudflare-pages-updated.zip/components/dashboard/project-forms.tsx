"use client";

import { useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  projectSchema,
  projectStatusValues,
  taskPriorityValues,
  taskSchema,
  taskStatusValues,
  type ProjectInput,
  type TaskInput,
} from "@/lib/validations/dashboard";
import { FormField, fieldAria } from "@/components/ui/form-field";
import { Button } from "@/components/ui/button";
import { humanize } from "@/lib/utils";

type StaffOption = { id: string; label: string };

export function ProjectForm({
  defaultValues,
  staff,
  canAssignOwner,
  submitLabel,
  onSubmit,
  onCancel,
}: {
  defaultValues?: Partial<ProjectInput>;
  staff: StaffOption[];
  canAssignOwner: boolean;
  submitLabel: string;
  onSubmit: (values: ProjectInput) => Promise<void>;
  onCancel: () => void;
}) {
  const { register, handleSubmit, control, formState } = useForm<ProjectInput>({
    resolver: zodResolver(projectSchema),
    defaultValues: {
      title: "",
      client_name: "",
      description: "",
      status: "planning",
      progress: 0,
      start_date: "",
      due_date: "",
      owner_id: "",
      ...defaultValues,
    },
  });
  const e = formState.errors;
  const progress = useWatch({ control, name: "progress" });

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-5">
      <FormField id="p-title" label="Project title" required error={e.title?.message}>
        <input className="field" data-autofocus {...fieldAria("p-title", e.title?.message)} {...register("title")} />
      </FormField>
      <div className="grid gap-5 sm:grid-cols-2">
        <FormField id="p-client" label="Client" error={e.client_name?.message}>
          <input className="field" {...fieldAria("p-client", e.client_name?.message)} {...register("client_name")} />
        </FormField>
        <FormField id="p-status" label="Status" required error={e.status?.message}>
          <select className="field" {...fieldAria("p-status", e.status?.message)} {...register("status")}>
            {projectStatusValues.map((s) => (
              <option key={s} value={s}>
                {humanize(s)}
              </option>
            ))}
          </select>
        </FormField>
        <FormField id="p-start" label="Start date" error={e.start_date?.message}>
          <input
            type="date"
            className="field"
            {...fieldAria("p-start", e.start_date?.message)}
            {...register("start_date")}
          />
        </FormField>
        <FormField id="p-due" label="Due date" error={e.due_date?.message}>
          <input type="date" className="field" {...fieldAria("p-due", e.due_date?.message)} {...register("due_date")} />
        </FormField>
      </div>
      <FormField id="p-progress" label={`Progress — ${progress ?? 0}%`} required error={e.progress?.message}>
        <input
          type="range"
          min={0}
          max={100}
          step={5}
          className="w-full accent-lime"
          {...fieldAria("p-progress", e.progress?.message)}
          {...register("progress", { valueAsNumber: true })}
        />
      </FormField>
      {canAssignOwner ? (
        <FormField id="p-owner" label="Project owner" error={e.owner_id?.message}>
          <select className="field" {...fieldAria("p-owner", e.owner_id?.message)} {...register("owner_id")}>
            <option value="">No owner</option>
            {staff.map((s) => (
              <option key={s.id} value={s.id}>
                {s.label}
              </option>
            ))}
          </select>
        </FormField>
      ) : null}
      <FormField id="p-desc" label="Description" error={e.description?.message}>
        <textarea
          className="field min-h-28"
          {...fieldAria("p-desc", e.description?.message)}
          {...register("description")}
        />
      </FormField>
      <div className="flex justify-end gap-2 pt-2">
        <Button type="button" variant="ghost" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" loading={formState.isSubmitting}>
          {submitLabel}
        </Button>
      </div>
    </form>
  );
}

export function TaskForm({
  projectId,
  defaultValues,
  staff,
  submitLabel,
  onSubmit,
  onCancel,
}: {
  projectId: string;
  defaultValues?: Partial<TaskInput>;
  staff: StaffOption[];
  submitLabel: string;
  onSubmit: (values: TaskInput) => Promise<void>;
  onCancel: () => void;
}) {
  const { register, handleSubmit, formState } = useForm<TaskInput>({
    resolver: zodResolver(taskSchema),
    defaultValues: {
      project_id: projectId,
      title: "",
      description: "",
      status: "todo",
      priority: "medium",
      assigned_to: "",
      due_date: "",
      ...defaultValues,
    },
  });
  const e = formState.errors;

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-5">
      <input type="hidden" {...register("project_id")} />
      <FormField id="t-title" label="Task" required error={e.title?.message}>
        <input className="field" data-autofocus {...fieldAria("t-title", e.title?.message)} {...register("title")} />
      </FormField>
      <div className="grid gap-5 sm:grid-cols-2">
        <FormField id="t-status" label="Status" required>
          <select className="field" id="t-status" {...register("status")}>
            {taskStatusValues.map((s) => (
              <option key={s} value={s}>
                {humanize(s)}
              </option>
            ))}
          </select>
        </FormField>
        <FormField id="t-priority" label="Priority" required>
          <select className="field" id="t-priority" {...register("priority")}>
            {taskPriorityValues.map((s) => (
              <option key={s} value={s}>
                {humanize(s)}
              </option>
            ))}
          </select>
        </FormField>
        <FormField id="t-assignee" label="Assignee" error={e.assigned_to?.message}>
          <select className="field" {...fieldAria("t-assignee", e.assigned_to?.message)} {...register("assigned_to")}>
            <option value="">Unassigned</option>
            {staff.map((s) => (
              <option key={s.id} value={s.id}>
                {s.label}
              </option>
            ))}
          </select>
        </FormField>
        <FormField id="t-due" label="Due date" error={e.due_date?.message}>
          <input type="date" className="field" {...fieldAria("t-due", e.due_date?.message)} {...register("due_date")} />
        </FormField>
      </div>
      <FormField id="t-desc" label="Details" error={e.description?.message}>
        <textarea
          className="field min-h-24"
          {...fieldAria("t-desc", e.description?.message)}
          {...register("description")}
        />
      </FormField>
      <div className="flex justify-end gap-2 pt-2">
        <Button type="button" variant="ghost" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" loading={formState.isSubmitting}>
          {submitLabel}
        </Button>
      </div>
    </form>
  );
}
