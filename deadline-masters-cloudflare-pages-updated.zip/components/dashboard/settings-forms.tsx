"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Bell, CheckCheck, Plus, Trash2 } from "lucide-react";
import { deleteSiteSetting, markAllNotificationsRead, updateProfile, upsertSiteSetting } from "@/lib/actions/dashboard";
import type { NotificationRow, SiteSettingRow } from "@/lib/types/database";
import { profileSchema, type ProfileInput } from "@/lib/validations/dashboard";
import { Button } from "@/components/ui/button";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { FormField, fieldAria } from "@/components/ui/form-field";
import { useToast } from "@/components/ui/toast";
import { cn, formatDateTime } from "@/lib/utils";

export function ProfileForm({ defaults, email }: { defaults: ProfileInput; email: string | null }) {
  const toast = useToast();
  const router = useRouter();
  const { register, handleSubmit, formState, reset } = useForm<ProfileInput>({
    resolver: zodResolver(profileSchema),
    defaultValues: defaults,
  });
  const e = formState.errors;

  return (
    <form
      noValidate
      className="space-y-5"
      onSubmit={handleSubmit(async (values) => {
        const res = await updateProfile(values);
        if (res.ok) {
          toast.success(res.message ?? "Saved");
          reset(values);
          router.refresh();
        } else toast.error(res.message);
      })}
    >
      <div className="grid gap-5 sm:grid-cols-2">
        <FormField id="pf-name" label="Full name" required error={e.full_name?.message}>
          <input
            className="field"
            autoComplete="name"
            {...fieldAria("pf-name", e.full_name?.message)}
            {...register("full_name")}
          />
        </FormField>
        <FormField id="pf-email" label="Email" required hint="Managed by your sign-in account.">
          <input
            id="pf-email"
            className="field opacity-70"
            value={email ?? ""}
            readOnly
            aria-describedby="pf-email-hint"
          />
        </FormField>
      </div>
      <FormField
        id="pf-avatar"
        label="Avatar URL"
        error={e.avatar_url?.message}
        hint="Link to a square image, e.g. from Supabase Storage (avatars bucket)."
      >
        <input
          className="field"
          type="url"
          placeholder="https://"
          {...fieldAria("pf-avatar", e.avatar_url?.message, "hint")}
          {...register("avatar_url")}
        />
      </FormField>
      <FormField id="pf-bio" label="Short bio" error={e.bio?.message}>
        <textarea className="field min-h-24" {...fieldAria("pf-bio", e.bio?.message)} {...register("bio")} />
      </FormField>
      <div className="flex justify-end">
        <Button type="submit" loading={formState.isSubmitting} disabled={!formState.isDirty}>
          Save profile
        </Button>
      </div>
    </form>
  );
}

export function NotificationsList({ items }: { items: NotificationRow[] }) {
  const [pending, start] = useTransition();
  const toast = useToast();
  const router = useRouter();
  const unread = items.filter((n) => !n.is_read).length;

  return (
    <div>
      <div className="mb-3 flex items-center justify-between">
        <p className="text-sm text-fg-muted">{unread ? `${unread} unread` : "All caught up"}</p>
        {unread ? (
          <Button
            size="sm"
            variant="ghost"
            loading={pending}
            onClick={() =>
              start(async () => {
                const res = await markAllNotificationsRead();
                if (res.ok) {
                  toast.success(res.message ?? "Done");
                  router.refresh();
                } else toast.error(res.message);
              })
            }
          >
            <CheckCheck className="size-4" aria-hidden /> Mark all read
          </Button>
        ) : null}
      </div>
      {items.length ? (
        <ul className="divide-y divide-line rounded-2xl border border-line">
          {items.map((n) => (
            <li key={n.id} className={cn("flex gap-3 p-4", !n.is_read && "bg-lime/[0.03]")}>
              <Bell className={cn("mt-0.5 size-4 shrink-0", n.is_read ? "text-fg-subtle" : "text-lime")} aria-hidden />
              <div className="min-w-0">
                <p className="text-sm font-medium">
                  {n.title} {!n.is_read ? <span className="sr-only">(unread)</span> : null}
                </p>
                {n.message ? <p className="text-sm text-fg-muted">{n.message}</p> : null}
                <p className="mt-1 font-mono text-[0.68rem] text-fg-subtle">{formatDateTime(n.created_at)}</p>
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <p className="rounded-2xl border border-dashed border-line-strong p-8 text-center text-sm text-fg-muted">
          No notifications yet. New leads and task assignments will appear here.
        </p>
      )}
    </div>
  );
}

export function SiteSettingsEditor({ settings }: { settings: SiteSettingRow[] }) {
  const toast = useToast();
  const router = useRouter();
  const [pending, start] = useTransition();
  const [key, setKey] = useState("");
  const [value, setValue] = useState("");
  const [toDelete, setToDelete] = useState<SiteSettingRow | null>(null);

  function save(k: string, v: string) {
    start(async () => {
      const res = await upsertSiteSetting({ key: k, value: v });
      if (res.ok) {
        toast.success(res.message ?? "Saved");
        setKey("");
        setValue("");
        router.refresh();
      } else toast.error(res.message);
    });
  }

  return (
    <div className="space-y-4">
      <p className="text-sm text-fg-muted">
        Key/value configuration stored in <code className="font-mono text-xs">site_settings</code>. Values may be plain
        text or JSON. Keys starting with <code className="font-mono text-xs">public.</code> are readable by website
        visitors — never store secrets here.
      </p>
      {settings.length ? (
        <ul className="divide-y divide-line rounded-2xl border border-line">
          {settings.map((s) => (
            <SettingRow key={s.id} setting={s} disabled={pending} onSave={save} onDelete={() => setToDelete(s)} />
          ))}
        </ul>
      ) : null}
      <form
        className="grid gap-3 rounded-2xl border border-dashed border-line-strong p-4 sm:grid-cols-[1fr_2fr_auto]"
        onSubmit={(e) => {
          e.preventDefault();
          if (key.trim()) save(key.trim(), value);
        }}
      >
        <div>
          <label htmlFor="ss-key" className="sr-only">
            Setting key
          </label>
          <input
            id="ss-key"
            className="field h-10 font-mono text-sm"
            placeholder="public.announcement"
            value={key}
            onChange={(e) => setKey(e.target.value)}
          />
        </div>
        <div>
          <label htmlFor="ss-value" className="sr-only">
            Setting value
          </label>
          <input
            id="ss-value"
            className="field h-10 text-sm"
            placeholder='"Now booking Q1 projects" or {"enabled": true}'
            value={value}
            onChange={(e) => setValue(e.target.value)}
          />
        </div>
        <Button type="submit" size="sm" className="h-10" loading={pending} disabled={!key.trim()}>
          <Plus className="size-4" aria-hidden /> Add
        </Button>
      </form>

      <ConfirmDialog
        open={Boolean(toDelete)}
        onClose={() => setToDelete(null)}
        title="Delete setting?"
        description={toDelete ? `“${toDelete.key}” will be removed.` : ""}
        onConfirm={async () => {
          if (!toDelete) return;
          const res = await deleteSiteSetting(toDelete.id);
          if (res.ok) {
            toast.success(res.message ?? "Deleted");
            setToDelete(null);
            router.refresh();
          } else toast.error(res.message);
        }}
      />
    </div>
  );
}

function SettingRow({
  setting,
  disabled,
  onSave,
  onDelete,
}: {
  setting: SiteSettingRow;
  disabled: boolean;
  onSave: (k: string, v: string) => void;
  onDelete: () => void;
}) {
  const initial = typeof setting.value === "string" ? setting.value : JSON.stringify(setting.value);
  const [v, setV] = useState(initial);
  return (
    <li className="grid items-center gap-3 p-3 sm:grid-cols-[1fr_2fr_auto]">
      <code className="truncate font-mono text-sm">{setting.key}</code>
      <div>
        <label htmlFor={`ss-${setting.id}`} className="sr-only">
          Value for {setting.key}
        </label>
        <input id={`ss-${setting.id}`} className="field h-9 text-sm" value={v} onChange={(e) => setV(e.target.value)} />
      </div>
      <div className="flex gap-1">
        <Button size="sm" variant="outline" disabled={disabled || v === initial} onClick={() => onSave(setting.key, v)}>
          Save
        </Button>
        <button
          type="button"
          onClick={onDelete}
          className="grid size-9 place-items-center rounded-lg text-fg-subtle hover:bg-danger/10 hover:text-danger"
          aria-label={`Delete ${setting.key}`}
        >
          <Trash2 className="size-4" aria-hidden />
        </button>
      </div>
    </li>
  );
}
