"use client";

import { Suspense, type ReactNode } from "react";
import { MotionConfig } from "framer-motion";
import { ToastProvider } from "@/components/ui/toast";
import { RouteProgress } from "@/components/ui/route-progress";

export function Providers({ children }: { children: ReactNode }) {
  return (
    // reducedMotion="user" → every Framer Motion animation respects prefers-reduced-motion.
    <MotionConfig reducedMotion="user">
      <ToastProvider>
        <Suspense fallback={null}>
          <RouteProgress />
        </Suspense>
        {children}
      </ToastProvider>
    </MotionConfig>
  );
}
