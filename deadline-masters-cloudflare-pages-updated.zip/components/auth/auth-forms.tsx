"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { requestPasswordReset, signUp, updatePassword } from "@/lib/actions/auth";
import {
  forgotPasswordSchema,
  signUpSchema,
  updatePasswordSchema,
  type ForgotPasswordInput,
  type SignUpInput,
  type UpdatePasswordInput,
} from "@/lib/validations/auth";
import { Button } from "@/components/ui/button";
import { FormField, fieldAria } from "@/components/ui/form-field";
import { FormAlert, PasswordInput } from "@/components/auth/sign-in-form";

const PASSWORD_HINT = "At least 8 characters, including a letter and a number.";

export function SignUpForm() {
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const { register, handleSubmit, formState } = useForm<SignUpInput>({
    resolver: zodResolver(signUpSchema),
    defaultValues: { full_name: "", email: "", password: "", confirm_password: "" },
  });
  const e = formState.errors;

  async function onSubmit(values: SignUpInput) {
    setError(null);
    const res = await signUp(values);
    if (!res) return;
    if (res.ok) setSuccess(res.message ?? "Check your inbox.");
    else setError(res.message);
  }

  if (success) return <FormAlert tone="success">{success}</FormAlert>;

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-5">
      {error ? <FormAlert tone="error">{error}</FormAlert> : null}
      <FormField id="full_name" label="Full name" required error={e.full_name?.message}>
        <input
          className="field"
          autoComplete="name"
          {...fieldAria("full_name", e.full_name?.message)}
          {...register("full_name")}
        />
      </FormField>
      <FormField id="email" label="Work email" required error={e.email?.message}>
        <input
          className="field"
          type="email"
          autoComplete="email"
          {...fieldAria("email", e.email?.message)}
          {...register("email")}
        />
      </FormField>
      <FormField id="password" label="Password" required error={e.password?.message} hint={PASSWORD_HINT}>
        <PasswordInput
          id="password"
          autoComplete="new-password"
          error={e.password?.message}
          {...register("password")}
        />
      </FormField>
      <FormField id="confirm_password" label="Confirm password" required error={e.confirm_password?.message}>
        <PasswordInput
          id="confirm_password"
          autoComplete="new-password"
          error={e.confirm_password?.message}
          {...register("confirm_password")}
        />
      </FormField>
      <Button type="submit" className="w-full" loading={formState.isSubmitting}>
        Create account
      </Button>
      <p className="text-xs leading-relaxed text-fg-subtle">
        New accounts start with read-only <em>viewer</em> access. An admin must grant team access.
      </p>
    </form>
  );
}

export function ForgotPasswordForm() {
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const { register, handleSubmit, formState } = useForm<ForgotPasswordInput>({
    resolver: zodResolver(forgotPasswordSchema),
    defaultValues: { email: "" },
  });

  async function onSubmit(values: ForgotPasswordInput) {
    setError(null);
    const res = await requestPasswordReset(values);
    if (res.ok) setSuccess(res.message ?? "Check your inbox.");
    else setError(res.message);
  }

  if (success) return <FormAlert tone="success">{success}</FormAlert>;

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-5">
      {error ? <FormAlert tone="error">{error}</FormAlert> : null}
      <FormField id="email" label="Email" required error={formState.errors.email?.message}>
        <input
          className="field"
          type="email"
          autoComplete="email"
          {...fieldAria("email", formState.errors.email?.message)}
          {...register("email")}
        />
      </FormField>
      <Button type="submit" className="w-full" loading={formState.isSubmitting}>
        Send reset link
      </Button>
    </form>
  );
}

export function UpdatePasswordForm() {
  const [error, setError] = useState<string | null>(null);
  const { register, handleSubmit, formState } = useForm<UpdatePasswordInput>({
    resolver: zodResolver(updatePasswordSchema),
    defaultValues: { password: "", confirm_password: "" },
  });
  const e = formState.errors;

  async function onSubmit(values: UpdatePasswordInput) {
    setError(null);
    const res = await updatePassword(values);
    if (res && !res.ok) setError(res.message);
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-5">
      {error ? <FormAlert tone="error">{error}</FormAlert> : null}
      <FormField id="password" label="New password" required error={e.password?.message} hint={PASSWORD_HINT}>
        <PasswordInput
          id="password"
          autoComplete="new-password"
          error={e.password?.message}
          {...register("password")}
        />
      </FormField>
      <FormField id="confirm_password" label="Confirm new password" required error={e.confirm_password?.message}>
        <PasswordInput
          id="confirm_password"
          autoComplete="new-password"
          error={e.confirm_password?.message}
          {...register("confirm_password")}
        />
      </FormField>
      <Button type="submit" className="w-full" loading={formState.isSubmitting}>
        Update password
      </Button>
    </form>
  );
}
