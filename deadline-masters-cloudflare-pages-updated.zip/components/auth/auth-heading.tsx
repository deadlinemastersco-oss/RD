import type { ReactNode } from "react";

export function AuthHeading({
  eyebrow,
  title,
  description,
}: {
  eyebrow: string;
  title: string;
  description?: ReactNode;
}) {
  return (
    <div className="mb-8">
      <p className="label-mono text-lime">{eyebrow}</p>
      <h1 className="mt-4 text-3xl font-semibold tracking-[-0.03em] sm:text-4xl">{title}</h1>
      {description ? <div className="mt-3 text-fg-muted">{description}</div> : null}
    </div>
  );
}
