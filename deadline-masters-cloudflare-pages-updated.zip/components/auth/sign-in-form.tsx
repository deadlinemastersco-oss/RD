"use client";

import Link from "next/link";
import { useState } from "react";
import { useSearchParams } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { CircleAlert, CircleCheck, Eye, EyeOff, Mail } from "lucide-react";
import { sendMagicLink, signInWithPassword } from "@/lib/actions/auth";
import { magicLinkSchema, signInSchema, type SignInInput } from "@/lib/validations/auth";
import { Button } from "@/components/ui/button";
import { FormField, fieldAria } from "@/components/ui/form-field";

export function FormAlert({ tone, children }: { tone: "error" | "success" | "info"; children: React.ReactNode }) {
  const Icon = tone === "success" ? CircleCheck : CircleAlert;
  const cls =
    tone === "error"
      ? "border-danger/30 bg-danger/10"
      : tone === "success"
        ? "border-success/30 bg-success/10"
        : "border-cyan/30 bg-cyan/10";
  const iconCls = tone === "error" ? "text-danger" : tone === "success" ? "text-success" : "text-cyan";
  return (
    <div role={tone === "error" ? "alert" : "status"} className={`flex gap-3 rounded-xl border p-3.5 text-sm ${cls}`}>
      <Icon className={`mt-0.5 size-4 shrink-0 ${iconCls}`} aria-hidden />
      <div>{children}</div>
    </div>
  );
}

export function PasswordInput({ id, error, ...props }: React.ComponentProps<"input"> & { id: string; error?: string }) {
  const [show, setShow] = useState(false);
  return (
    <div className="relative">
      <input type={show ? "text" : "password"} className="field pr-11" {...fieldAria(id, error)} {...props} />
      <button
        type="button"
        onClick={() => setShow((s) => !s)}
        className="absolute inset-y-0 right-0 grid w-11 place-items-center text-fg-subtle hover:text-fg"
        aria-label={show ? "Hide password" : "Show password"}
        aria-pressed={show}
      >
        {show ? <EyeOff className="size-4" aria-hidden /> : <Eye className="size-4" aria-hidden />}
      </button>
    </div>
  );
}

export function SignInForm() {
  const params = useSearchParams();
  const next = params.get("next") ?? undefined;
  const [mode, setMode] = useState<"password" | "magic">("password");
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(
    params.get("signed_out")
      ? "You have been signed out."
      : params.get("password") === "updated"
        ? "Password updated."
        : null,
  );

  const form = useForm<SignInInput>({
    resolver: zodResolver(signInSchema),
    defaultValues: { email: "", password: "" },
  });
  const magic = useForm<{ email: string }>({ resolver: zodResolver(magicLinkSchema), defaultValues: { email: "" } });

  async function onPassword(values: SignInInput) {
    setError(null);
    setInfo(null);
    const res = await signInWithPassword(values, next);
    // On success the action redirects; we only get here on failure.
    if (res && !res.ok) setError(res.message);
  }

  async function onMagic(values: { email: string }) {
    setError(null);
    const res = await sendMagicLink(values, next);
    if (res.ok) setInfo(res.message ?? "Check your inbox.");
    else setError(res.message);
  }

  const fe = form.formState.errors;

  return (
    <div className="space-y-6">
      {info ? <FormAlert tone="success">{info}</FormAlert> : null}
      {error ? <FormAlert tone="error">{error}</FormAlert> : null}

      <div
        role="tablist"
        aria-label="Sign-in method"
        className="grid grid-cols-2 rounded-full border border-line-strong p-1 text-sm"
      >
        {(["password", "magic"] as const).map((m) => (
          <button
            key={m}
            type="button"
            role="tab"
            aria-selected={mode === m}
            onClick={() => {
              setMode(m);
              setError(null);
            }}
            className={`rounded-full py-2 transition-colors ${mode === m ? "bg-fg text-ink" : "text-fg-muted hover:text-fg"}`}
          >
            {m === "password" ? "Password" : "Email link"}
          </button>
        ))}
      </div>

      {mode === "password" ? (
        <form onSubmit={form.handleSubmit(onPassword)} noValidate className="space-y-5">
          <FormField id="email" label="Email" required error={fe.email?.message}>
            <input
              className="field"
              type="email"
              autoComplete="email"
              {...fieldAria("email", fe.email?.message)}
              {...form.register("email")}
            />
          </FormField>
          <FormField id="password" label="Password" required error={fe.password?.message}>
            <PasswordInput
              id="password"
              autoComplete="current-password"
              error={fe.password?.message}
              {...form.register("password")}
            />
          </FormField>
          <div className="flex justify-end">
            <Link
              href="/auth/forgot-password"
              className="text-sm text-fg-muted underline-offset-4 hover:text-fg hover:underline"
            >
              Forgot password?
            </Link>
          </div>
          <Button type="submit" className="w-full" loading={form.formState.isSubmitting}>
            Sign in
          </Button>
        </form>
      ) : (
        <form onSubmit={magic.handleSubmit(onMagic)} noValidate className="space-y-5">
          <FormField
            id="magic-email"
            label="Email"
            required
            error={magic.formState.errors.email?.message}
            hint="We will email you a one-time sign-in link. Works for existing team accounts only."
          >
            <input
              className="field"
              type="email"
              autoComplete="email"
              {...fieldAria("magic-email", magic.formState.errors.email?.message, "hint")}
              {...magic.register("email")}
            />
          </FormField>
          <Button type="submit" className="w-full" loading={magic.formState.isSubmitting}>
            <Mail className="size-4" aria-hidden /> Email me a link
          </Button>
        </form>
      )}
    </div>
  );
}
