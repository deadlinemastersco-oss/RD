import Image from "next/image";
import Link from "next/link";
import { cn } from "@/lib/utils";

export function LogoMark({ className }: { className?: string }) {
  return (
    <Image
      src="/deadline-masters-logo.png"
      alt=""
      width={96}
      height={96}
      priority
      className={cn("size-9 object-contain", className)}
      aria-hidden="true"
    />
  );
}

export function Logo({ className, href = "/" }: { className?: string; href?: string }) {
  return (
    <Link
      href={href}
      className={cn("group inline-flex items-center gap-2.5", className)}
      aria-label="Deadline Masters — home"
    >
      <LogoMark className="transition-transform duration-300 group-hover:scale-[1.04]" />
      <span className="text-[1.05rem] font-semibold tracking-[-0.03em]">
        Deadline<span className="text-fg-muted">Masters</span>
      </span>
    </Link>
  );
}
