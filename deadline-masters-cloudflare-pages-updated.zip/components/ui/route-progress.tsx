"use client";

import { useEffect, useRef, useState } from "react";
import { usePathname, useSearchParams } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";

/**
 * Thin top progress line shown during client-side navigations.
 * Starts on same-origin link clicks, completes when the URL changes.
 */
export function RouteProgress() {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [active, setActive] = useState(false);
  const timer = useRef<number | null>(null);

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      const a = (e.target as HTMLElement | null)?.closest?.("a");
      if (!a || a.target === "_blank" || a.hasAttribute("download")) return;
      const href = a.getAttribute("href");
      if (!href || href.startsWith("#") || href.startsWith("mailto:") || href.startsWith("tel:")) return;
      const url = new URL(a.href, window.location.href);
      if (url.origin !== window.location.origin) return;
      if (url.pathname === window.location.pathname && url.search === window.location.search) return;
      if (timer.current) window.clearTimeout(timer.current);
      // Avoid a flash for instant (prefetched) navigations.
      timer.current = window.setTimeout(() => setActive(true), 120);
    }
    document.addEventListener("click", onClick, true);
    return () => document.removeEventListener("click", onClick, true);
  }, []);

  useEffect(() => {
    if (timer.current) window.clearTimeout(timer.current);
    // eslint-disable-next-line react-hooks/set-state-in-effect -- navigation finished; reset indicator
    setActive(false);
  }, [pathname, searchParams]);

  return (
    <AnimatePresence>
      {active ? (
        <motion.div
          aria-hidden
          className="fixed inset-x-0 top-0 z-[120] h-0.5 origin-left bg-lime shadow-[0_0_12px_rgb(200_243_74/0.7)]"
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 0.85, transition: { duration: 2.5, ease: [0.1, 0.8, 0.3, 1] } }}
          exit={{ scaleX: 1, opacity: 0, transition: { duration: 0.3 } }}
        />
      ) : null}
    </AnimatePresence>
  );
}
