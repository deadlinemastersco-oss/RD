import { cn } from "@/lib/utils";

type Props = {
  text: string;
  /** Words to render in the italic serif accent (matched as a phrase). */
  accent?: string;
  as?: "h1" | "h2" | "p";
  className?: string;
  /** Seconds before the first word starts. */
  delay?: number;
};

/**
 * Word-by-word headline reveal driven by CSS keyframes, so it runs on first paint
 * without waiting for JavaScript (good for LCP). The full sentence is exposed to
 * assistive tech via aria-label; animated spans are aria-hidden. Reduced-motion
 * users get the final state immediately (see globals.css).
 */
export function AnimatedText({ text, accent, as = "h1", className, delay = 0 }: Props) {
  const Tag = as;
  const accentWords = accent ? accent.split(" ") : [];
  const words = text.split(" ");

  let accentStart = -1;
  if (accentWords.length) {
    accentStart = words.findIndex((_, i) => accentWords.every((a, j) => words[i + j] === a));
  }

  return (
    <Tag className={className} aria-label={text}>
      {words.map((word, i) => {
        const isAccent = accentStart >= 0 && i >= accentStart && i < accentStart + accentWords.length;
        return (
          <span key={`${word}-${i}`} aria-hidden className="inline-block overflow-hidden pb-[0.12em] align-bottom">
            <span
              className={cn(
                "inline-block animate-word-rise",
                isAccent && "pr-[0.06em] font-serif font-normal text-lime italic",
              )}
              style={{ animationDelay: `${delay + i * 0.045}s` }}
            >
              {word}
            </span>
            {i < words.length - 1 ? " " : ""}
          </span>
        );
      })}
    </Tag>
  );
}
