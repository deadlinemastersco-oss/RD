import type { LucideIcon } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
  className,
}: {
  icon: LucideIcon;
  title: string;
  description?: ReactNode;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "relative flex flex-col items-center justify-center overflow-hidden rounded-[var(--radius-card)] border border-dashed border-line-strong px-6 py-14 text-center",
        className,
      )}
    >
      <div aria-hidden className="bg-grid bg-grid-fade absolute inset-0 opacity-60" />
      <div className="relative mb-5 grid size-12 place-items-center rounded-2xl border border-line-strong bg-surface-2">
        <Icon className="size-5 text-lime" aria-hidden />
      </div>
      <h3 className="relative text-lg font-semibold tracking-tight">{title}</h3>
      {description ? (
        <div className="relative mt-2 max-w-md text-sm leading-relaxed text-fg-muted">{description}</div>
      ) : null}
      {action ? <div className="relative mt-6">{action}</div> : null}
    </div>
  );
}
