import {
  Compass,
  Globe,
  Layers,
  LayoutDashboard,
  Magnet,
  PenTool,
  ShieldCheck,
  TrendingUp,
  Workflow,
  Zap,
  type LucideIcon,
  type LucideProps,
} from "lucide-react";
import type { IconName } from "@/lib/types/content";

export const iconMap: Record<IconName, LucideIcon> = {
  globe: Globe,
  "layout-dashboard": LayoutDashboard,
  "pen-tool": PenTool,
  workflow: Workflow,
  "trending-up": TrendingUp,
  magnet: Magnet,
  "shield-check": ShieldCheck,
  zap: Zap,
  layers: Layers,
  compass: Compass,
};

export function ServiceIcon({ name, ...props }: { name: IconName } & LucideProps) {
  const Icon = iconMap[name] ?? Layers;
  return <Icon aria-hidden {...props} />;
}
