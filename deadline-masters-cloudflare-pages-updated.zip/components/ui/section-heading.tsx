import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

/** Sharp mono section label, e.g.  [ 03 ]  PROCESS */
export function SectionLabel({
  index,
  children,
  className,
}: {
  index?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <p className={cn("label-mono flex items-center gap-3 text-fg-muted", className)}>
      {index ? (
        <span className="text-lime" aria-hidden>
          [{index}]
        </span>
      ) : (
        <span aria-hidden className="size-1.5 rounded-full bg-lime" />
      )}
      <span>{children}</span>
    </p>
  );
}

export function SectionHeading({
  index,
  eyebrow,
  title,
  description,
  align = "left",
  className,
  as = "h2",
}: {
  index?: string;
  eyebrow?: string;
  title: ReactNode;
  description?: ReactNode;
  align?: "left" | "center";
  className?: string;
  as?: "h1" | "h2";
}) {
  const Tag = as;
  return (
    <div className={cn("max-w-3xl", align === "center" && "mx-auto text-center", className)}>
      {eyebrow ? (
        <SectionLabel index={index} className={cn("mb-5", align === "center" && "justify-center")}>
          {eyebrow}
        </SectionLabel>
      ) : null}
      <Tag
        className={cn(
          "font-semibold tracking-[-0.035em] text-fg",
          as === "h1" ? "text-4xl leading-[1.02] sm:text-6xl lg:text-7xl" : "text-3xl leading-[1.05] sm:text-5xl",
        )}
      >
        {title}
      </Tag>
      {description ? (
        <div className={cn("mt-5 text-lg leading-relaxed text-fg-muted", align === "center" && "mx-auto max-w-2xl")}>
          {description}
        </div>
      ) : null}
    </div>
  );
}

/** Italic serif accent used inside headings. */
export function Accent({ children }: { children: ReactNode }) {
  return <span className="font-serif font-normal text-lime italic">{children}</span>;
}
