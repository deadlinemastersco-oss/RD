"use client";

import { Component, type ErrorInfo, type ReactNode } from "react";
import { CircleAlert } from "lucide-react";

type Props = { children: ReactNode; fallback?: ReactNode; label?: string };
type State = { hasError: boolean };

/**
 * Component-level error boundary for isolated widgets (charts, notification
 * panel). Route-level errors are handled by the error.tsx files in app/.
 */
export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error(
      `[ErrorBoundary${this.props.label ? `:${this.props.label}` : ""}]`,
      error.message,
      info.componentStack,
    );
  }

  render() {
    if (!this.state.hasError) return this.props.children;
    return (
      this.props.fallback ?? (
        <div
          role="alert"
          className="flex items-center gap-3 rounded-xl border border-danger/30 bg-danger/5 p-4 text-sm"
        >
          <CircleAlert className="size-4 shrink-0 text-danger" aria-hidden />
          <span className="text-fg-muted">This section could not be displayed.</span>
          <button
            type="button"
            className="ml-auto text-fg underline underline-offset-4"
            onClick={() => this.setState({ hasError: false })}
          >
            Retry
          </button>
        </div>
      )
    );
  }
}
