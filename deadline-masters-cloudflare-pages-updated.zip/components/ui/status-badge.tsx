import { cn, humanize } from "@/lib/utils";

type Tone = "lime" | "cyan" | "violet" | "amber" | "danger" | "success" | "neutral";

const tones: Record<Tone, string> = {
  lime: "text-lime border-lime/30 bg-lime/10",
  cyan: "text-cyan border-cyan/30 bg-cyan/10",
  violet: "text-violet border-violet/30 bg-violet/10",
  amber: "text-amber border-amber/30 bg-amber/10",
  danger: "text-danger border-danger/30 bg-danger/10",
  success: "text-success border-success/30 bg-success/10",
  neutral: "text-fg-muted border-line-strong bg-fg/[0.04]",
};

const statusTone: Record<string, Tone> = {
  // leads
  new: "lime",
  contacted: "cyan",
  qualified: "violet",
  proposal_sent: "amber",
  won: "success",
  lost: "danger",
  archived: "neutral",
  // projects
  planning: "cyan",
  active: "lime",
  on_hold: "amber",
  review: "violet",
  completed: "success",
  cancelled: "neutral",
  // tasks
  todo: "neutral",
  in_progress: "cyan",
  blocked: "danger",
  done: "success",
  // priority
  low: "neutral",
  medium: "cyan",
  high: "amber",
  urgent: "danger",
  // roles
  admin: "lime",
  team_member: "violet",
  viewer: "neutral",
};

/**
 * Status pill. Always renders the text label next to the colour dot so meaning
 * is never conveyed by colour alone.
 */
export function StatusBadge({
  status,
  label,
  tone,
  className,
}: {
  status?: string;
  label?: string;
  tone?: Tone;
  className?: string;
}) {
  const t = tone ?? statusTone[status ?? ""] ?? "neutral";
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 font-mono text-[0.68rem] font-medium tracking-wider uppercase",
        tones[t],
        className,
      )}
    >
      <span aria-hidden className="size-1.5 rounded-full bg-current" />
      {label ?? humanize(status)}
    </span>
  );
}
