"use client";

import { useEffect, useRef } from "react";
import { useReducedMotion } from "framer-motion";

/**
 * Hero backdrop: fine grid + soft glows + a spotlight that follows the mouse
 * on desktop. Pure CSS variables — no re-renders on pointer move.
 */
export function HeroBackground() {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();

  useEffect(() => {
    const el = ref.current;
    if (!el || reduce || window.matchMedia("(pointer: coarse)").matches) return;
    let frame = 0;
    const onMove = (e: PointerEvent) => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const r = el.getBoundingClientRect();
        el.style.setProperty("--mx", `${e.clientX - r.left}px`);
        el.style.setProperty("--my", `${e.clientY - r.top}px`);
      });
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("pointermove", onMove);
    };
  }, [reduce]);

  return (
    <div ref={ref} aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden [--mx:70%] [--my:30%]">
      <div className="bg-grid bg-grid-fade absolute inset-0" />
      <div
        className="absolute inset-0 opacity-70 transition-opacity"
        style={{
          background: "radial-gradient(420px circle at var(--mx) var(--my), rgb(200 243 74 / 0.10), transparent 60%)",
        }}
      />
      <div className="absolute -top-40 left-1/2 h-[520px] w-[900px] -translate-x-1/2 rounded-full bg-[radial-gradient(ellipse_at_center,rgb(98_225_232/0.10),transparent_65%)] blur-2xl" />
      <div className="absolute top-1/3 -right-40 h-[420px] w-[420px] rounded-full bg-[radial-gradient(circle,rgb(168_148_255/0.09),transparent_65%)] blur-2xl" />
      <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-b from-transparent to-ink" />
    </div>
  );
}
