import Image from "next/image";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import type { CaseStudy } from "@/lib/types/content";
import { cn } from "@/lib/utils";

/** Deterministic abstract cover so cards look intentional without stock imagery. */
function AbstractCover({ seed, className }: { seed: string; className?: string }) {
  const hash = Array.from(seed).reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7);
  const palette = ["#c8f34a", "#62e1e8", "#a894ff", "#f5b84b"];
  const c1 = palette[hash % 4]!;
  const c2 = palette[(hash >>> 3) % 4]!;
  const bars = Array.from({ length: 9 }, (_, i) => 20 + ((hash >>> i) % 60));
  return (
    <svg viewBox="0 0 400 240" className={className} aria-hidden preserveAspectRatio="xMidYMid slice">
      <rect width="400" height="240" fill="#0d0f12" />
      <defs>
        <linearGradient id={`g-${seed}`} x1="0" x2="1" y1="0" y2="1">
          <stop offset="0" stopColor={c1} stopOpacity="0.35" />
          <stop offset="1" stopColor={c2} stopOpacity="0.05" />
        </linearGradient>
      </defs>
      <circle cx={80 + (hash % 240)} cy="80" r="140" fill={`url(#g-${seed})`} />
      {Array.from({ length: 10 }).map((_, i) => (
        <line key={`v${i}`} x1={i * 40} y1="0" x2={i * 40} y2="240" stroke="rgb(237 237 230 / 0.05)" />
      ))}
      {Array.from({ length: 6 }).map((_, i) => (
        <line key={`h${i}`} x1="0" y1={i * 40} x2="400" y2={i * 40} stroke="rgb(237 237 230 / 0.05)" />
      ))}
      <rect x="40" y="56" width="200" height="128" rx="10" fill="#13161a" stroke="rgb(237 237 230 / 0.12)" />
      {bars.map((h, i) => (
        <rect
          key={i}
          x={56 + i * 19}
          y={168 - h}
          width="11"
          height={h}
          rx="2"
          fill={i % 3 === 0 ? c1 : "rgb(237 237 230 / 0.18)"}
        />
      ))}
      <rect x="260" y="56" width="100" height="56" rx="10" fill="#13161a" stroke="rgb(237 237 230 / 0.12)" />
      <rect x="274" y="72" width="54" height="6" rx="3" fill="rgb(237 237 230 / 0.3)" />
      <rect x="274" y="88" width="34" height="6" rx="3" fill={c2} opacity="0.7" />
      <rect x="260" y="128" width="100" height="56" rx="10" fill="#13161a" stroke="rgb(237 237 230 / 0.12)" />
      <circle cx="286" cy="156" r="12" fill="none" stroke={c1} strokeWidth="4" strokeDasharray="50 100" />
    </svg>
  );
}

export function CaseStudyCover({
  study,
  className,
  priority,
}: {
  study: CaseStudy;
  className?: string;
  priority?: boolean;
}) {
  if (study.coverImage) {
    return (
      <Image
        src={study.coverImage}
        alt={`Cover image for ${study.title}`}
        fill
        sizes="(min-width: 1024px) 40vw, 100vw"
        className={cn("object-cover", className)}
        priority={priority}
      />
    );
  }
  return <AbstractCover seed={study.slug} className={cn("absolute inset-0 h-full w-full", className)} />;
}

export function CaseStudyCard({ study, className }: { study: CaseStudy; className?: string }) {
  return (
    <Link
      href={`/work/${study.slug}`}
      className={cn(
        "card group flex h-full flex-col overflow-hidden transition-colors hover:border-line-strong",
        className,
      )}
    >
      <div className="relative aspect-[5/3] overflow-hidden border-b border-line">
        <div className="absolute inset-0 transition-transform duration-700 ease-out group-hover:scale-[1.04]">
          <CaseStudyCover study={study} />
        </div>
        {study.isIllustrative ? (
          <span className="label-mono absolute top-4 left-4 rounded-full border border-amber/40 bg-ink/80 px-2.5 py-1 !text-[0.62rem] text-amber backdrop-blur">
            Illustrative blueprint
          </span>
        ) : null}
      </div>
      <div className="flex flex-1 flex-col p-6">
        <p className="label-mono text-fg-subtle">{study.industry}</p>
        <h3 className="mt-3 text-lg leading-snug font-semibold tracking-tight">{study.title}</h3>
        <p className="mt-3 line-clamp-3 text-sm leading-relaxed text-fg-muted">{study.summary}</p>
        <div className="mt-auto flex items-center justify-between pt-6">
          <ul className="flex flex-wrap gap-1.5">
            {study.technologies.slice(0, 3).map((t) => (
              <li key={t} className="rounded-full border border-line px-2.5 py-0.5 text-xs text-fg-muted">
                {t}
              </li>
            ))}
          </ul>
          <ArrowUpRight
            className="size-5 shrink-0 text-fg-subtle transition-all group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-lime"
            aria-hidden
          />
        </div>
      </div>
    </Link>
  );
}
