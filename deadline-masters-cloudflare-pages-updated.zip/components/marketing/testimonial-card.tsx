import Image from "next/image";
import { Quote } from "lucide-react";
import type { Testimonial } from "@/lib/types/content";
import { cn, initials } from "@/lib/utils";

export function TestimonialCard({ testimonial, className }: { testimonial: Testimonial; className?: string }) {
  return (
    <figure className={cn("card flex h-full flex-col p-7", className)}>
      <Quote className="size-6 text-lime" aria-hidden />
      {testimonial.rating ? (
        <p className="mt-4 text-sm text-amber" aria-label={`Rated ${testimonial.rating} out of 5`}>
          {"★".repeat(testimonial.rating)}
          <span className="text-fg-subtle">{"★".repeat(5 - testimonial.rating)}</span>
        </p>
      ) : null}
      <blockquote className="mt-5 flex-1 text-lg leading-relaxed">“{testimonial.quote}”</blockquote>
      <figcaption className="mt-8 flex items-center gap-3">
        <div className="relative size-10 overflow-hidden rounded-full border border-line-strong bg-surface-2">
          {testimonial.avatarUrl ? (
            <Image src={testimonial.avatarUrl} alt="" fill sizes="40px" className="object-cover" />
          ) : (
            <span aria-hidden className="grid h-full place-items-center text-xs font-medium">
              {initials(testimonial.clientName)}
            </span>
          )}
        </div>
        <div>
          <p className="text-sm font-medium">{testimonial.clientName}</p>
          <p className="text-xs text-fg-muted">
            {[testimonial.clientRole, testimonial.company].filter(Boolean).join(", ")}
          </p>
        </div>
      </figcaption>
    </figure>
  );
}
