import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { SectionLabel } from "@/components/ui/section-heading";

/** Consistent inner-page header with grid backdrop. */
export function PageHeader({
  eyebrow,
  title,
  description,
  children,
  className,
}: {
  eyebrow: string;
  title: ReactNode;
  description?: ReactNode;
  children?: ReactNode;
  className?: string;
}) {
  return (
    <section className={cn("noise relative isolate overflow-hidden pt-36 pb-16 md:pt-44 md:pb-20", className)}>
      <div aria-hidden className="bg-grid bg-grid-fade absolute inset-0 -z-10" />
      <div
        aria-hidden
        className="absolute -top-32 right-0 -z-10 h-[420px] w-[620px] rounded-full bg-[radial-gradient(ellipse,rgb(98_225_232/0.08),transparent_65%)] blur-2xl"
      />
      <div className="container-page">
        <SectionLabel className="mb-6">{eyebrow}</SectionLabel>
        <h1 className="max-w-4xl text-4xl leading-[1.02] font-semibold tracking-[-0.04em] sm:text-6xl lg:text-7xl">
          {title}
        </h1>
        {description ? (
          <div className="mt-6 max-w-2xl text-lg leading-relaxed text-fg-muted sm:text-xl">{description}</div>
        ) : null}
        {children ? <div className="mt-10">{children}</div> : null}
      </div>
    </section>
  );
}
