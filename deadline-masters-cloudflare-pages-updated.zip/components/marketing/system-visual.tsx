"use client";

import { motion, useReducedMotion } from "framer-motion";

/**
 * Abstract "system map": four disciplines feeding one business core.
 * Decorative only (aria-hidden) — the same information is in the page copy.
 */
const nodes = [
  { id: "design", label: "Design", x: 70, y: 70, color: "var(--color-violet)" },
  { id: "engineering", label: "Engineering", x: 390, y: 70, color: "var(--color-cyan)" },
  { id: "growth", label: "Growth", x: 70, y: 290, color: "var(--color-amber)" },
  { id: "operations", label: "Operations", x: 390, y: 290, color: "var(--color-lime)" },
] as const;

const CX = 230;
const CY = 180;

function curve(x: number, y: number) {
  const mx = (x + CX) / 2;
  return `M ${x} ${y} C ${mx} ${y}, ${mx} ${CY}, ${CX} ${CY}`;
}

export function SystemVisual() {
  const reduce = useReducedMotion();

  return (
    <div aria-hidden className="relative">
      <svg viewBox="0 0 460 360" className="h-auto w-full" fill="none">
        <defs>
          <radialGradient id="core-glow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="rgb(200 243 74)" stopOpacity="0.35" />
            <stop offset="100%" stopColor="rgb(200 243 74)" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* concentric rings */}
        {[118, 86, 54].map((r, i) => (
          <motion.circle
            key={r}
            cx={CX}
            cy={CY}
            r={r}
            stroke="rgb(237 237 230 / 0.08)"
            strokeDasharray={i === 0 ? "2 6" : undefined}
            initial={reduce ? false : { opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2 + i * 0.1 }}
            style={{ transformOrigin: `${CX}px ${CY}px` }}
          />
        ))}

        {/* connections */}
        {nodes.map((n, i) => (
          <g key={n.id}>
            <motion.path
              d={curve(n.x, n.y)}
              stroke="rgb(237 237 230 / 0.18)"
              strokeWidth={1.2}
              initial={reduce ? false : { pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 1.2, delay: 0.5 + i * 0.12, ease: [0.16, 1, 0.3, 1] }}
            />
            {!reduce ? (
              <motion.circle
                r={3}
                fill={n.color}
                initial={{ offsetDistance: "0%", opacity: 0 }}
                animate={{ offsetDistance: "100%", opacity: [0, 1, 1, 0] }}
                transition={{
                  duration: 2.4,
                  delay: 1.8 + i * 0.6,
                  repeat: Infinity,
                  repeatDelay: 4.5,
                  ease: "easeInOut",
                }}
                style={{ offsetPath: `path("${curve(n.x, n.y)}")` }}
              />
            ) : null}
          </g>
        ))}

        {/* core */}
        <circle cx={CX} cy={CY} r={70} fill="url(#core-glow)" />
        <motion.g
          initial={reduce ? false : { opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          style={{ transformOrigin: `${CX}px ${CY}px` }}
        >
          <rect x={CX - 78} y={CY - 26} width={156} height={52} rx={14} fill="#0d0f12" stroke="rgb(200 243 74 / 0.6)" />
          <text
            x={CX}
            y={CY - 3}
            textAnchor="middle"
            fill="#edede6"
            fontSize="13"
            fontWeight="600"
            fontFamily="var(--font-sans)"
          >
            Your business
          </text>
          <text
            x={CX}
            y={CY + 13}
            textAnchor="middle"
            fill="#c8f34a"
            fontSize="8"
            letterSpacing="1.2"
            fontFamily="var(--font-mono)"
          >
            ONE PLAN · ONE TEAM
          </text>
        </motion.g>

        {/* discipline nodes */}
        {nodes.map((n, i) => (
          <motion.g
            key={`${n.id}-node`}
            initial={reduce ? false : { opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.9 + i * 0.1 }}
          >
            <rect
              x={n.x - 52}
              y={n.y - 17}
              width={104}
              height={34}
              rx={17}
              fill="#13161a"
              stroke="rgb(237 237 230 / 0.14)"
            />
            <circle cx={n.x - 36} cy={n.y} r={4} fill={n.color} />
            <text x={n.x - 26} y={n.y + 4} fill="#edede6" fontSize="11.5" fontFamily="var(--font-sans)">
              {n.label}
            </text>
          </motion.g>
        ))}
      </svg>
    </div>
  );
}
