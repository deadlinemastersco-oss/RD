import { Check, Minus } from "lucide-react";
import { ButtonLink } from "@/components/ui/button";
import type { PricingTier } from "@/lib/types/content";
import { cn, formatPrice } from "@/lib/utils";

export function PricingCard({ tier, className }: { tier: PricingTier; className?: string }) {
  return (
    <article
      className={cn(
        "relative flex h-full flex-col rounded-[var(--radius-card)] border p-7",
        tier.highlighted
          ? "border-lime/50 bg-[linear-gradient(180deg,rgb(200_243_74/0.08),rgb(200_243_74/0.01))] shadow-[0_0_60px_-20px_rgb(200_243_74/0.35)]"
          : "border-line bg-fg/[0.015]",
        className,
      )}
    >
      {tier.highlighted ? (
        <span className="label-mono absolute -top-3 left-7 rounded-full bg-lime px-3 py-1 !text-[0.62rem] text-ink">
          Recommended
        </span>
      ) : null}
      <h3 className="text-xl font-semibold tracking-tight">{tier.name}</h3>
      <p className="mt-2 text-sm text-fg-muted">{tier.tagline}</p>

      <div className="mt-7">
        <p className="label-mono text-fg-subtle">{tier.startingPrice === null ? "Pricing" : "Starting from"}</p>
        <p className="mt-2 text-4xl font-semibold tracking-tight">{formatPrice(tier.startingPrice)}</p>
        <p className="mt-1 text-xs text-fg-subtle">{tier.priceNote} · excl. taxes</p>
      </div>

      <dl className="mt-6 grid gap-3 border-y border-line py-5 text-sm">
        <div className="flex justify-between gap-4">
          <dt className="text-fg-subtle">Typical timeline</dt>
          <dd className="text-right">{tier.timeline}</dd>
        </div>
        <div>
          <dt className="text-fg-subtle">Best for</dt>
          <dd className="mt-1 text-fg-muted">{tier.bestFor}</dd>
        </div>
      </dl>

      <ul className="mt-6 flex-1 space-y-3 text-sm">
        {tier.includes.map((item) => (
          <li key={item} className="flex gap-2.5">
            <Check className="mt-0.5 size-4 shrink-0 text-lime" aria-hidden />
            <span>{item}</span>
          </li>
        ))}
        {tier.excludes?.map((item) => (
          <li key={item} className="flex gap-2.5 text-fg-subtle">
            <Minus className="mt-0.5 size-4 shrink-0" aria-hidden />
            <span>
              <span className="sr-only">Not included: </span>
              {item}
            </span>
          </li>
        ))}
      </ul>

      <ButtonLink href={tier.cta.href} variant={tier.highlighted ? "primary" : "outline"} className="mt-8 w-full">
        {tier.cta.label}
      </ButtonLink>
    </article>
  );
}
