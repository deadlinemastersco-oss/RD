import { Accent, SectionHeading } from "@/components/ui/section-heading";
import { Reveal, Stagger, StaggerItem } from "@/components/ui/reveal";
import { homeCopy } from "@/lib/constants/copy";

export function WhySection() {
  const { why } = homeCopy;
  return (
    <section
      className="relative overflow-hidden border-y border-line bg-surface/30 py-24 md:py-32"
      aria-labelledby="why-heading"
    >
      <div
        aria-hidden
        className="bg-grid absolute inset-0 [mask-image:linear-gradient(to_bottom,transparent,black_30%,black_70%,transparent)] opacity-40"
      />
      <div className="container-page relative grid gap-16 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <div className="lg:sticky lg:top-28">
            <SectionHeading
              index="02"
              eyebrow={why.eyebrow}
              title={
                <span id="why-heading">
                  One coordinated team <Accent>instead of</Accent> four disconnected vendors.
                </span>
              }
            />
            <Reveal delay={0.1}>
              <p className="mt-6 max-w-md text-lg leading-relaxed text-fg-muted">{why.intro}</p>
            </Reveal>
          </div>
        </div>

        <Stagger className="grid gap-4 sm:grid-cols-2 lg:col-span-7">
          {why.points.map((p, i) => (
            <StaggerItem key={p.title} className="card group relative overflow-hidden p-7">
              <span
                aria-hidden
                className="absolute top-4 right-6 font-serif text-7xl text-fg/[0.05] italic transition-colors group-hover:text-lime/15"
              >
                {i + 1}
              </span>
              <span aria-hidden className="block h-px w-10 bg-lime" />
              <h3 className="mt-6 text-xl font-semibold tracking-tight">{p.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-fg-muted">{p.body}</p>
            </StaggerItem>
          ))}
        </Stagger>
      </div>
    </section>
  );
}
