"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, CircleAlert, CircleCheck } from "lucide-react";
import { submitContact } from "@/lib/actions/public";
import { contactSchema, type ContactInput } from "@/lib/validations/public";
import { budgetOptions, serviceInterestOptions, timelineOptions } from "@/lib/constants/forms";
import { siteConfig } from "@/lib/constants/site";
import { Button } from "@/components/ui/button";
import { FormField, Honeypot, fieldAria } from "@/components/ui/form-field";
import { cn } from "@/lib/utils";

type FieldName = keyof ContactInput;

export function ContactForm() {
  const params = useSearchParams();
  const [status, setStatus] = useState<"idle" | "success" | "error">("idle");
  const [serverMessage, setServerMessage] = useState<string | null>(null);
  const [startedAt] = useState(() => Date.now());

  const preset = params.get("service");
  const presetValid = serviceInterestOptions.some((o) => o.value === preset);

  const {
    register,
    handleSubmit,
    setError,
    setValue,
    control,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<ContactInput>({
    resolver: zodResolver(contactSchema),
    mode: "onTouched",
    defaultValues: {
      full_name: "",
      email: "",
      phone: "",
      company: "",
      message: "",
      consent: false,
      company_website: "",
    },
  });

  useEffect(() => {
    if (presetValid && preset) setValue("service_interest", preset as ContactInput["service_interest"]);
  }, [preset, presetValid, setValue]);

  const messageLength = useWatch({ control, name: "message" })?.length ?? 0;

  async function onSubmit(values: ContactInput) {
    setServerMessage(null);
    try {
      const res = await submitContact({ ...values, started_at: startedAt });
      if (res.ok) {
        setStatus("success");
        setServerMessage(res.message ?? null);
        reset();
        return;
      }
      if (res.fieldErrors) {
        for (const [field, msgs] of Object.entries(res.fieldErrors)) {
          if (msgs?.[0]) setError(field as FieldName, { message: msgs[0] });
        }
      }
      setStatus("error");
      setServerMessage(res.message);
    } catch {
      setStatus("error");
      setServerMessage("We could not reach the server. Check your connection and try again.");
    }
  }

  const e = (name: FieldName) => errors[name]?.message as string | undefined;

  return (
    <AnimatePresence mode="wait" initial={false}>
      {status === "success" ? (
        <motion.div
          key="success"
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="card p-8 sm:p-10"
          role="status"
          aria-live="polite"
        >
          <div className="grid size-12 place-items-center rounded-2xl bg-success/15">
            <CircleCheck className="size-6 text-success" aria-hidden />
          </div>
          <h2 className="mt-6 text-2xl font-semibold tracking-tight">Message received.</h2>
          <p className="mt-3 max-w-lg text-fg-muted">
            {serverMessage ?? "Thank you — your message is with the team."} {siteConfig.contact.responseTime}
          </p>
          <ol className="mt-8 space-y-3 text-sm">
            {[
              "A specialist reads your message and checks fit.",
              "You get a reply with questions or a proposed call time.",
              "If we are a fit, you receive a written scope before any commitment.",
            ].map((s, i) => (
              <li key={s} className="flex gap-3">
                <span className="grid size-6 shrink-0 place-items-center rounded-full border border-line-strong font-mono text-[0.7rem] text-lime">
                  {i + 1}
                </span>
                <span className="pt-0.5 text-fg-muted">{s}</span>
              </li>
            ))}
          </ol>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button variant="outline" onClick={() => setStatus("idle")}>
              Send another message
            </Button>
            <Link href="/work" className="inline-flex h-11 items-center px-3 text-sm text-fg-muted hover:text-fg">
              Browse how we work <ArrowRight className="ml-1.5 size-4" aria-hidden />
            </Link>
          </div>
        </motion.div>
      ) : (
        <motion.form
          key="form"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onSubmit={handleSubmit(onSubmit)}
          noValidate
          className="card relative space-y-10 p-6 sm:p-10"
          aria-describedby={status === "error" ? "contact-server-error" : undefined}
        >
          <fieldset className="space-y-6">
            <legend className="label-mono mb-6 flex items-center gap-3 text-fg-muted">
              <span className="text-lime">[01]</span> About you
            </legend>
            <div className="grid gap-6 sm:grid-cols-2">
              <FormField id="full_name" label="Full name" required error={e("full_name")}>
                <input
                  className="field"
                  autoComplete="name"
                  {...fieldAria("full_name", e("full_name"))}
                  {...register("full_name")}
                />
              </FormField>
              <FormField id="email" label="Work email" required error={e("email")}>
                <input
                  className="field"
                  type="email"
                  autoComplete="email"
                  inputMode="email"
                  {...fieldAria("email", e("email"))}
                  {...register("email")}
                />
              </FormField>
              <FormField
                id="phone"
                label="Phone / WhatsApp"
                error={e("phone")}
                hint="Include country code for international numbers."
              >
                <input
                  className="field"
                  type="tel"
                  autoComplete="tel"
                  inputMode="tel"
                  {...fieldAria("phone", e("phone"), "Include country code for international numbers.")}
                  {...register("phone")}
                />
              </FormField>
              <FormField id="company" label="Company" error={e("company")}>
                <input
                  className="field"
                  autoComplete="organization"
                  {...fieldAria("company", e("company"))}
                  {...register("company")}
                />
              </FormField>
            </div>
          </fieldset>

          <fieldset className="space-y-6">
            <legend className="label-mono mb-6 flex items-center gap-3 text-fg-muted">
              <span className="text-lime">[02]</span> The project
            </legend>
            <FormField id="service_interest" label="What do you need help with?" required error={e("service_interest")}>
              <select
                className="field"
                defaultValue=""
                {...fieldAria("service_interest", e("service_interest"))}
                {...register("service_interest")}
              >
                <option value="" disabled>
                  Choose the closest option
                </option>
                {serviceInterestOptions.map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
              </select>
            </FormField>

            <div className="grid gap-6 sm:grid-cols-2">
              <FormField id="budget_range" label="Budget" required error={e("budget_range")}>
                <select
                  className="field"
                  defaultValue=""
                  {...fieldAria("budget_range", e("budget_range"))}
                  {...register("budget_range")}
                >
                  <option value="" disabled>
                    Select a range
                  </option>
                  {budgetOptions.map((o) => (
                    <option key={o.value} value={o.value}>
                      {o.label}
                    </option>
                  ))}
                </select>
              </FormField>
              <FormField id="deadline" label="Timeline" required error={e("deadline")}>
                <select
                  className="field"
                  defaultValue=""
                  {...fieldAria("deadline", e("deadline"))}
                  {...register("deadline")}
                >
                  <option value="" disabled>
                    When do you need it?
                  </option>
                  {timelineOptions.map((o) => (
                    <option key={o.value} value={o.value}>
                      {o.label}
                    </option>
                  ))}
                </select>
              </FormField>
            </div>

            <FormField
              id="message"
              label="What is going on?"
              required
              error={e("message")}
              hint="The problem, what you have tried, and what a good outcome looks like."
            >
              <textarea
                className="field min-h-40 resize-y"
                rows={6}
                {...fieldAria(
                  "message",
                  e("message"),
                  "The problem, what you have tried, and what a good outcome looks like.",
                )}
                {...register("message")}
              />
              <span
                className={cn(
                  "self-end font-mono text-[0.7rem]",
                  messageLength > 5000 ? "text-danger" : "text-fg-subtle",
                )}
              >
                {messageLength.toLocaleString()} / 5,000
              </span>
            </FormField>
          </fieldset>

          <Honeypot register={register("company_website")} />

          <div className="space-y-6 border-t border-line pt-8">
            <div>
              <label className="flex cursor-pointer items-start gap-3 text-sm text-fg-muted">
                <input
                  type="checkbox"
                  className="mt-0.5 size-4 shrink-0 cursor-pointer accent-lime"
                  aria-invalid={e("consent") ? true : undefined}
                  aria-describedby={e("consent") ? "consent-error" : undefined}
                  {...register("consent")}
                />
                <span>
                  I agree that Deadline Masters may store these details and contact me about this inquiry, as described
                  in the{" "}
                  <Link href="/privacy" className="text-fg underline underline-offset-4">
                    privacy policy
                  </Link>
                  .
                </span>
              </label>
              {e("consent") ? (
                <p id="consent-error" role="alert" className="mt-2 pl-7 text-xs font-medium text-danger">
                  {e("consent")}
                </p>
              ) : null}
            </div>

            {status === "error" && serverMessage ? (
              <div
                id="contact-server-error"
                role="alert"
                className="flex gap-3 rounded-xl border border-danger/30 bg-danger/10 p-4 text-sm"
              >
                <CircleAlert className="mt-0.5 size-4 shrink-0 text-danger" aria-hidden />
                <p>{serverMessage}</p>
              </div>
            ) : null}

            <div className="flex flex-col-reverse items-start gap-4 sm:flex-row sm:items-center sm:justify-between">
              <p className="text-xs text-fg-subtle">{siteConfig.contact.responseTime}</p>
              <Button type="submit" size="lg" loading={isSubmitting} className="w-full sm:w-auto">
                {isSubmitting ? "Sending…" : "Send message"}
                {!isSubmitting ? <ArrowRight className="size-4" aria-hidden /> : null}
              </Button>
            </div>
          </div>
        </motion.form>
      )}
    </AnimatePresence>
  );
}
