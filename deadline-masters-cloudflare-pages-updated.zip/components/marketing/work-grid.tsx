"use client";

import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { SearchX } from "lucide-react";
import { CaseStudyCard } from "@/components/marketing/case-study-card";
import { EmptyState } from "@/components/ui/empty-state";
import type { CaseStudy } from "@/lib/types/content";
import { cn } from "@/lib/utils";

type ServiceOption = { slug: string; title: string };

export function WorkGrid({ items, services }: { items: CaseStudy[]; services: ServiceOption[] }) {
  const [industry, setIndustry] = useState<string>("all");
  const [service, setService] = useState<string>("all");

  const industries = useMemo(() => Array.from(new Set(items.map((i) => i.industry))).sort(), [items]);
  const usedServices = useMemo(
    () => services.filter((s) => items.some((i) => i.services.includes(s.slug))),
    [items, services],
  );

  const filtered = items.filter(
    (i) => (industry === "all" || i.industry === industry) && (service === "all" || i.services.includes(service)),
  );

  return (
    <div>
      <div className="mb-10 flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
        <FilterGroup
          label="Industry"
          value={industry}
          onChange={setIndustry}
          options={industries.map((x) => ({ value: x, label: x }))}
        />
        <FilterGroup
          label="Service"
          value={service}
          onChange={setService}
          options={usedServices.map((s) => ({ value: s.slug, label: s.title }))}
        />
      </div>

      <p className="sr-only" aria-live="polite">
        {filtered.length} {filtered.length === 1 ? "item" : "items"} shown
      </p>

      {filtered.length ? (
        <motion.ul layout className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          <AnimatePresence mode="popLayout">
            {filtered.map((item) => (
              <motion.li
                key={item.slug}
                layout
                initial={{ opacity: 0, scale: 0.97 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.97 }}
                transition={{ duration: 0.25 }}
              >
                <CaseStudyCard study={item} />
              </motion.li>
            ))}
          </AnimatePresence>
        </motion.ul>
      ) : (
        <EmptyState
          icon={SearchX}
          title="Nothing matches those filters"
          description="Try a different industry or service."
          action={
            <button
              type="button"
              className="text-sm text-lime underline underline-offset-4"
              onClick={() => {
                setIndustry("all");
                setService("all");
              }}
            >
              Clear filters
            </button>
          }
        />
      )}
    </div>
  );
}

function FilterGroup({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
}) {
  return (
    <div role="group" aria-label={`Filter by ${label.toLowerCase()}`}>
      <p className="label-mono mb-3 text-fg-subtle">{label}</p>
      <div className="flex flex-wrap gap-2">
        {[{ value: "all", label: "All" }, ...options].map((o) => (
          <button
            key={o.value}
            type="button"
            aria-pressed={value === o.value}
            onClick={() => onChange(o.value)}
            className={cn(
              "rounded-full border px-3.5 py-1.5 text-sm transition-colors",
              value === o.value
                ? "border-lime bg-lime text-ink"
                : "border-line-strong text-fg-muted hover:border-fg/40 hover:text-fg",
            )}
          >
            {o.label}
          </button>
        ))}
      </div>
    </div>
  );
}
