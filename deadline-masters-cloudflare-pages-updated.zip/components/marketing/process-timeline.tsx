"use client";

import { useRef, useState } from "react";
import { motion, useMotionValueEvent, useScroll, useSpring } from "framer-motion";
import { Check } from "lucide-react";
import type { ProcessStep } from "@/lib/types/content";
import { cn } from "@/lib/utils";

/**
 * Vertical process timeline with a scroll-linked progress line.
 * `compact` shows summaries only (home page); `full` adds activities and outputs.
 */
export function ProcessTimeline({ steps, variant = "full" }: { steps: ProcessStep[]; variant?: "full" | "compact" }) {
  const ref = useRef<HTMLOListElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 70%", "end 60%"] });
  const scaleY = useSpring(scrollYProgress, { stiffness: 120, damping: 26, mass: 0.3 });
  const [activeIndex, setActiveIndex] = useState(0);

  useMotionValueEvent(scrollYProgress, "change", (v) => {
    const i = Math.min(steps.length - 1, Math.max(0, Math.floor(v * steps.length)));
    setActiveIndex(i);
  });

  return (
    <ol ref={ref} className="relative">
      {/* rail */}
      <div aria-hidden className="absolute top-2 bottom-2 left-[19px] w-px bg-line-strong md:left-[23px]" />
      <motion.div
        aria-hidden
        style={{ scaleY }}
        className="absolute top-2 bottom-2 left-[19px] w-px origin-top bg-gradient-to-b from-lime via-lime to-cyan shadow-[0_0_10px_rgb(200_243_74/0.6)] md:left-[23px]"
      />

      {steps.map((step, i) => {
        const reached = i <= activeIndex;
        return (
          <li
            key={step.id}
            className={cn(
              "relative grid grid-cols-[40px_1fr] gap-5 md:grid-cols-[48px_1fr] md:gap-8",
              variant === "full" ? "pb-16 last:pb-0" : "pb-10 last:pb-0",
            )}
          >
            <div
              className={cn(
                "relative z-10 grid size-10 place-items-center rounded-full border font-mono text-xs transition-all duration-500 md:size-12",
                reached ? "border-lime bg-lime text-ink" : "border-line-strong bg-ink text-fg-muted",
              )}
            >
              {reached && i < activeIndex ? <Check className="size-4" aria-hidden /> : step.index}
            </div>

            <div
              className={cn("pt-1.5 transition-opacity duration-500 md:pt-2.5", reached ? "opacity-100" : "opacity-55")}
            >
              <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1">
                <h3
                  className={cn(
                    "font-semibold tracking-tight",
                    variant === "full" ? "text-2xl md:text-3xl" : "text-xl",
                  )}
                >
                  {step.title}
                </h3>
                <span className="label-mono text-fg-subtle">{step.duration}</span>
              </div>
              <p className="mt-2 max-w-xl text-fg-muted">{step.summary}</p>

              {variant === "full" ? (
                <div className="mt-6 grid gap-4 md:grid-cols-5">
                  <div className="card p-5 md:col-span-3">
                    <p className="label-mono mb-3 text-fg-subtle">What happens</p>
                    <ul className="space-y-2 text-sm">
                      {step.activities.map((a) => (
                        <li key={a} className="flex gap-2">
                          <span aria-hidden className="mt-2 size-1 shrink-0 rounded-full bg-lime" />
                          {a}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="card p-5 md:col-span-2">
                    <p className="label-mono mb-3 text-fg-subtle">You receive</p>
                    <p className="text-sm">{step.output}</p>
                  </div>
                </div>
              ) : null}
            </div>
          </li>
        );
      })}
    </ol>
  );
}
