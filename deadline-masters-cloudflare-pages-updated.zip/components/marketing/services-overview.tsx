import { ArrowRight } from "lucide-react";
import { ButtonLink } from "@/components/ui/button";
import { Accent, SectionHeading } from "@/components/ui/section-heading";
import { Stagger, StaggerItem } from "@/components/ui/reveal";
import { ServiceCard } from "@/components/marketing/service-card";
import type { Service } from "@/lib/types/content";

export function ServicesOverview({ services }: { services: Service[] }) {
  return (
    <section
      id="capabilities"
      className="container-page scroll-mt-24 py-24 md:py-32"
      aria-labelledby="services-heading"
    >
      <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
        <SectionHeading
          index="01"
          eyebrow="Capabilities"
          title={
            <span id="services-heading">
              Seven disciplines. <Accent>One</Accent> accountable team.
            </span>
          }
          description="Pick a single capability or combine several. Either way, you get one plan, one point of contact and specialists who already work together."
        />
        <ButtonLink href="/services" variant="outline" className="shrink-0">
          All capabilities <ArrowRight className="size-4" aria-hidden />
        </ButtonLink>
      </div>

      <Stagger className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {services.map((s, i) => (
          <StaggerItem key={s.slug} className={i === 0 ? "lg:row-span-1" : undefined}>
            <ServiceCard service={s} index={i} />
          </StaggerItem>
        ))}
        <StaggerItem>
          <div className="flex h-full flex-col justify-between rounded-[var(--radius-card)] border border-dashed border-line-strong p-7">
            <div>
              <p className="label-mono text-lime">Not listed?</p>
              <p className="mt-4 text-xl font-semibold tracking-tight">Bring us the problem, not the job title.</p>
              <p className="mt-3 text-sm leading-relaxed text-fg-muted">
                Most engagements combine two or three disciplines. Describe what is stuck and we will tell you how we
                would approach it.
              </p>
            </div>
            <ButtonLink
              href="/diagnostic"
              variant="ghost"
              className="mt-8 self-start px-0 text-lime hover:bg-transparent hover:text-lime"
            >
              Run the diagnostic <ArrowRight className="size-4" aria-hidden />
            </ButtonLink>
          </div>
        </StaggerItem>
      </Stagger>
    </section>
  );
}
