"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { ArrowRight, CircleCheck } from "lucide-react";
import { subscribeNewsletter } from "@/lib/actions/public";
import { newsletterSchema, type NewsletterInput } from "@/lib/validations/public";
import { Honeypot } from "@/components/ui/form-field";
import { cn } from "@/lib/utils";

export function NewsletterForm({ source = "footer", className }: { source?: string; className?: string }) {
  const [done, setDone] = useState<string | null>(null);
  const [serverError, setServerError] = useState<string | null>(null);
  const [startedAt] = useState(() => Date.now());
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<NewsletterInput>({
    resolver: zodResolver(newsletterSchema),
    defaultValues: { email: "", source, company_website: "" },
  });

  async function onSubmit(values: NewsletterInput) {
    setServerError(null);
    const res = await subscribeNewsletter({ ...values, started_at: startedAt });
    if (res.ok) setDone(res.message ?? "You're on the list.");
    else setServerError(res.message);
  }

  if (done) {
    return (
      <p role="status" className={cn("flex items-center gap-2 text-sm text-success", className)}>
        <CircleCheck className="size-4" aria-hidden /> {done}
      </p>
    );
  }

  const errorMsg = errors.email?.message ?? serverError;

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className={cn("relative", className)}>
      <label htmlFor={`newsletter-${source}`} className="sr-only">
        Email address
      </label>
      <div className="flex items-center gap-2 rounded-full border border-line-strong bg-surface p-1.5 focus-within:border-lime focus-within:shadow-[0_0_0_3px_rgb(200_243_74/0.15)]">
        <input
          id={`newsletter-${source}`}
          type="email"
          autoComplete="email"
          placeholder="you@company.com"
          className="min-w-0 flex-1 bg-transparent px-3 text-sm outline-none placeholder:text-fg-subtle"
          aria-invalid={errorMsg ? true : undefined}
          aria-describedby={errorMsg ? `newsletter-${source}-error` : undefined}
          {...register("email")}
        />
        <button
          type="submit"
          disabled={isSubmitting}
          className="inline-flex h-9 items-center gap-1.5 rounded-full bg-fg px-4 text-sm font-medium text-ink transition hover:bg-white disabled:opacity-60"
        >
          {isSubmitting ? "Joining…" : "Subscribe"}
          <ArrowRight className="size-3.5" aria-hidden />
        </button>
      </div>
      <Honeypot register={register("company_website")} />
      {errorMsg ? (
        <p id={`newsletter-${source}-error`} role="alert" className="mt-2 pl-4 text-xs text-danger">
          {errorMsg}
        </p>
      ) : null}
    </form>
  );
}
