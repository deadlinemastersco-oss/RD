import { Accent, SectionHeading } from "@/components/ui/section-heading";
import { Stagger, StaggerItem } from "@/components/ui/reveal";
import { TeamCard } from "@/components/marketing/team-card";
import type { TeamMember } from "@/lib/types/content";

export function TeamSection({
  team,
  index = "03",
  title,
  description,
}: {
  team: TeamMember[];
  index?: string;
  title?: React.ReactNode;
  description?: string;
}) {
  return (
    <section className="container-page py-24 md:py-32" aria-labelledby="team-heading">
      <SectionHeading
        index={index}
        eyebrow="The team"
        title={
          <span id="team-heading">
            {title ?? (
              <>
                Four specialists. <Accent>Every</Accent> angle covered.
              </>
            )}
          </span>
        }
        description={
          description ??
          "Design, engineering, growth and operations — each led by a senior specialist, each involved from the first conversation."
        }
      />
      <Stagger className="mt-14 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {team.map((m, i) => (
          <StaggerItem key={m.id}>
            <TeamCard member={m} index={i} />
          </StaggerItem>
        ))}
      </Stagger>
    </section>
  );
}
