import Image from "next/image";
import type { TeamMember } from "@/lib/types/content";
import { cn, initials } from "@/lib/utils";

const accents = ["text-violet", "text-cyan", "text-amber", "text-lime"];

export function TeamCard({ member, index, className }: { member: TeamMember; index: number; className?: string }) {
  const accent = accents[index % accents.length];
  const links = Object.entries(member.socialLinks).filter(([, v]) => Boolean(v)) as [string, string][];

  return (
    <article className={cn("card group relative flex h-full flex-col overflow-hidden p-6", className)}>
      <div className="flex items-center justify-between">
        <span className={cn("label-mono", accent)}>Seat {String(index + 1).padStart(2, "0")}</span>
        <span className="label-mono text-fg-subtle">{member.discipline}</span>
      </div>

      <div className="relative mt-6 aspect-square overflow-hidden rounded-2xl border border-line bg-surface-2">
        {member.avatarUrl ? (
          <Image
            src={member.avatarUrl}
            alt={`Portrait of ${member.name}`}
            fill
            sizes="(min-width: 1024px) 22vw, (min-width: 640px) 45vw, 100vw"
            className="object-cover grayscale transition duration-500 group-hover:grayscale-0"
          />
        ) : (
          <div aria-hidden className="bg-grid absolute inset-0 grid place-items-center">
            <span className={cn("font-serif text-7xl italic", accent)}>{initials(member.name)}</span>
          </div>
        )}
      </div>

      <h3 className="mt-6 text-lg font-semibold tracking-tight">{member.name}</h3>
      <p className="mt-1 text-sm text-fg-muted">{member.role}</p>
      <p className="mt-4 text-sm leading-relaxed text-fg-muted">{member.shortBio}</p>

      <ul className="mt-5 flex flex-wrap gap-1.5" aria-label={`${member.name} skills`}>
        {member.skills.slice(0, 5).map((s) => (
          <li key={s} className="rounded-full border border-line px-2.5 py-0.5 text-xs text-fg-muted">
            {s}
          </li>
        ))}
      </ul>

      {links.length ? (
        <ul className="mt-5 flex gap-4 text-xs">
          {links.map(([k, href]) => (
            <li key={k}>
              <a
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                className="text-fg-muted capitalize hover:text-lime"
              >
                {k}
              </a>
            </li>
          ))}
        </ul>
      ) : null}
    </article>
  );
}
