import Link from "next/link";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { AnimatedText } from "@/components/ui/animated-text";
import { ButtonLink } from "@/components/ui/button";
import { MagneticButton } from "@/components/ui/magnetic-button";
import { Reveal } from "@/components/ui/reveal";
import { HeroBackground } from "@/components/marketing/hero-background";
import { SystemVisual } from "@/components/marketing/system-visual";
import { homeCopy } from "@/lib/constants/copy";
import { siteConfig } from "@/lib/constants/site";

export function Hero() {
  const { hero } = homeCopy;
  return (
    <section className="noise relative isolate overflow-hidden pt-32 pb-20 sm:pt-40 lg:pb-28">
      <HeroBackground />
      <div className="container-page relative">
        <Reveal y={10}>
          <p className="inline-flex items-center gap-2.5 rounded-full border border-line-strong bg-surface/70 py-1.5 pr-4 pl-2 text-xs text-fg-muted backdrop-blur">
            <span className="relative grid size-5 place-items-center rounded-full bg-lime/15">
              <span className="size-1.5 animate-pulse-dot rounded-full bg-lime" />
            </span>
            <span className="label-mono !text-[0.66rem]">{hero.eyebrow}</span>
          </p>
        </Reveal>

        <AnimatedText
          text={hero.headline}
          accent={hero.accentWord}
          className="mt-8 max-w-[15ch] text-[2.75rem] leading-[0.98] font-semibold tracking-[-0.045em] sm:text-7xl lg:text-[6.2rem]"
          delay={0.1}
        />

        <div className="mt-12 grid items-center gap-12 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <Reveal delay={0.5}>
              <p className="max-w-md text-lg leading-relaxed text-fg-muted sm:text-xl">{hero.subheadline}</p>
            </Reveal>
            <Reveal delay={0.65}>
              <div className="mt-9 flex flex-col gap-3 sm:flex-row sm:items-center">
                <MagneticButton>
                  <ButtonLink href={siteConfig.cta.primary.href} size="lg" className="w-full sm:w-auto">
                    {hero.primaryCta}
                    <ArrowUpRight
                      className="size-5 transition-transform group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5"
                      aria-hidden
                    />
                  </ButtonLink>
                </MagneticButton>
                <ButtonLink href={siteConfig.cta.secondary.href} variant="outline" size="lg">
                  {hero.secondaryCta}
                  <ArrowRight className="size-4 transition-transform group-hover/btn:translate-x-1" aria-hidden />
                </ButtonLink>
              </div>
              <p className="mt-6 text-sm text-fg-subtle">
                Not sure where to start?{" "}
                <Link
                  href="/diagnostic"
                  className="text-fg underline decoration-lime/60 underline-offset-4 hover:decoration-lime"
                >
                  Take the 2-minute diagnostic
                </Link>
                .
              </p>
            </Reveal>
          </div>

          <Reveal delay={0.35} className="lg:col-span-7">
            <div className="glass relative rounded-[1.75rem] border border-line-strong p-4 sm:p-6">
              <div className="mb-2 flex items-center justify-between px-1">
                <span className="label-mono text-fg-subtle">System map</span>
                <span className="label-mono flex items-center gap-2 text-fg-subtle">
                  <span className="size-1.5 rounded-full bg-lime" aria-hidden /> Coordinated delivery
                </span>
              </div>
              <SystemVisual />
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
