import type { ReactNode } from "react";
import { PageHeader } from "@/components/marketing/page-header";

export type LegalSection = { heading: string; body: ReactNode };

/**
 * Shared layout for legal pages. The copy in these pages is a sensible starting
 * template — have it reviewed by a qualified lawyer before launch.
 */
export function LegalPage({
  eyebrow,
  title,
  updated,
  intro,
  sections,
}: {
  eyebrow: string;
  title: string;
  updated: string;
  intro: ReactNode;
  sections: LegalSection[];
}) {
  return (
    <>
      <PageHeader eyebrow={eyebrow} title={title} description={<>Last updated {updated}</>} />
      <div className="container-page grid gap-12 pb-12 lg:grid-cols-12">
        <nav aria-label="Sections" className="hidden lg:col-span-3 lg:block">
          <ol className="sticky top-28 space-y-2 border-l border-line text-sm">
            {sections.map((s, i) => (
              <li key={s.heading}>
                <a
                  href={`#s-${i + 1}`}
                  className="-ml-px block border-l border-transparent pl-4 text-fg-muted hover:border-lime hover:text-fg"
                >
                  {s.heading}
                </a>
              </li>
            ))}
          </ol>
        </nav>
        <div className="max-w-3xl space-y-12 lg:col-span-9">
          <div className="text-lg leading-relaxed text-fg-muted">{intro}</div>
          {sections.map((s, i) => (
            <section key={s.heading} id={`s-${i + 1}`} className="scroll-mt-28">
              <h2 className="text-2xl font-semibold tracking-tight">
                <span className="mr-3 font-mono text-base text-lime">{String(i + 1).padStart(2, "0")}</span>
                {s.heading}
              </h2>
              <div className="mt-4 space-y-4 leading-relaxed text-fg-muted [&_a]:text-fg [&_a]:underline [&_a]:underline-offset-4 [&_li]:ml-5 [&_li]:list-disc [&_ul]:space-y-2">
                {s.body}
              </div>
            </section>
          ))}
        </div>
      </div>
    </>
  );
}
