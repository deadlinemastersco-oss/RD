import { MessageSquareQuote } from "lucide-react";
import { Accent, SectionHeading } from "@/components/ui/section-heading";
import { Stagger, StaggerItem } from "@/components/ui/reveal";
import { TestimonialCard } from "@/components/marketing/testimonial-card";
import { EmptyState } from "@/components/ui/empty-state";
import type { Testimonial } from "@/lib/types/content";

export function TestimonialsSection({ testimonials, index = "07" }: { testimonials: Testimonial[]; index?: string }) {
  return (
    <section className="container-page py-24 md:py-32" aria-labelledby="testimonials-heading">
      <SectionHeading
        index={index}
        eyebrow="Client voices"
        title={
          <span id="testimonials-heading">
            In their <Accent>own</Accent> words.
          </span>
        }
      />
      {testimonials.length ? (
        <Stagger className="mt-14 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((t) => (
            <StaggerItem key={t.id}>
              <TestimonialCard testimonial={t} />
            </StaggerItem>
          ))}
        </Stagger>
      ) : (
        <EmptyState
          className="mt-14"
          icon={MessageSquareQuote}
          title="Testimonials are publishing with permission"
          description="We only publish feedback that clients have explicitly approved for public use. Ask us for references during your first call."
        />
      )}
    </section>
  );
}
