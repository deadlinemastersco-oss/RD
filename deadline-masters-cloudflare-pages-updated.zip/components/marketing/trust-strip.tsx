import { CountUp } from "@/components/ui/count-up";
import { homeCopy } from "@/lib/constants/copy";

const disciplines = [
  "UI/UX design",
  "Next.js engineering",
  "SaaS & MVPs",
  "AI workflows",
  "Automation",
  "SEO & content",
  "Lead generation",
  "Operations",
  "Compliance coordination",
];

/** Honest trust indicators + discipline ticker (no fake logos). */
export function TrustStrip() {
  return (
    <section aria-label="At a glance" className="border-y border-line bg-surface/40">
      <div className="container-page">
        <dl className="grid grid-cols-2 divide-line lg:grid-cols-4 lg:divide-x">
          {homeCopy.trust.map((t, i) => (
            <div
              key={t.label}
              className={`flex flex-col-reverse px-4 py-8 sm:px-6 ${i % 2 === 1 ? "border-l border-line lg:border-l-0" : ""} ${i >= 2 ? "border-t border-line lg:border-t-0" : ""}`}
            >
              <dt className="mt-2 text-sm text-fg-muted">{t.label}</dt>
              <dd className="text-4xl font-semibold tracking-tight sm:text-5xl">
                <CountUp value={t.value} />
              </dd>
            </div>
          ))}
        </dl>
      </div>
      <div className="relative overflow-hidden border-t border-line py-4" aria-hidden>
        <div className="flex w-max animate-marquee gap-10 whitespace-nowrap motion-reduce:animate-none">
          {[...disciplines, ...disciplines].map((d, i) => (
            <span key={i} className="label-mono flex items-center gap-10 text-fg-subtle">
              {d} <span className="text-lime">✦</span>
            </span>
          ))}
        </div>
        <div className="pointer-events-none absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-ink to-transparent" />
        <div className="pointer-events-none absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-ink to-transparent" />
      </div>
    </section>
  );
}
