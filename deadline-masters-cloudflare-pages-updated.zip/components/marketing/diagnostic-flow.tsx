"use client";

import Link from "next/link";
import { useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, ArrowRight, CircleAlert, CircleCheck, RefreshCw } from "lucide-react";
import { submitDiagnostic } from "@/lib/actions/public";
import { diagnosticQuestions, type DiagnosticAnswers, type DiagnosticKey } from "@/lib/constants/forms";
import { fallbackServices } from "@/lib/constants/services";
import { pricingTiers } from "@/lib/constants/engagement";
import { recommend } from "@/lib/diagnostic";
import { diagnosticContactSchema, type DiagnosticContactInput } from "@/lib/validations/public";
import { Button, ButtonLink } from "@/components/ui/button";
import { FormField, Honeypot, fieldAria } from "@/components/ui/form-field";
import { ServiceIcon } from "@/components/ui/icon";
import { ProfessionalDisclaimer } from "@/components/marketing/professional-disclaimer";
import { cn, formatPrice } from "@/lib/utils";

const order: DiagnosticKey[] = ["problem", "urgency", "stage", "outcome"];
const TOTAL = order.length + 1; // + result/contact step

type Partial4 = Partial<DiagnosticAnswers>;

export function DiagnosticFlow() {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Partial4>({});
  const [direction, setDirection] = useState(1);
  const [done, setDone] = useState(false);
  const headingRef = useRef<HTMLHeadingElement>(null);

  const complete = order.every((k) => answers[k]);
  const rec = useMemo(() => (complete ? recommend(answers as DiagnosticAnswers) : null), [answers, complete]);

  function go(to: number) {
    setDirection(to > step ? 1 : -1);
    setStep(to);
    window.setTimeout(() => headingRef.current?.focus(), 50);
  }

  function choose(key: DiagnosticKey, value: string) {
    setAnswers((a) => ({ ...a, [key]: value }));
    // Advance automatically after a short beat so the selection is visible.
    window.setTimeout(() => go(Math.min(step + 1, order.length)), 220);
  }

  function restart() {
    setAnswers({});
    setDone(false);
    go(0);
  }

  const progress = done ? 100 : Math.round((step / TOTAL) * 100);

  return (
    <div className="card overflow-hidden">
      {/* progress */}
      <div className="flex items-center justify-between gap-4 border-b border-line px-6 py-4 sm:px-8">
        <p className="label-mono text-fg-muted">
          {done ? "Complete" : step < order.length ? `Step ${step + 1} of ${TOTAL}` : `Step ${TOTAL} of ${TOTAL}`}
        </p>
        <div
          className="h-1 w-40 overflow-hidden rounded-full bg-fg/10"
          role="progressbar"
          aria-label="Diagnostic progress"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={progress}
        >
          <motion.div
            className="h-full rounded-full bg-lime"
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.4 }}
          />
        </div>
      </div>

      <div className="relative min-h-[28rem] p-6 sm:p-8">
        <AnimatePresence mode="wait" custom={direction} initial={false}>
          {done ? (
            <motion.div key="done" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} role="status">
              <div className="grid size-12 place-items-center rounded-2xl bg-success/15">
                <CircleCheck className="size-6 text-success" aria-hidden />
              </div>
              <h2 ref={headingRef} tabIndex={-1} className="mt-6 text-2xl font-semibold tracking-tight outline-none">
                Your diagnostic is with the team.
              </h2>
              <p className="mt-3 max-w-lg text-fg-muted">
                A specialist will review your answers and reply within one business day with questions or a suggested
                next step.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <ButtonLink href="/services" variant="outline">
                  Explore services
                </ButtonLink>
                <Button variant="ghost" onClick={restart}>
                  <RefreshCw className="size-4" aria-hidden /> Start over
                </Button>
              </div>
            </motion.div>
          ) : step < order.length ? (
            <QuestionStep
              key={order[step]}
              direction={direction}
              questionKey={order[step]!}
              value={answers[order[step]!]}
              onChoose={choose}
              headingRef={headingRef}
            />
          ) : rec ? (
            <motion.div
              key="result"
              custom={direction}
              initial={{ opacity: 0, x: 24 * direction }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -24 * direction }}
              transition={{ duration: 0.3 }}
            >
              <ResultAndContact
                answers={answers as DiagnosticAnswers}
                rec={rec}
                headingRef={headingRef}
                onDone={() => setDone(true)}
              />
            </motion.div>
          ) : null}
        </AnimatePresence>
      </div>

      {!done ? (
        <div className="flex items-center justify-between border-t border-line px-6 py-4 sm:px-8">
          <Button variant="ghost" size="sm" onClick={() => go(step - 1)} disabled={step === 0}>
            <ArrowLeft className="size-4" aria-hidden /> Back
          </Button>
          {step < order.length ? (
            <Button variant="ghost" size="sm" onClick={() => go(step + 1)} disabled={!answers[order[step]!]}>
              Next <ArrowRight className="size-4" aria-hidden />
            </Button>
          ) : (
            <Button variant="ghost" size="sm" onClick={restart}>
              <RefreshCw className="size-4" aria-hidden /> Restart
            </Button>
          )}
        </div>
      ) : null}
    </div>
  );
}

function QuestionStep({
  questionKey,
  value,
  onChoose,
  direction,
  headingRef,
}: {
  questionKey: DiagnosticKey;
  value?: string;
  onChoose: (k: DiagnosticKey, v: string) => void;
  direction: number;
  headingRef: React.RefObject<HTMLHeadingElement | null>;
}) {
  const q = diagnosticQuestions[questionKey];
  return (
    <motion.fieldset
      initial={{ opacity: 0, x: 24 * direction }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -24 * direction }}
      transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
    >
      <legend className="sr-only">{q.title}</legend>
      <h2 ref={headingRef} tabIndex={-1} className="text-2xl font-semibold tracking-tight outline-none sm:text-3xl">
        {q.title}
      </h2>
      <p className="mt-2 text-fg-muted">{q.help}</p>
      <div className="mt-8 grid gap-3 sm:grid-cols-2">
        {q.options.map((o) => {
          const checked = value === o.value;
          const hint = "hint" in o ? o.hint : undefined;
          return (
            <label
              key={o.value}
              className={cn(
                "group relative flex cursor-pointer items-start gap-3 rounded-2xl border p-4 transition-all has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-lime",
                checked ? "border-lime bg-lime/[0.07]" : "border-line-strong hover:border-fg/30 hover:bg-fg/[0.02]",
              )}
            >
              <input
                type="radio"
                name={questionKey}
                value={o.value}
                checked={checked}
                onChange={() => onChoose(questionKey, o.value)}
                className="peer sr-only"
              />
              <span
                aria-hidden
                className={cn(
                  "mt-0.5 grid size-5 shrink-0 place-items-center rounded-full border transition-colors",
                  checked ? "border-lime bg-lime" : "border-line-strong",
                )}
              >
                {checked ? <span className="size-2 rounded-full bg-ink" /> : null}
              </span>
              <span>
                <span className="block font-medium">{o.label}</span>
                {hint ? <span className="mt-1 block text-sm text-fg-muted">{hint}</span> : null}
              </span>
            </label>
          );
        })}
      </div>
    </motion.fieldset>
  );
}

function ResultAndContact({
  answers,
  rec,
  headingRef,
  onDone,
}: {
  answers: DiagnosticAnswers;
  rec: ReturnType<typeof recommend>;
  headingRef: React.RefObject<HTMLHeadingElement | null>;
  onDone: () => void;
}) {
  const primary = fallbackServices.find((s) => s.slug === rec.primaryService);
  const supporting = rec.supportingServices
    .map((slug) => fallbackServices.find((s) => s.slug === slug))
    .filter((s): s is NonNullable<typeof s> => Boolean(s));
  const tier = pricingTiers.find((t) => t.id === rec.engagementTierId);
  const [serverError, setServerError] = useState<string | null>(null);
  const [startedAt] = useState(() => Date.now());

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<DiagnosticContactInput>({
    resolver: zodResolver(diagnosticContactSchema),
    defaultValues: { name: "", email: "", phone: "", company: "", notes: "", consent: false, company_website: "" },
  });

  async function onSubmit(values: DiagnosticContactInput) {
    setServerError(null);
    try {
      const res = await submitDiagnostic({ ...values, answers, started_at: startedAt });
      if (res.ok) return onDone();
      if (res.fieldErrors) {
        for (const [k, msgs] of Object.entries(res.fieldErrors)) {
          if (msgs?.[0] && k in values) setError(k as keyof DiagnosticContactInput, { message: msgs[0] });
        }
      }
      setServerError(res.message);
    } catch {
      setServerError("We could not reach the server. Check your connection and try again.");
    }
  }

  const e = (k: keyof DiagnosticContactInput) => errors[k]?.message as string | undefined;

  return (
    <div className="grid gap-10 lg:grid-cols-2">
      <div>
        <p className="label-mono text-lime">Recommended path</p>
        <h2
          ref={headingRef}
          tabIndex={-1}
          className="mt-3 text-2xl font-semibold tracking-tight outline-none sm:text-3xl"
        >
          {rec.headline}
        </h2>
        <p className="mt-3 text-fg-muted">{rec.rationale}</p>

        {primary ? (
          <Link
            href={`/services/${primary.slug}`}
            className="group mt-6 flex items-start gap-4 rounded-2xl border border-lime/40 bg-lime/[0.05] p-4 transition-colors hover:bg-lime/[0.09]"
          >
            <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-lime/15">
              <ServiceIcon name={primary.icon} className="size-5 text-lime" />
            </span>
            <span>
              <span className="label-mono text-fg-subtle">Lead discipline</span>
              <span className="mt-1 block font-medium group-hover:underline">{primary.title}</span>
              <span className="mt-1 block text-sm text-fg-muted">{primary.shortDescription}</span>
            </span>
          </Link>
        ) : null}

        {supporting.length ? (
          <div className="mt-4">
            <p className="label-mono mb-2 text-fg-subtle">Supported by</p>
            <ul className="flex flex-wrap gap-2">
              {supporting.map((s) => (
                <li key={s.slug}>
                  <Link
                    href={`/services/${s.slug}`}
                    className="inline-flex rounded-full border border-line-strong px-3 py-1 text-sm hover:border-fg/40"
                  >
                    {s.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ) : null}

        <div className="mt-6 space-y-4 text-sm">
          <div>
            <p className="label-mono mb-1 text-fg-subtle">Suggested pace</p>
            <p className="text-fg-muted">{rec.pace}</p>
          </div>
          {tier ? (
            <div>
              <p className="label-mono mb-1 text-fg-subtle">Typical investment</p>
              <p className="text-fg-muted">
                {tier.name}: {tier.startingPrice === null ? "custom quote" : `from ${formatPrice(tier.startingPrice)}`}{" "}
                · {tier.timeline}. Final pricing depends on scope.
              </p>
            </div>
          ) : null}
          <div>
            <p className="label-mono mb-2 text-fg-subtle">First steps</p>
            <ol className="space-y-2">
              {rec.firstSteps.map((s, i) => (
                <li key={s} className="flex gap-3 text-fg-muted">
                  <span className="font-mono text-lime">{i + 1}.</span>
                  {s}
                </li>
              ))}
            </ol>
          </div>
        </div>

        <p className="mt-6 text-xs leading-relaxed text-fg-subtle">
          This is an automated, rules-based suggestion to start a conversation. It is not legal, tax, financial or other
          professional advice.
        </p>
        {rec.needsProfessionalDisclaimer ? <ProfessionalDisclaimer compact className="mt-4" /> : null}
      </div>

      <form
        onSubmit={handleSubmit(onSubmit)}
        noValidate
        className="relative space-y-5 rounded-2xl border border-line-strong bg-surface-2/60 p-5 sm:p-6"
      >
        <div>
          <h3 className="text-lg font-semibold tracking-tight">Get a specialist&apos;s review</h3>
          <p className="mt-1 text-sm text-fg-muted">
            Share your details and we will reply with a considered next step.
          </p>
        </div>
        <FormField id="d-name" label="Name" required error={e("name")}>
          <input className="field" autoComplete="name" {...fieldAria("d-name", e("name"))} {...register("name")} />
        </FormField>
        <FormField id="d-email" label="Email" required error={e("email")}>
          <input
            className="field"
            type="email"
            autoComplete="email"
            {...fieldAria("d-email", e("email"))}
            {...register("email")}
          />
        </FormField>
        <div className="grid gap-5 sm:grid-cols-2">
          <FormField id="d-phone" label="Phone" error={e("phone")}>
            <input
              className="field"
              type="tel"
              autoComplete="tel"
              {...fieldAria("d-phone", e("phone"))}
              {...register("phone")}
            />
          </FormField>
          <FormField id="d-company" label="Company" error={e("company")}>
            <input
              className="field"
              autoComplete="organization"
              {...fieldAria("d-company", e("company"))}
              {...register("company")}
            />
          </FormField>
        </div>
        <FormField id="d-notes" label="Anything else we should know?" error={e("notes")}>
          <textarea className="field min-h-24" rows={3} {...fieldAria("d-notes", e("notes"))} {...register("notes")} />
        </FormField>
        <Honeypot register={register("company_website")} />
        <div>
          <label className="flex cursor-pointer items-start gap-3 text-sm text-fg-muted">
            <input
              type="checkbox"
              className="mt-0.5 size-4 shrink-0 accent-lime"
              aria-invalid={e("consent") ? true : undefined}
              aria-describedby={e("consent") ? "d-consent-error" : undefined}
              {...register("consent")}
            />
            <span>
              I agree to be contacted about this inquiry, per the{" "}
              <Link href="/privacy" className="text-fg underline underline-offset-4">
                privacy policy
              </Link>
              .
            </span>
          </label>
          {e("consent") ? (
            <p id="d-consent-error" role="alert" className="mt-2 pl-7 text-xs font-medium text-danger">
              {e("consent")}
            </p>
          ) : null}
        </div>
        {serverError ? (
          <div role="alert" className="flex gap-3 rounded-xl border border-danger/30 bg-danger/10 p-3 text-sm">
            <CircleAlert className="mt-0.5 size-4 shrink-0 text-danger" aria-hidden />
            <p>{serverError}</p>
          </div>
        ) : null}
        <Button type="submit" loading={isSubmitting} className="w-full">
          {isSubmitting ? "Sending…" : "Send for review"}
        </Button>
      </form>
    </div>
  );
}
