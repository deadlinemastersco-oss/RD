"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, Menu } from "lucide-react";
import { Logo } from "@/components/ui/logo";
import { ButtonLink } from "@/components/ui/button";
import { MagneticButton } from "@/components/ui/magnetic-button";
import { MobileNav } from "@/components/marketing/mobile-nav";
import { mainNav, siteConfig } from "@/lib/constants/site";
import { cn } from "@/lib/utils";

export function Navbar() {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const isActive = (href: string) => pathname === href || pathname.startsWith(`${href}/`);

  return (
    <>
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-50 transition-[background-color,border-color,backdrop-filter] duration-300",
          scrolled ? "glass border-b border-line" : "border-b border-transparent",
        )}
      >
        <nav aria-label="Main" className="container-page flex h-16 items-center justify-between gap-6 md:h-18">
          <Logo />

          <ul className="hidden items-center gap-1 lg:flex">
            {mainNav.map((item) => (
              <li key={item.href}>
                <Link
                  href={item.href}
                  aria-current={isActive(item.href) ? "page" : undefined}
                  className={cn(
                    "relative rounded-full px-4 py-2 text-sm transition-colors",
                    isActive(item.href) ? "text-fg" : "text-fg-muted hover:text-fg",
                  )}
                >
                  {isActive(item.href) ? (
                    <motion.span
                      layoutId="nav-active"
                      className="absolute inset-0 rounded-full bg-fg/[0.07]"
                      transition={{ type: "spring", stiffness: 380, damping: 32 }}
                    />
                  ) : null}
                  <span className="relative">{item.label}</span>
                </Link>
              </li>
            ))}
          </ul>

          <div className="flex items-center gap-2">
            <Link
              href="/diagnostic"
              className="hidden rounded-full px-4 py-2 text-sm text-fg-muted transition-colors hover:text-fg xl:inline-flex"
            >
              Free diagnostic
            </Link>
            <MagneticButton className="hidden sm:inline-flex">
              <ButtonLink href={siteConfig.cta.primary.href} size="sm" className="h-10 px-4">
                {siteConfig.cta.primary.label}
                <ArrowUpRight
                  className="size-4 transition-transform group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5"
                  aria-hidden
                />
              </ButtonLink>
            </MagneticButton>
            <button
              type="button"
              className="grid size-10 place-items-center rounded-full border border-line-strong text-fg lg:hidden"
              onClick={() => setOpen(true)}
              aria-label="Open menu"
              aria-expanded={open}
              aria-controls="mobile-nav"
            >
              <Menu className="size-5" aria-hidden />
            </button>
          </div>
        </nav>
      </header>
      <MobileNav open={open} onClose={() => setOpen(false)} />
    </>
  );
}
