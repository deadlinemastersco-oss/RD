import { ArrowUpRight } from "lucide-react";
import { ButtonLink } from "@/components/ui/button";
import { MagneticButton } from "@/components/ui/magnetic-button";
import { Reveal } from "@/components/ui/reveal";
import { homeCopy } from "@/lib/constants/copy";
import { siteConfig } from "@/lib/constants/site";

export function CTASection({
  title = homeCopy.finalCta.title,
  body = homeCopy.finalCta.body,
}: {
  title?: string;
  body?: string;
}) {
  return (
    <section className="container-page py-20 md:py-28" aria-labelledby="cta-heading">
      <Reveal>
        <div className="noise relative isolate overflow-hidden rounded-[2rem] border border-line-strong bg-surface px-6 py-16 text-center sm:px-12 md:py-24">
          <div aria-hidden className="bg-grid bg-grid-fade absolute inset-0 -z-10" />
          <div
            aria-hidden
            className="absolute -bottom-40 left-1/2 -z-10 h-80 w-[48rem] -translate-x-1/2 rounded-full bg-[radial-gradient(ellipse,rgb(200_243_74/0.18),transparent_65%)] blur-2xl"
          />
          <p className="label-mono text-lime">Next step</p>
          <h2
            id="cta-heading"
            className="mx-auto mt-5 max-w-3xl text-3xl leading-[1.05] font-semibold tracking-[-0.035em] sm:text-5xl"
          >
            {title}
          </h2>
          <p className="mx-auto mt-5 max-w-xl text-lg text-fg-muted">{body}</p>
          <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <MagneticButton>
              <ButtonLink href={siteConfig.cta.primary.href} size="lg">
                {siteConfig.cta.primary.label}
                <ArrowUpRight className="size-5" aria-hidden />
              </ButtonLink>
            </MagneticButton>
            <ButtonLink href="/diagnostic" variant="outline" size="lg">
              Run the free diagnostic
            </ButtonLink>
          </div>
          <p className="mt-6 text-sm text-fg-subtle">
            Or email{" "}
            <a href={`mailto:${siteConfig.contact.email}`} className="text-fg underline underline-offset-4">
              {siteConfig.contact.email}
            </a>
          </p>
        </div>
      </Reveal>
    </section>
  );
}
