import Link from "next/link";
import { ArrowUpRight, Clock, Globe, Mail, MapPin, Phone } from "lucide-react";
import { Logo } from "@/components/ui/logo";
import { NewsletterForm } from "@/components/marketing/newsletter-form";
import { footerNav, legalDisclaimer, siteConfig } from "@/lib/constants/site";

const socialLabels: Record<keyof typeof siteConfig.social, string> = {
  linkedin: "LinkedIn",
  x: "X (Twitter)",
  instagram: "Instagram",
  github: "GitHub",
};

export function Footer() {
  const year = new Date().getFullYear();
  const socials = (Object.keys(siteConfig.social) as (keyof typeof siteConfig.social)[]).filter(
    (k) => siteConfig.social[k],
  );

  return (
    <footer className="relative mt-24 border-t border-line bg-surface/40">
      <div className="container-page grid gap-12 py-16 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <Logo />
          <p className="mt-5 max-w-sm text-sm leading-relaxed text-fg-muted">{siteConfig.description}</p>
          <div className="mt-8 max-w-sm">
            <p className="label-mono mb-3 text-fg-muted">Field notes · monthly</p>
            <NewsletterForm source="footer" />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-8 sm:grid-cols-3 lg:col-span-7">
          <FooterColumn title="Company" links={footerNav.company} />
          <FooterColumn title="Capabilities" links={footerNav.capabilities} />
          <div className="col-span-2 sm:col-span-1">
            <FooterColumn title="Resources" links={footerNav.resources} />
            <div className="mt-8">
              <p className="label-mono mb-4 text-fg-subtle">Contact</p>
              <ul className="space-y-3 text-sm text-fg-muted">
                <li>
                  <a
                    href={`mailto:${siteConfig.contact.email}`}
                    className="inline-flex items-center gap-2 hover:text-fg"
                  >
                    <Mail className="size-4" aria-hidden /> {siteConfig.contact.email}
                  </a>
                </li>
                <li>
                  <a
                    href={`tel:${siteConfig.contact.phone.replace(/[^+\d]/g, "")}`}
                    className="inline-flex items-center gap-2 hover:text-fg"
                  >
                    <Phone className="size-4" aria-hidden /> {siteConfig.contact.phone}
                  </a>
                </li>
                <li>
                  <a
                    href={siteConfig.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 hover:text-fg"
                  >
                    <Globe className="size-4" aria-hidden /> deadline-masters.com
                  </a>
                </li>
                <li className="inline-flex items-start gap-2">
                  <MapPin className="mt-0.5 size-4 shrink-0" aria-hidden /> {siteConfig.contact.address}
                </li>
                <li className="inline-flex items-center gap-2">
                  <Clock className="size-4" aria-hidden /> {siteConfig.contact.hours}
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <div className="container-page">
        <div className="hairline-x" />
        <p className="py-6 text-xs leading-relaxed text-fg-subtle">
          <strong className="font-medium text-fg-muted">Professional-services disclaimer.</strong> {legalDisclaimer}
        </p>
        <div className="hairline-x" />
        <div className="flex flex-col gap-4 py-6 text-xs text-fg-subtle sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {year} {siteConfig.legalName}. All rights reserved.
          </p>
          <ul className="flex flex-wrap gap-x-5 gap-y-2">
            {footerNav.legal.map((l) => (
              <li key={l.href}>
                <Link href={l.href} className="hover:text-fg">
                  {l.label}
                </Link>
              </li>
            ))}
            {socials.map((k) => (
              <li key={k}>
                <a
                  href={siteConfig.social[k]}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 hover:text-fg"
                >
                  {socialLabels[k]} <ArrowUpRight className="size-3" aria-hidden />
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </footer>
  );
}

function FooterColumn({ title, links }: { title: string; links: readonly { label: string; href: string }[] }) {
  return (
    <div>
      <p className="label-mono mb-4 text-fg-subtle">{title}</p>
      <ul className="space-y-3 text-sm">
        {links.map((l) => (
          <li key={l.href}>
            <Link href={l.href} className="text-fg-muted transition-colors hover:text-fg">
              {l.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
