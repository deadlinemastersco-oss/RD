import { ArrowRight, Info } from "lucide-react";
import { ButtonLink } from "@/components/ui/button";
import { Accent, SectionHeading } from "@/components/ui/section-heading";
import { Stagger, StaggerItem } from "@/components/ui/reveal";
import { CaseStudyCard } from "@/components/marketing/case-study-card";
import type { CaseStudy } from "@/lib/types/content";

export function FeaturedWork({ items, fromDatabase }: { items: CaseStudy[]; fromDatabase: boolean }) {
  return (
    <section className="container-page py-24 md:py-32" aria-labelledby="work-heading">
      <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
        <SectionHeading
          index="04"
          eyebrow="Work"
          title={
            <span id="work-heading">
              How we <Accent>approach</Accent> real problems.
            </span>
          }
        />
        <ButtonLink href="/work" variant="outline" className="shrink-0">
          View all work <ArrowRight className="size-4" aria-hidden />
        </ButtonLink>
      </div>

      {!fromDatabase ? (
        <p className="mt-8 flex max-w-3xl items-start gap-3 rounded-2xl border border-line bg-surface/60 p-4 text-sm text-fg-muted">
          <Info className="mt-0.5 size-4 shrink-0 text-amber" aria-hidden />
          Client case studies are being prepared for publication with our clients&apos; permission. Until then, these
          illustrative blueprints show how we would approach common engagements — they are not client results.
        </p>
      ) : null}

      <Stagger className="mt-12 grid gap-6 md:grid-cols-2 xl:grid-cols-3">
        {items.slice(0, 3).map((s) => (
          <StaggerItem key={s.slug}>
            <CaseStudyCard study={s} />
          </StaggerItem>
        ))}
      </Stagger>
    </section>
  );
}
