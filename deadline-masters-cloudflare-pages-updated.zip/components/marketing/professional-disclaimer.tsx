import { Scale } from "lucide-react";
import { legalDisclaimer } from "@/lib/constants/site";
import { cn } from "@/lib/utils";

/** Visible notice for anything touching legal, tax, compliance or finance. */
export function ProfessionalDisclaimer({ className, compact }: { className?: string; compact?: boolean }) {
  return (
    <aside
      role="note"
      aria-label="Professional services disclaimer"
      className={cn("flex gap-3 rounded-2xl border border-amber/30 bg-amber/[0.06] p-4 text-sm", className)}
    >
      <Scale className="mt-0.5 size-4 shrink-0 text-amber" aria-hidden />
      <p className="leading-relaxed text-fg-muted">
        <strong className="font-medium text-fg">Important:</strong>{" "}
        {compact
          ? "Legal, tax and financial advice may require a licensed professional. We coordinate and support this work; regulated advice and filings are handled by qualified professionals."
          : legalDisclaimer}
      </p>
    </aside>
  );
}
