"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, X } from "lucide-react";
import { Logo } from "@/components/ui/logo";
import { ButtonLink } from "@/components/ui/button";
import { mainNav, siteConfig } from "@/lib/constants/site";
import { useIsClient } from "@/lib/use-is-client";

export function MobileNav({ open, onClose }: { open: boolean; onClose: () => void }) {
  const pathname = usePathname();
  const panelRef = useRef<HTMLDivElement>(null);
  const lastPath = useRef(pathname);
  const isClient = useIsClient();

  // Close on navigation.
  useEffect(() => {
    if (lastPath.current !== pathname) {
      lastPath.current = pathname;
      onClose();
    }
  }, [pathname, onClose]);

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    window.setTimeout(() => panelRef.current?.querySelector<HTMLElement>("a,button")?.focus(), 50);
    return () => {
      document.body.style.overflow = prev;
      document.removeEventListener("keydown", onKey);
    };
  }, [open, onClose]);

  if (!isClient) return null;

  return createPortal(
    <AnimatePresence>
      {open ? (
        <motion.div
          id="mobile-nav"
          ref={panelRef}
          role="dialog"
          aria-modal="true"
          aria-label="Site menu"
          className="fixed inset-0 z-[70] flex flex-col bg-ink lg:hidden"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
        >
          <div aria-hidden className="bg-grid bg-grid-fade pointer-events-none absolute inset-0" />
          <div className="container-page relative flex h-16 items-center justify-between">
            <Logo />
            <button
              type="button"
              onClick={onClose}
              className="grid size-10 place-items-center rounded-full border border-line-strong"
              aria-label="Close menu"
            >
              <X className="size-5" aria-hidden />
            </button>
          </div>
          <nav aria-label="Mobile" className="container-page relative flex flex-1 flex-col justify-between pt-8 pb-10">
            <ul className="space-y-1">
              {[...mainNav, { label: "Diagnostic", href: "/diagnostic" }, { label: "Contact", href: "/contact" }].map(
                (item, i) => (
                  <motion.li
                    key={item.href}
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.04 * i + 0.05, duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                  >
                    <Link
                      href={item.href}
                      onClick={onClose}
                      aria-current={pathname === item.href ? "page" : undefined}
                      className="group flex items-center justify-between border-b border-line py-4 text-3xl font-semibold tracking-tight aria-[current=page]:text-lime"
                    >
                      {item.label}
                      <ArrowRight
                        className="size-5 text-fg-subtle transition-transform group-hover:translate-x-1"
                        aria-hidden
                      />
                    </Link>
                  </motion.li>
                ),
              )}
            </ul>
            <div className="space-y-4 pt-10">
              <ButtonLink href={siteConfig.cta.primary.href} size="lg" className="w-full" onClick={onClose}>
                {siteConfig.cta.primary.label}
              </ButtonLink>
              <p className="text-center text-sm text-fg-muted">{siteConfig.contact.responseTime}</p>
            </div>
          </nav>
        </motion.div>
      ) : null}
    </AnimatePresence>,
    document.body,
  );
}
