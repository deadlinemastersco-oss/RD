"use client";

import Link from "next/link";
import { useRef } from "react";
import { ArrowUpRight, Check } from "lucide-react";
import { ServiceIcon } from "@/components/ui/icon";
import type { Service } from "@/lib/types/content";
import { cn, formatPrice } from "@/lib/utils";

/** Interactive service card: pointer-follow spotlight, lifts on hover, reveals highlights. */
export function ServiceCard({ service, index, className }: { service: Service; index: number; className?: string }) {
  const ref = useRef<HTMLAnchorElement>(null);

  function onMove(e: React.PointerEvent) {
    const el = ref.current;
    if (!el || e.pointerType !== "mouse") return;
    const r = el.getBoundingClientRect();
    el.style.setProperty("--sx", `${e.clientX - r.left}px`);
    el.style.setProperty("--sy", `${e.clientY - r.top}px`);
  }

  return (
    <Link
      ref={ref}
      href={`/services/${service.slug}`}
      onPointerMove={onMove}
      className={cn(
        "card group relative flex h-full flex-col overflow-hidden p-6 transition-[transform,border-color] duration-300 ease-out hover:-translate-y-1 hover:border-line-strong sm:p-7",
        className,
      )}
    >
      <span
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-100"
        style={{
          background:
            "radial-gradient(360px circle at var(--sx, 50%) var(--sy, 0%), rgb(200 243 74 / 0.08), transparent 60%)",
        }}
      />
      <div className="relative flex items-start justify-between">
        <div className="grid size-11 place-items-center rounded-xl border border-line-strong bg-surface-2 transition-colors group-hover:border-lime/40">
          <ServiceIcon name={service.icon} className="size-5 text-lime" />
        </div>
        <span className="label-mono text-fg-subtle">{String(index + 1).padStart(2, "0")}</span>
      </div>

      <h3 className="relative mt-8 text-xl font-semibold tracking-tight">{service.title}</h3>
      <p className="relative mt-3 text-sm leading-relaxed text-fg-muted">{service.shortDescription}</p>

      <ul className="relative mt-5 space-y-2">
        {service.whatWeDeliver.slice(0, 3).map((f) => (
          <li key={f} className="flex gap-2 text-sm text-fg-muted">
            <Check className="mt-0.5 size-4 shrink-0 text-lime/80" aria-hidden />
            <span>{f}</span>
          </li>
        ))}
      </ul>

      <div className="relative mt-auto flex items-end justify-between gap-4 pt-8">
        <div>
          <p className="label-mono text-fg-subtle">{service.startingPrice === null ? "Pricing" : "From"}</p>
          <p className="mt-1 font-medium">{formatPrice(service.startingPrice)}</p>
        </div>
        <span className="grid size-10 place-items-center rounded-full border border-line-strong transition-all duration-300 group-hover:border-lime group-hover:bg-lime group-hover:text-ink">
          <ArrowUpRight className="size-4" aria-hidden />
          <span className="sr-only">View {service.title}</span>
        </span>
      </div>
    </Link>
  );
}
