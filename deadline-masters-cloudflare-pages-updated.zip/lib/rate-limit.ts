import "server-only";

import { headers } from "next/headers";

/**
 * Minimal in-memory, fixed-window rate limiter for public forms.
 *
 * LIMITATION: memory is per server instance. On Vercel each function instance
 * keeps its own counters, so this is a speed bump, not a guarantee.
 * For production-grade limiting, swap `hit()` for Upstash Redis
 * (@upstash/ratelimit) or Vercel Firewall rules — see README → Security.
 */

type Bucket = { count: number; resetAt: number };
const buckets = new Map<string, Bucket>();
const MAX_KEYS = 5000;

export async function clientIp() {
  const h = await headers();
  const forwarded = h.get("x-forwarded-for");
  return (forwarded?.split(",")[0] ?? h.get("x-real-ip") ?? "unknown").trim();
}

export async function rateLimit(scope: string, limit: number, windowMs: number) {
  const ip = await clientIp();
  const key = `${scope}:${ip}`;
  const now = Date.now();

  if (buckets.size > MAX_KEYS) {
    for (const [k, b] of buckets) if (b.resetAt <= now) buckets.delete(k);
  }

  const bucket = buckets.get(key);
  if (!bucket || bucket.resetAt <= now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return { ok: true as const };
  }
  bucket.count += 1;
  if (bucket.count > limit) {
    return { ok: false as const, retryAfterSeconds: Math.ceil((bucket.resetAt - now) / 1000) };
  }
  return { ok: true as const };
}
