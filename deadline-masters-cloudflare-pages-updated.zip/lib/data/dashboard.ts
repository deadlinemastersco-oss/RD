import "server-only";

import { cache } from "react";
import { createClient } from "@/lib/supabase/server";
import type {
  ContactSubmissionRow,
  LeadStatus,
  NotificationRow,
  ProfileRow,
  ProjectInquiryRow,
  ProjectRow,
  ProjectTaskRow,
  SiteSettingRow,
  TaskPriority,
  TaskStatus,
  TeamMemberRow,
} from "@/lib/types/database";

/**
 * Dashboard queries. All run through the signed-in user's Supabase client, so
 * Row Level Security decides what each role can see.
 *
 * Every function returns `{ data, setupRequired }`. `setupRequired` is true when
 * Supabase is not configured or the tables do not exist yet (migrations not run),
 * so pages can show a friendly setup state instead of crashing.
 */

export type Result<T> = { data: T; setupRequired: boolean; error?: string };

const MISSING_TABLE_CODES = new Set(["42P01", "PGRST205", "PGRST204", "PGRST202"]);

function handle<T>(fallback: T, error: { code?: string; message: string } | null, data: T | null): Result<T> {
  if (error) {
    if (MISSING_TABLE_CODES.has(error.code ?? "")) return { data: fallback, setupRequired: true };
    console.error("[dashboard:query]", error.code, error.message);
    return { data: fallback, setupRequired: false, error: "Could not load data." };
  }
  return { data: data ?? fallback, setupRequired: false };
}

const noClient = <T>(fallback: T): Result<T> => ({ data: fallback, setupRequired: true });

export type Lead = {
  type: "contact" | "project";
  id: string;
  name: string;
  email: string;
  phone: string | null;
  company: string | null;
  topic: string | null;
  budget: string | null;
  timeline: string | null;
  message: string | null;
  source: string;
  status: LeadStatus;
  assigned_to: string | null;
  created_at: string;
  diagnostic?: ProjectInquiryRow["diagnostic"];
};

const fromContact = (r: ContactSubmissionRow): Lead => ({
  type: "contact",
  id: r.id,
  name: r.full_name,
  email: r.email,
  phone: r.phone,
  company: r.company,
  topic: r.service_interest,
  budget: r.budget_range,
  timeline: r.deadline,
  message: r.message,
  source: r.source,
  status: r.status,
  assigned_to: r.assigned_to,
  created_at: r.created_at,
});

const fromInquiry = (r: ProjectInquiryRow): Lead => ({
  type: "project",
  id: r.id,
  name: r.name,
  email: r.email,
  phone: r.phone,
  company: r.company,
  topic: r.recommended_service ?? r.project_type,
  budget: r.estimated_budget,
  timeline: r.desired_timeline,
  message: r.project_description,
  source: r.source,
  status: r.status,
  assigned_to: r.assigned_to,
  created_at: r.created_at,
  diagnostic: r.diagnostic,
});

/** Escape characters with special meaning in PostgREST `or` / `ilike` filters. */
function searchTerm(q: string) {
  return q
    .replace(/[%_,()*\\]/g, " ")
    .trim()
    .slice(0, 80);
}

export async function listLeads(opts: {
  type: "contact" | "project";
  q?: string;
  status?: LeadStatus | "all";
  limit?: number;
}): Promise<Result<Lead[]>> {
  const supabase = await createClient();
  if (!supabase) return noClient([]);
  const term = opts.q ? searchTerm(opts.q) : "";

  if (opts.type === "contact") {
    let query = supabase
      .from("contact_submissions")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(opts.limit ?? 200);
    if (opts.status && opts.status !== "all") query = query.eq("status", opts.status);
    if (term)
      query = query.or(
        `full_name.ilike.%${term}%,email.ilike.%${term}%,company.ilike.%${term}%,message.ilike.%${term}%`,
      );
    const { data, error } = await query;
    const r = handle<ContactSubmissionRow[]>([], error, data);
    return { ...r, data: r.data.map(fromContact) };
  }

  let query = supabase
    .from("project_inquiries")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(opts.limit ?? 200);
  if (opts.status && opts.status !== "all") query = query.eq("status", opts.status);
  if (term)
    query = query.or(
      `name.ilike.%${term}%,email.ilike.%${term}%,company.ilike.%${term}%,project_description.ilike.%${term}%`,
    );
  const { data, error } = await query;
  const r = handle<ProjectInquiryRow[]>([], error, data);
  return { ...r, data: r.data.map(fromInquiry) };
}

export const listStaff = cache(
  async (): Promise<Result<Pick<ProfileRow, "id" | "full_name" | "email" | "role" | "avatar_url">[]>> => {
    const supabase = await createClient();
    if (!supabase) return noClient([]);
    const { data, error } = await supabase
      .from("profiles")
      .select("id, full_name, email, role, avatar_url")
      .in("role", ["admin", "team_member"])
      .order("full_name", { ascending: true });
    return handle([], error, data);
  },
);

export async function listProfiles(): Promise<Result<ProfileRow[]>> {
  const supabase = await createClient();
  if (!supabase) return noClient([]);
  const { data, error } = await supabase.from("profiles").select("*").order("created_at", { ascending: true });
  return handle([], error, data);
}

export async function listProjects(opts: { status?: string; q?: string } = {}): Promise<Result<ProjectRow[]>> {
  const supabase = await createClient();
  if (!supabase) return noClient([]);
  let query = supabase
    .from("projects")
    .select("*")
    .order("due_date", { ascending: true, nullsFirst: false })
    .limit(200);
  if (opts.status && opts.status !== "all") query = query.eq("status", opts.status as ProjectRow["status"]);
  const term = opts.q ? searchTerm(opts.q) : "";
  if (term) query = query.or(`title.ilike.%${term}%,client_name.ilike.%${term}%`);
  const { data, error } = await query;
  return handle([], error, data);
}

export async function getProject(id: string): Promise<Result<{ project: ProjectRow | null; tasks: ProjectTaskRow[] }>> {
  const supabase = await createClient();
  if (!supabase) return noClient({ project: null, tasks: [] });
  const [p, t] = await Promise.all([
    supabase.from("projects").select("*").eq("id", id).maybeSingle(),
    supabase.from("project_tasks").select("*").eq("project_id", id).order("created_at", { ascending: true }),
  ]);
  if (p.error) return handle({ project: null, tasks: [] }, p.error, null);
  return { data: { project: p.data, tasks: t.data ?? [] }, setupRequired: false };
}

export type TaskWithProject = ProjectTaskRow & { project_title: string | null };

export async function listTasks(opts: {
  assignedTo?: string;
  status?: TaskStatus | "all" | "open";
  priority?: TaskPriority | "all";
  limit?: number;
}): Promise<Result<TaskWithProject[]>> {
  const supabase = await createClient();
  if (!supabase) return noClient([]);
  let query = supabase
    .from("project_tasks")
    .select("*")
    .order("due_date", { ascending: true, nullsFirst: false })
    .limit(opts.limit ?? 300);
  if (opts.assignedTo) query = query.eq("assigned_to", opts.assignedTo);
  if (opts.status === "open") query = query.neq("status", "done");
  else if (opts.status && opts.status !== "all") query = query.eq("status", opts.status);
  if (opts.priority && opts.priority !== "all") query = query.eq("priority", opts.priority);

  const { data, error } = await query;
  const r = handle<ProjectTaskRow[]>([], error, data);
  if (!r.data.length) return { ...r, data: [] };

  const ids = Array.from(new Set(r.data.map((t) => t.project_id)));
  const { data: projects } = await supabase.from("projects").select("id, title").in("id", ids);
  const titles = new Map((projects ?? []).map((p) => [p.id, p.title]));
  return { ...r, data: r.data.map((t) => ({ ...t, project_title: titles.get(t.project_id) ?? null })) };
}

export async function listNotifications(userId: string, limit = 20): Promise<Result<NotificationRow[]>> {
  const supabase = await createClient();
  if (!supabase) return noClient([]);
  const { data, error } = await supabase
    .from("notifications")
    .select("*")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })
    .limit(limit);
  return handle([], error, data);
}

export async function listSiteSettings(): Promise<Result<SiteSettingRow[]>> {
  const supabase = await createClient();
  if (!supabase) return noClient([]);
  const { data, error } = await supabase.from("site_settings").select("*").order("key");
  return handle([], error, data);
}

export async function listTeamMembersAdmin(): Promise<Result<TeamMemberRow[]>> {
  const supabase = await createClient();
  if (!supabase) return noClient([]);
  const { data, error } = await supabase.from("team_members").select("*").order("sort_order");
  return handle([], error, data);
}

export type Overview = {
  counts: {
    newLeads: number;
    openLeads: number;
    activeProjects: number;
    openTasks: number;
    overdueTasks: number;
    subscribers: number | null;
  };
  pipeline: { status: LeadStatus; count: number }[];
  weekly: { week: string; contact: number; project: number }[];
  recentLeads: Lead[];
  myTasks: TaskWithProject[];
  upcomingProjects: ProjectRow[];
};

const PIPELINE: LeadStatus[] = ["new", "contacted", "qualified", "proposal_sent", "won", "lost"];

function weekKey(d: Date) {
  const x = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
  const day = (x.getUTCDay() + 6) % 7; // Monday = 0
  x.setUTCDate(x.getUTCDate() - day);
  return x.toISOString().slice(0, 10);
}

export async function getOverview(userId: string, isAdmin: boolean): Promise<Result<Overview | null>> {
  const supabase = await createClient();
  if (!supabase) return noClient(null);

  const since = new Date(Date.now() - 7 * 8 * 86400000).toISOString();
  const today = new Date().toISOString().slice(0, 10);

  const [contacts, inquiries, projects, tasks, subs] = await Promise.all([
    supabase
      .from("contact_submissions")
      .select("*")
      .gte("created_at", since)
      .order("created_at", { ascending: false })
      .limit(500),
    supabase
      .from("project_inquiries")
      .select("*")
      .gte("created_at", since)
      .order("created_at", { ascending: false })
      .limit(500),
    supabase.from("projects").select("*").order("due_date", { ascending: true, nullsFirst: false }).limit(200),
    supabase
      .from("project_tasks")
      .select("*")
      .neq("status", "done")
      .order("due_date", { ascending: true, nullsFirst: false })
      .limit(500),
    isAdmin
      ? supabase.from("newsletter_subscribers").select("id", { count: "exact", head: true }).eq("is_subscribed", true)
      : Promise.resolve({ count: null, error: null }),
  ]);

  const firstError = contacts.error ?? inquiries.error ?? projects.error ?? tasks.error;
  if (firstError) return handle(null, firstError, null);

  const leads = [...(contacts.data ?? []).map(fromContact), ...(inquiries.data ?? []).map(fromInquiry)].sort((a, b) =>
    b.created_at.localeCompare(a.created_at),
  );

  const weeks: Overview["weekly"] = [];
  for (let i = 7; i >= 0; i--) {
    weeks.push({ week: weekKey(new Date(Date.now() - i * 7 * 86400000)), contact: 0, project: 0 });
  }
  const idx = new Map(weeks.map((w, i) => [w.week, i]));
  for (const l of leads) {
    const i = idx.get(weekKey(new Date(l.created_at)));
    if (i !== undefined) weeks[i]![l.type] += 1;
  }

  const openTasks = tasks.data ?? [];
  const projectRows = projects.data ?? [];
  const titles = new Map(projectRows.map((p) => [p.id, p.title]));

  return {
    data: {
      counts: {
        newLeads: leads.filter((l) => l.status === "new").length,
        openLeads: leads.filter((l) => !["won", "lost", "archived"].includes(l.status)).length,
        activeProjects: projectRows.filter((p) => ["planning", "active", "review"].includes(p.status)).length,
        openTasks: openTasks.length,
        overdueTasks: openTasks.filter((t) => t.due_date && t.due_date < today).length,
        subscribers: "count" in subs ? (subs.count ?? null) : null,
      },
      pipeline: PIPELINE.map((status) => ({ status, count: leads.filter((l) => l.status === status).length })),
      weekly: weeks,
      recentLeads: leads.slice(0, 6),
      myTasks: openTasks
        .filter((t) => t.assigned_to === userId)
        .slice(0, 6)
        .map((t) => ({ ...t, project_title: titles.get(t.project_id) ?? null })),
      upcomingProjects: projectRows.filter((p) => !["completed", "cancelled"].includes(p.status)).slice(0, 4),
    },
    setupRequired: false,
  };
}
