import "server-only";

import { cache } from "react";
import { createPublicClient } from "@/lib/supabase/public";
import { fallbackServices } from "@/lib/constants/services";
import { fallbackCaseStudies, fallbackTeam, fallbackTestimonials } from "@/lib/constants/people-and-work";
import type { CaseStudy, IconName, Service, ServiceCategory, TeamMember, Testimonial } from "@/lib/types/content";
import type { CaseStudyRow, Json, ServiceRow, TeamMemberRow, TestimonialRow } from "@/lib/types/database";

/**
 * Content layer for marketing pages.
 * Reads published rows from Supabase and falls back to the typed constants in
 * lib/constants/* when the database is not configured, unreachable or empty.
 * The site therefore always renders.
 */

const iconNames: IconName[] = [
  "globe",
  "layout-dashboard",
  "pen-tool",
  "workflow",
  "trending-up",
  "magnet",
  "shield-check",
  "zap",
  "layers",
  "compass",
];

function asObject(json: Json): Record<string, Json | undefined> {
  return json && typeof json === "object" && !Array.isArray(json) ? json : {};
}
function asString(v: Json | undefined): string | undefined {
  return typeof v === "string" && v.trim() ? v : undefined;
}
function asStringArray(v: Json | undefined): string[] | undefined {
  return Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : undefined;
}

function mapService(row: ServiceRow): Service {
  const base = fallbackServices.find((s) => s.slug === row.slug);
  const d = asObject(row.details);
  const processRaw = Array.isArray(d.process) ? d.process : undefined;
  const process = processRaw
    ?.map((p) => asObject(p ?? null))
    .map((p) => ({ title: asString(p.title) ?? "", description: asString(p.description) ?? "" }))
    .filter((p) => p.title);
  const icon = iconNames.includes(row.icon as IconName) ? (row.icon as IconName) : (base?.icon ?? "layers");
  const category = (asString(d.category) as ServiceCategory | undefined) ?? base?.category ?? "build";

  return {
    slug: row.slug,
    title: row.title,
    category,
    icon,
    shortDescription: row.short_description ?? base?.shortDescription ?? "",
    fullDescription: row.full_description ?? base?.fullDescription ?? row.short_description ?? "",
    problem: asString(d.problem) ?? base?.problem ?? "",
    idealClient: asString(d.idealClient) ?? base?.idealClient ?? "",
    whatWeDeliver: row.features.length ? row.features : (base?.whatWeDeliver ?? []),
    process: process?.length ? process : (base?.process ?? []),
    deliverables: asStringArray(d.deliverables) ?? base?.deliverables ?? [],
    timeline: row.delivery_time ?? base?.timeline ?? "Scoped per project",
    startingPrice: row.starting_price === null ? null : Number(row.starting_price),
    needsProfessionalDisclaimer: d.needsProfessionalDisclaimer === true || base?.needsProfessionalDisclaimer === true,
  };
}

function mapCaseStudy(row: CaseStudyRow): CaseStudy {
  return {
    slug: row.slug,
    title: row.title,
    clientName: row.client_name ?? "Confidential client",
    industry: row.industry ?? "General",
    services: row.service_slugs,
    summary: row.summary ?? "",
    challenge: row.challenge ?? "",
    approach: row.approach ?? "",
    solution: row.solution ?? "",
    outcome: row.outcome ?? "",
    technologies: row.technologies,
    coverImage: row.cover_image,
    gallery: row.gallery,
    isIllustrative: false,
    publishedAt: row.created_at,
  };
}

function mapTeamMember(row: TeamMemberRow): TeamMember {
  const links = asObject(row.social_links);
  const pick = (k: string) => asString(links[k]);
  return {
    id: row.id,
    name: row.name,
    role: row.role,
    discipline: row.role.split(/[&,·]/)[0]?.trim() ?? row.role,
    shortBio: row.short_bio ?? "",
    fullBio: row.full_bio ?? row.short_bio ?? "",
    avatarUrl: row.avatar_url,
    skills: row.skills,
    socialLinks: { linkedin: pick("linkedin"), x: pick("x"), github: pick("github"), website: pick("website") },
    isPlaceholder: false,
  };
}

function mapTestimonial(row: TestimonialRow): Testimonial {
  return {
    id: row.id,
    clientName: row.client_name,
    clientRole: row.client_role,
    company: row.company,
    quote: row.quote,
    avatarUrl: row.avatar_url,
    rating: row.rating,
  };
}

export const getServices = cache(async (): Promise<{ services: Service[]; fromDatabase: boolean }> => {
  const supabase = createPublicClient();
  if (!supabase) return { services: fallbackServices, fromDatabase: false };
  try {
    const { data, error } = await supabase
      .from("services")
      .select("*")
      .eq("is_active", true)
      .order("sort_order", { ascending: true });
    if (error || !data?.length) return { services: fallbackServices, fromDatabase: false };
    return { services: data.map(mapService), fromDatabase: true };
  } catch {
    return { services: fallbackServices, fromDatabase: false };
  }
});

export const getService = cache(async (slug: string) => {
  const { services } = await getServices();
  return services.find((s) => s.slug === slug) ?? null;
});

export const getCaseStudies = cache(async (): Promise<{ items: CaseStudy[]; fromDatabase: boolean }> => {
  const supabase = createPublicClient();
  if (!supabase) return { items: fallbackCaseStudies, fromDatabase: false };
  try {
    const { data, error } = await supabase
      .from("case_studies")
      .select("*")
      .eq("is_published", true)
      .order("created_at", { ascending: false });
    if (error || !data?.length) return { items: fallbackCaseStudies, fromDatabase: false };
    return { items: data.map(mapCaseStudy), fromDatabase: true };
  } catch {
    return { items: fallbackCaseStudies, fromDatabase: false };
  }
});

export const getCaseStudy = cache(async (slug: string) => {
  const { items } = await getCaseStudies();
  return items.find((c) => c.slug === slug) ?? null;
});

export const getTeam = cache(async (): Promise<TeamMember[]> => {
  const supabase = createPublicClient();
  if (!supabase) return fallbackTeam;
  try {
    const { data, error } = await supabase
      .from("team_members")
      .select("*")
      .eq("is_published", true)
      .order("sort_order", { ascending: true });
    if (error || !data?.length) return fallbackTeam;
    return data.map(mapTeamMember);
  } catch {
    return fallbackTeam;
  }
});

export const getTestimonials = cache(async (): Promise<Testimonial[]> => {
  const supabase = createPublicClient();
  if (!supabase) return fallbackTestimonials;
  try {
    const { data, error } = await supabase
      .from("testimonials")
      .select("*")
      .eq("is_published", true)
      .order("created_at", { ascending: false })
      .limit(12);
    if (error || !data?.length) return fallbackTestimonials;
    return data.map(mapTestimonial);
  } catch {
    return fallbackTestimonials;
  }
});
