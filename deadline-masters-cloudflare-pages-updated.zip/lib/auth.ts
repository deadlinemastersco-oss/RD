import "server-only";

import { cache } from "react";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import type { ProfileRow, UserRole } from "@/lib/types/database";

export type SessionUser = {
  id: string;
  email: string | null;
  profile: ProfileRow | null;
  role: UserRole;
};

/**
 * Returns the signed-in user verified against Supabase Auth (getUser performs a
 * network check — never trust getSession() for authorization on the server),
 * plus their profile and role from the database. Deduplicated per request.
 */
export const getSessionUser = cache(async (): Promise<SessionUser | null> => {
  const supabase = await createClient();
  if (!supabase) return null;

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();
  if (error || !user) return null;

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle();

  return {
    id: user.id,
    email: user.email ?? null,
    profile: profile ?? null,
    // Role always comes from the database, never from user metadata or the client.
    role: profile?.role ?? "viewer",
  };
});

export const roleRank: Record<UserRole, number> = { viewer: 0, team_member: 1, admin: 2 };

export function hasRole(user: Pick<SessionUser, "role"> | null, minimum: UserRole) {
  return !!user && roleRank[user.role] >= roleRank[minimum];
}

/** Server-side guard for pages. Redirects instead of rendering protected content. */
export async function requireUser(minimum: UserRole = "viewer", next = "/dashboard") {
  const user = await getSessionUser();
  if (!user) redirect(`/auth/sign-in?next=${encodeURIComponent(next)}`);
  if (!hasRole(user, minimum)) redirect("/dashboard?denied=1");
  return user;
}

/** Guard for Server Actions: returns null instead of redirecting. */
export async function authorize(minimum: UserRole) {
  const user = await getSessionUser();
  if (!user || !hasRole(user, minimum)) return null;
  return user;
}
