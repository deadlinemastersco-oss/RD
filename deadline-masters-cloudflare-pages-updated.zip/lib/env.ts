/**
 * Public environment access.
 *
 * Supabase issues two kinds of browser-safe keys:
 *  - the newer "publishable" key  (sb_publishable_...) → NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY
 *  - the legacy "anon" JWT key                          → NEXT_PUBLIC_SUPABASE_ANON_KEY
 * Either works. The publishable key wins when both are set.
 *
 * NEVER read SUPABASE_SERVICE_ROLE_KEY here — see lib/supabase/admin.ts (server-only).
 */

export const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "";

export const supabasePublicKey =
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "";

/** True when the public Supabase URL and a browser-safe key are both present. */
export const isSupabaseConfigured = Boolean(supabaseUrl && supabasePublicKey);

export const siteUrl = (process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000").replace(/\/$/, "");
