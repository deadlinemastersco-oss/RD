import type { FAQ, PricingTier, ProcessStep } from "@/lib/types/content";

export const processSteps: ProcessStep[] = [
  {
    id: "discovery",
    index: "01",
    title: "Discovery",
    summary: "We learn the business before we touch the brief.",
    activities: [
      "Kick-off call with decision makers",
      "Goals, constraints and deadline review",
      "Access to existing tools and data",
    ],
    output: "Shared understanding of the goal and what success looks like",
    duration: "1–3 days",
  },
  {
    id: "diagnosis",
    index: "02",
    title: "Diagnosis",
    summary: "We find the real problem, which is not always the one in the brief.",
    activities: [
      "Audit of current systems, site or process",
      "Stakeholder and user conversations",
      "Risk and dependency mapping",
    ],
    output: "Written diagnosis with prioritised findings",
    duration: "2–5 days",
  },
  {
    id: "strategy",
    index: "03",
    title: "Strategy",
    summary: "One plan, agreed in writing, with scope and trade-offs visible.",
    activities: ["Scope and success criteria", "Milestones, owners and dependencies", "Fixed quote or phased estimate"],
    output: "Signed scope, timeline and responsibilities",
    duration: "2–4 days",
  },
  {
    id: "design",
    index: "04",
    title: "Design",
    summary: "Structure first, visuals second, approval before build.",
    activities: ["Flows and wireframes", "Visual design and content", "Review rounds with your team"],
    output: "Approved designs and content",
    duration: "1–3 weeks",
  },
  {
    id: "build",
    index: "05",
    title: "Build",
    summary: "Weekly demos on a live staging link — you see progress, not promises.",
    activities: ["Engineering in short cycles", "Integrations and automation", "Testing on real devices and data"],
    output: "Working, tested system on staging",
    duration: "1–8 weeks",
  },
  {
    id: "launch",
    index: "06",
    title: "Launch",
    summary: "Careful release, documented handover, nothing left in our heads.",
    activities: ["Production deployment and checks", "Analytics and monitoring", "Handover session and documentation"],
    output: "Live system your team owns",
    duration: "1–3 days",
  },
  {
    id: "optimization",
    index: "07",
    title: "Optimization",
    summary: "We measure what happened and improve what matters.",
    activities: ["Post-launch review", "Usage and conversion analysis", "Prioritised improvement backlog"],
    output: "Evidence-based next steps",
    duration: "Ongoing",
  },
];

export const pricingTiers: PricingTier[] = [
  {
    id: "quick-fix",
    name: "Quick Fix",
    tagline: "One urgent problem, solved properly.",
    startingPrice: 25000,
    priceNote: "per fix",
    timeline: "2–10 working days",
    bestFor: "A broken form, slow page, failed integration, urgent landing page or a single automation.",
    includes: [
      "Diagnosis call and written fix plan",
      "Implementation by the relevant specialist",
      "Testing and a short handover note",
      "7 days of post-fix support",
    ],
    excludes: ["Full redesigns", "New multi-page builds"],
    cta: { label: "Request a quick fix", href: "/contact?service=quick-fix" },
  },
  {
    id: "growth-system",
    name: "Business Growth System",
    tagline: "Website, pipeline and content working as one.",
    startingPrice: 150000,
    priceNote: "per project",
    timeline: "4–8 weeks",
    bestFor: "Established businesses that need a credible website, a working lead pipeline and a content engine.",
    includes: [
      "Positioning and site architecture",
      "Custom-designed, fast website",
      "Lead capture wired into a pipeline dashboard",
      "Technical SEO and analytics",
      "Content plan and first publishing sprint",
    ],
    cta: { label: "Plan a growth system", href: "/contact?service=growth-system" },
    highlighted: true,
  },
  {
    id: "saas-mvp",
    name: "SaaS / MVP Launch",
    tagline: "A real first release, not a throwaway prototype.",
    startingPrice: 400000,
    priceNote: "per release",
    timeline: "6–12 weeks",
    bestFor: "Founders and teams launching a product or replacing spreadsheets with an internal platform.",
    includes: [
      "Scope workshop and MVP definition",
      "Product design for core flows",
      "Next.js + Supabase build with auth and roles",
      "Admin dashboard and reporting",
      "Production deployment and documentation",
    ],
    cta: { label: "Scope an MVP", href: "/contact?service=saas-mvp" },
  },
  {
    id: "custom-mission",
    name: "Custom Mission",
    tagline: "Multi-disciplinary work, scoped around you.",
    startingPrice: null,
    priceNote: "scoped per engagement",
    timeline: "Scoped per engagement",
    bestFor: "Combined technology, growth and operations work, or an ongoing retainer with the full team.",
    includes: [
      "Dedicated coordination across all four specialists",
      "Phased roadmap with milestones",
      "Monthly or milestone-based billing",
      "Licensed professionals engaged for regulated work",
    ],
    cta: { label: "Discuss a custom mission", href: "/contact?service=custom" },
  },
];

export const pricingNotes = [
  "All prices are starting points in INR and exclude applicable taxes (GST where applicable).",
  "Final pricing depends on scope, integrations, content readiness and timeline, and is confirmed in a written proposal before any work begins.",
  "International clients can be invoiced in USD, GBP, EUR or AED on request.",
  "Third-party costs — hosting, domains, paid tools, licences and fees of licensed professionals — are billed at cost or paid directly by you.",
];

export const faqs: FAQ[] = [
  {
    question: "What does Deadline Masters actually do?",
    answer:
      "We are a four-specialist team covering product design, full-stack development, digital growth and automation, and business operations. We take on problems that cross those boundaries — for example, a website that needs a new design, a lead pipeline and follow-up automation — and deliver them as one coordinated project.",
  },
  {
    question: "How quickly can you start?",
    answer:
      "For Quick Fix work we can usually begin within a few working days. Larger projects typically start within one to two weeks of a signed scope. We will tell you honestly if we cannot meet your deadline rather than accept work we cannot deliver well.",
  },
  {
    question: "Do you work with clients outside India?",
    answer:
      "Yes. We are based in India and work with international clients across time zones, with overlap hours agreed at kick-off and invoicing available in major currencies.",
  },
  {
    question: "Are you a law firm or a chartered accountancy?",
    answer:
      "No. We provide documentation, process design and coordination support for legal, finance and compliance work. Anything that requires a licence — legal advice, tax filings, audits, regulated financial advice — is handled by qualified professionals, either your existing advisors or trusted professionals we coordinate with.",
  },
  {
    question: "Who owns the code, designs and accounts?",
    answer:
      "You do. Code lives in your repository, designs in your workspace and services in accounts registered to your business. Ownership transfers on payment of the relevant invoice.",
  },
  {
    question: "How do you price projects?",
    answer:
      "Most projects are fixed-price against a written scope. Ongoing work is billed monthly. The prices on this site are starting points; you receive a detailed proposal before committing to anything.",
  },
  {
    question: "What happens after launch?",
    answer:
      "Every project includes a handover and a short support window. After that you can continue on a monthly optimisation plan, book Quick Fixes as needed, or run everything in-house with our documentation.",
  },
  {
    question: "Do you use AI in your work?",
    answer:
      "Yes, where it genuinely helps — drafting, research, data extraction and automation — always with human review. We will not put AI-generated output in front of your customers without checking it, and we tell you where AI is used.",
  },
];
