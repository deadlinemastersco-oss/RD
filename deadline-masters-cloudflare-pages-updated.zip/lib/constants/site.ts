/**
 * Central brand + contact configuration.
 *
 * Everything a non-developer is likely to change lives here:
 * contact details, social links, legal entity name and currency.
 * Replace the placeholder values before launch (see SETUP.md → "Replace placeholder details").
 */

export const siteConfig = {
  name: process.env.NEXT_PUBLIC_APP_NAME || "Deadline Masters",
  shortName: "Deadline Masters",
  concept: "Digital execution task force",
  tagline: "Digital systems for businesses that cannot afford to slow down.",
  description:
    "Deadline Masters is a four-specialist digital execution team. We design, build, automate and improve the technology and digital operations behind ambitious businesses.",
  url: (process.env.NEXT_PUBLIC_SITE_URL || "https://deadline-masters.com").replace(/\/$/, ""),
  locale: "en_IN",

  /** Legal entity shown in the footer and legal pages. */
  legalName: "Deadline Masters",
  foundedYear: 2024,

  contact: {
    email: "Deadlinemasters.co@gmail.com",
    phone: "+1 (637) 377-8543",
    whatsapp: "",
    city: "Springfield, IL, United States",
    address: "742 Evergreen Terrace, Springfield, IL 62704, United States",
    hours: "Mon–Sat · 10:00–19:00 IST",
    responseTime: "We reply to every inquiry within one business day.",
  },

  /** Leave a value empty to hide that link everywhere. */
  social: {
    linkedin: "",
    x: "",
    instagram: "",
    github: "",
  },

  cta: {
    primary: { label: "Start a Project", href: "/contact" },
    secondary: { label: "Explore Capabilities", href: "/services" },
  },

  currency: {
    code: "INR",
    locale: "en-IN",
  },

  /** Set to true only once you have real, permissioned client testimonials in Supabase. */
  showTestimonialsSection: true,
} as const;

export type SiteConfig = typeof siteConfig;

export const mainNav = [
  { label: "Services", href: "/services" },
  { label: "Work", href: "/work" },
  { label: "Process", href: "/process" },
  { label: "Pricing", href: "/pricing" },
  { label: "About", href: "/about" },
] as const;

export const footerNav = {
  company: [
    { label: "About", href: "/about" },
    { label: "Process", href: "/process" },
    { label: "Work", href: "/work" },
    { label: "Contact", href: "/contact" },
  ],
  capabilities: [
    { label: "Websites & web apps", href: "/services/websites-and-web-applications" },
    { label: "SaaS & MVPs", href: "/services/saas-dashboards-and-mvp-development" },
    { label: "UI/UX & product design", href: "/services/ui-ux-and-product-design" },
    { label: "AI workflows & automation", href: "/services/ai-workflow-and-business-automation" },
    { label: "SEO & digital growth", href: "/services/seo-content-and-digital-growth" },
  ],
  resources: [
    { label: "Pricing", href: "/pricing" },
    { label: "Project diagnostic", href: "/diagnostic" },
    { label: "Team sign in", href: "/auth/sign-in" },
  ],
  legal: [
    { label: "Privacy policy", href: "/privacy" },
    { label: "Terms of service", href: "/terms" },
    { label: "Disclaimer", href: "/disclaimer" },
  ],
} as const;

export const legalDisclaimer =
  "Deadline Masters is not a law firm, chartered accountancy or registered investment advisor. Legal, tax, compliance and financial work is provided as documentation, coordination and advisory support, and is delivered through qualified, licensed professionals wherever the law requires. Nothing on this website is legal, tax or financial advice.";
