/**
 * Editorial copy for marketing pages. Edit wording here without touching components.
 */

export const homeCopy = {
  hero: {
    eyebrow: "Digital execution team · India → worldwide",
    headline: "Digital systems for businesses that cannot afford to slow down.",
    accentWord: "cannot afford",
    subheadline:
      "We design, build, automate, and improve the technology and digital operations behind ambitious businesses.",
    primaryCta: "Start a Project",
    secondaryCta: "Explore Capabilities",
  },
  /** Honest, verifiable indicators — no invented client counts or results. */
  trust: [
    { value: "4", label: "Senior specialists, one accountable team" },
    { value: "1", label: "Business day to reply to every inquiry" },
    { value: "100%", label: "Of code, designs and accounts owned by you" },
    { value: "7", label: "Disciplines under one written scope" },
  ],
  why: {
    eyebrow: "Why Deadline Masters",
    title: "One coordinated team instead of four disconnected vendors.",
    intro:
      "Most business problems do not respect job titles. A slow website is also a sales problem. A messy pipeline is also an operations problem. We solve them together.",
    points: [
      {
        title: "One scope, one owner",
        body: "Design, engineering, growth and operations work from a single written plan with a single point of contact. No hand-offs between agencies.",
      },
      {
        title: "Deadlines treated as commitments",
        body: "We plan backwards from your date, surface risks early and tell you the moment something threatens delivery — not the day before.",
      },
      {
        title: "Built to be owned by you",
        body: "Clean code in your repository, documentation your team can follow, and accounts in your name. You are never locked in.",
      },
      {
        title: "Honest about limits",
        body: "When work needs a licensed lawyer, accountant or advisor, we say so and bring them in. We do not stretch beyond what we are qualified to do.",
      },
    ],
  },
  finalCta: {
    title: "Tell us what is stuck. We will tell you how we would fix it.",
    body: "Share the problem and the deadline. Within one business day you will get a candid reply — including when we are not the right fit.",
  },
} as const;

export const aboutCopy = {
  story: {
    eyebrow: "Our story",
    title: "Built by specialists who were tired of watching good businesses wait.",
    paragraphs: [
      "Deadline Masters started from a simple observation: businesses rarely have a single problem. A new product needs design, engineering and a launch plan. A growth push needs a website, a pipeline and someone keeping operations in order. Yet most companies hire these skills separately and spend their energy coordinating vendors.",
      "We brought four disciplines into one team — product design, full-stack engineering, digital strategy and automation, and business operations — so that the people solving your problem are already talking to each other.",
      "We are based in India and work with clients wherever they are. We keep the team deliberately small, so every engagement is handled by the people you actually speak to.",
    ],
  },
  mission: {
    eyebrow: "Mission",
    statement:
      "To give ambitious businesses the digital systems they need — designed, built and run with the care of an in-house team and the speed of a specialist one.",
  },
  values: [
    {
      title: "Clarity over cleverness",
      body: "Plain language, written scopes and visible trade-offs. If we cannot explain it simply, we have not understood it.",
    },
    {
      title: "Ownership",
      body: "We treat your deadline, budget and reputation as our own, and we own our mistakes quickly.",
    },
    { title: "Craft", body: "Accessible interfaces, secure code and documentation someone will actually read." },
    {
      title: "Candour",
      body: "We tell you when an idea will not work, when a date is at risk, and when you need someone other than us.",
    },
  ],
  principles: [
    "Diagnose before prescribing.",
    "Agree scope in writing, and change it in writing.",
    "Show working software early and often.",
    "Security and accessibility are defaults, not upgrades.",
    "Leave every system better documented than we found it.",
    "Regulated work goes to licensed professionals.",
  ],
  advantage: {
    eyebrow: "The multidisciplinary advantage",
    title: "Four perspectives on every decision.",
    body: "When a designer, an engineer, a growth strategist and an operator review the same plan, blind spots surface early — before they become expensive. That is the practical benefit of one coordinated team.",
  },
} as const;
