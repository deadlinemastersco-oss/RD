import type { CaseStudy, TeamMember, Testimonial } from "@/lib/types/content";

/**
 * FALLBACK TEAM
 * Placeholder profiles describing the four specialist seats.
 * Replace names and bios in Supabase (`team_members`) or here before launch.
 */
export const fallbackTeam: TeamMember[] = [
  {
    id: "seat-design",
    name: "Product Design Lead",
    role: "UI/UX & Product Design",
    discipline: "Design",
    shortBio:
      "Turns complex requirements into clear interfaces, flows and design systems that engineering can build without guesswork.",
    fullBio:
      "Leads research, information architecture, interface design and design systems. Owns how every product and website feels to use — from first wireframe to final component library.",
    avatarUrl: null,
    skills: ["UX research", "Interface design", "Design systems", "Prototyping", "Accessibility"],
    socialLinks: {},
    isPlaceholder: true,
  },
  {
    id: "seat-engineering",
    name: "Engineering Lead",
    role: "Full-stack & SaaS Development",
    discipline: "Engineering",
    shortBio:
      "Builds the websites, dashboards and MVPs — Next.js, React, TypeScript and Supabase, engineered for production from day one.",
    fullBio:
      "Owns architecture, data modelling, security and delivery. Responsible for code quality, performance, deployments and the technical decisions that keep a product maintainable.",
    avatarUrl: null,
    skills: ["Next.js", "React", "TypeScript", "Supabase / PostgreSQL", "API integrations"],
    socialLinks: {},
    isPlaceholder: true,
  },
  {
    id: "seat-growth",
    name: "Digital Strategy Lead",
    role: "Strategy, Content & Automation",
    discipline: "Growth",
    shortBio:
      "Designs the systems that bring attention and remove busywork — SEO, content operations, social and AI-assisted workflows.",
    fullBio:
      "Connects positioning, search, content and automation. Builds repeatable publishing systems and practical AI workflows with human review, measured against business outcomes.",
    avatarUrl: null,
    skills: ["SEO", "Content systems", "Social media", "AI workflows", "Automation"],
    socialLinks: {},
    isPlaceholder: true,
  },
  {
    id: "seat-operations",
    name: "Business Operations Lead",
    role: "Sales, Operations & Compliance Coordination",
    discipline: "Operations",
    shortBio:
      "Keeps pipelines, operations, finance workflows and compliance coordination organised — working with licensed professionals where required.",
    fullBio:
      "Owns lead generation, client operations, finance processes and compliance coordination. Engages qualified legal and finance professionals for regulated work and keeps every deadline visible.",
    avatarUrl: null,
    skills: ["Lead generation", "Sales operations", "Finance workflows", "Compliance coordination", "Documentation"],
    socialLinks: {},
    isPlaceholder: true,
  },
];

/**
 * FALLBACK "WORK"
 * These are ILLUSTRATIVE engagement blueprints, not client case studies.
 * They are always labelled as such in the UI and contain no client names or results.
 * Publish real, permissioned case studies in Supabase (`case_studies`) to replace them.
 */
export const fallbackCaseStudies: CaseStudy[] = [
  {
    slug: "blueprint-service-business-lead-engine",
    title: "Rebuilding a service firm's website into a lead engine",
    clientName: "Illustrative scenario",
    industry: "Professional services",
    services: ["websites-and-web-applications", "lead-generation-systems", "seo-content-and-digital-growth"],
    summary:
      "How we would approach a professional-services firm whose website looks dated, ranks poorly and routes inquiries to a shared inbox where they go cold.",
    challenge:
      "A typical firm in this position has an outdated site built by a former vendor, no clear service pages, and contact forms that email a shared inbox. Nobody owns follow-up, and there is no record of which inquiries became clients.",
    approach:
      "Start with a two-week diagnosis: interview the partners, review past inquiries, and map the three services that produce the best clients. Design the site around those services, with one clear next step on every page.",
    solution:
      "A Next.js website with dedicated service pages, structured data and fast mobile performance; forms that write into a Supabase-backed pipeline with owners and statuses; and an automated acknowledgement plus internal alert for every new lead.",
    outcome:
      "The expected result is a site the team can update themselves and a pipeline where every inquiry has an owner and a status. Real outcomes depend on the firm's market and follow-up discipline — we measure them after launch rather than promise them in advance.",
    technologies: ["Next.js", "Supabase", "Tailwind CSS", "Structured data", "CRM automation"],
    coverImage: null,
    gallery: [],
    isIllustrative: true,
    publishedAt: null,
  },
  {
    slug: "blueprint-spreadsheet-to-saas-dashboard",
    title: "Replacing a spreadsheet operation with an internal dashboard",
    clientName: "Illustrative scenario",
    industry: "Operations & logistics",
    services: [
      "saas-dashboards-and-mvp-development",
      "ui-ux-and-product-design",
      "ai-workflow-and-business-automation",
    ],
    summary:
      "How we would move a growing operations team off shared spreadsheets and onto a role-based dashboard with an audit trail.",
    challenge:
      "Orders, assignments and status updates live in several shared spreadsheets. Edits overwrite each other, there is no access control, and weekly reporting takes a manager most of a day.",
    approach:
      "Shadow the team for a week, document every status and hand-off, then design a data model and permission scheme before any screens. Agree a first release that covers the daily workflow only.",
    solution:
      "A Next.js and Supabase internal tool with authentication, admin / team / viewer roles enforced by Row Level Security, task boards, an activity log and scheduled reports assembled automatically.",
    outcome:
      "The intended result is one source of truth with controlled access and reports that build themselves. We would baseline time spent on reporting before the build so the improvement can be measured honestly.",
    technologies: ["Next.js", "TypeScript", "Supabase Auth", "PostgreSQL RLS", "Recharts"],
    coverImage: null,
    gallery: [],
    isIllustrative: true,
    publishedAt: null,
  },
  {
    slug: "blueprint-founder-operations-system",
    title: "Giving a founder-led company an operations backbone",
    clientName: "Illustrative scenario",
    industry: "Early-stage startup",
    services: ["operations-and-compliance-coordination", "ai-workflow-and-business-automation"],
    summary:
      "How we would organise contracts, filings, invoices and recurring deadlines for a small company whose founders are doing everything themselves.",
    challenge:
      "Contracts sit in email attachments, statutory deadlines are remembered rather than tracked, and invoicing happens whenever a founder finds time.",
    approach:
      "Inventory every document and recurring obligation, identify which tasks require a licensed chartered accountant, company secretary or lawyer, and design a structure the founders can maintain in under an hour a week.",
    solution:
      "An organised document system, a compliance and renewals calendar with reminders, invoice and approval workflows, and coordination with the company's licensed advisors for regulated filings.",
    outcome:
      "The goal is that no deadline depends on memory and regulated work is handled by qualified professionals. This is coordination and documentation support — not legal, tax or financial advice.",
    technologies: ["Workflow automation", "Document templates", "Compliance calendar", "Finance workflows"],
    coverImage: null,
    gallery: [],
    isIllustrative: true,
    publishedAt: null,
  },
];

/**
 * FALLBACK TESTIMONIALS
 * Intentionally empty. Only publish real quotes you have permission to use.
 * Add them in Supabase (`testimonials`, is_published = true).
 */
export const fallbackTestimonials: Testimonial[] = [];
