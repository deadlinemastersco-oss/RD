/** Option lists shared by forms, validation schemas and the dashboard. */

export const serviceInterestOptions = [
  { value: "websites-and-web-applications", label: "Website or web application" },
  { value: "saas-dashboards-and-mvp-development", label: "SaaS dashboard or MVP" },
  { value: "ui-ux-and-product-design", label: "UI/UX & product design" },
  { value: "ai-workflow-and-business-automation", label: "AI workflow & automation" },
  { value: "seo-content-and-digital-growth", label: "SEO, content & digital growth" },
  { value: "lead-generation-systems", label: "Lead-generation system" },
  { value: "operations-and-compliance-coordination", label: "Operations & compliance coordination" },
  { value: "quick-fix", label: "Quick fix for an urgent problem" },
  { value: "growth-system", label: "Business Growth System" },
  { value: "saas-mvp", label: "SaaS / MVP Launch" },
  { value: "custom", label: "Custom mission / not sure yet" },
] as const;

export const budgetOptions = [
  { value: "under-50k", label: "Under ₹50,000" },
  { value: "50k-1.5l", label: "₹50,000 – ₹1.5 lakh" },
  { value: "1.5l-4l", label: "₹1.5 – ₹4 lakh" },
  { value: "4l-10l", label: "₹4 – ₹10 lakh" },
  { value: "10l-plus", label: "₹10 lakh +" },
  { value: "not-sure", label: "Not sure yet" },
] as const;

export const timelineOptions = [
  { value: "this-week", label: "This week — it is urgent" },
  { value: "2-4-weeks", label: "Within 2–4 weeks" },
  { value: "1-3-months", label: "Within 1–3 months" },
  { value: "flexible", label: "Flexible" },
] as const;

export type OptionValue<T extends readonly { value: string }[]> = T[number]["value"];

export const labelFor = (options: readonly { value: string; label: string }[], value: string | null | undefined) =>
  options.find((o) => o.value === value)?.label ?? value ?? "—";

/* ---------------------------------------------------------------------------
 * Diagnostic flow
 * ------------------------------------------------------------------------- */

export const diagnosticQuestions = {
  problem: {
    title: "Where is the problem?",
    help: "Pick the area that is costing you the most right now.",
    options: [
      {
        value: "website",
        label: "Our website is not working for us",
        hint: "Slow, outdated, hard to update or not converting",
      },
      {
        value: "product",
        label: "We need to build a product or internal tool",
        hint: "SaaS idea, MVP, dashboard, spreadsheet replacement",
      },
      {
        value: "experience",
        label: "Users find our product confusing",
        hint: "Drop-offs, support load, inconsistent design",
      },
      {
        value: "manual-work",
        label: "Too much repetitive manual work",
        hint: "Copy-paste between tools, manual reports, slow hand-offs",
      },
      { value: "visibility", label: "Not enough people find us", hint: "Weak search presence, inconsistent content" },
      {
        value: "pipeline",
        label: "Leads are unpredictable or lost",
        hint: "No pipeline, poor follow-up, unclear attribution",
      },
      {
        value: "operations",
        label: "Operations and compliance feel chaotic",
        hint: "Deadlines, documents, finance workflows, filings",
      },
    ],
  },
  urgency: {
    title: "How urgent is it?",
    help: "Be honest — it changes how we would approach it.",
    options: [
      { value: "critical", label: "Critical — it is hurting the business now" },
      { value: "high", label: "High — needs solving this month" },
      { value: "planned", label: "Planned — next quarter" },
      { value: "exploring", label: "Exploring options" },
    ],
  },
  stage: {
    title: "What stage is the business at?",
    help: "This helps us size the recommendation.",
    options: [
      { value: "idea", label: "Pre-launch or idea stage" },
      { value: "early", label: "Early — first customers" },
      { value: "growing", label: "Growing — processes are straining" },
      { value: "established", label: "Established — optimising and modernising" },
    ],
  },
  outcome: {
    title: "What outcome matters most?",
    help: "Choose the result you would measure us on.",
    options: [
      { value: "launch", label: "Launch something new" },
      { value: "leads", label: "More qualified inquiries" },
      { value: "time", label: "Save team time" },
      { value: "experience", label: "Better customer experience" },
      { value: "control", label: "Control, visibility and fewer missed deadlines" },
    ],
  },
} as const;

export type DiagnosticKey = keyof typeof diagnosticQuestions;
export type DiagnosticAnswers = {
  [K in DiagnosticKey]: (typeof diagnosticQuestions)[K]["options"][number]["value"];
};

/** Human label for a lead's topic: form option → service title → prettified slug. */
export function topicLabel(value: string | null | undefined, serviceTitles: Record<string, string> = {}) {
  if (!value) return "—";
  const option = serviceInterestOptions.find((o) => o.value === value);
  if (option) return option.label;
  if (serviceTitles[value]) return serviceTitles[value];
  return value.replace(/[_-]+/g, " ").replace(/^\w/, (c) => c.toUpperCase());
}
