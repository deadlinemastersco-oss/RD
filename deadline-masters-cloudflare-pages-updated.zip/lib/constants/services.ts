import type { Service } from "@/lib/types/content";

/**
 * Fallback service catalogue.
 * Used whenever the Supabase `services` table is empty or unreachable.
 * A row in Supabase with the same `slug` overrides the matching fields here.
 *
 * Prices are "starting from" figures in INR. Edit freely — they are placeholders
 * for your own rate card, not quotes.
 */
export const fallbackServices: Service[] = [
  {
    slug: "websites-and-web-applications",
    title: "Websites & web applications",
    category: "build",
    icon: "globe",
    shortDescription:
      "Fast, accessible marketing sites and web apps that explain what you do and turn visitors into conversations.",
    fullDescription:
      "We plan, design and engineer websites and web applications on a modern Next.js stack — structured for search, easy for your team to update, and built to load quickly on real phones and real networks.",
    problem:
      "Your website is slow, hard to update, or no longer matches how the business sells. Leads arrive through the wrong channels, or not at all, and every small change needs a developer.",
    idealClient:
      "Service businesses, professional firms and growing companies that need a credible web presence and a site their team can actually run.",
    whatWeDeliver: [
      "Information architecture and conversion-focused page structure",
      "Custom visual design aligned to your brand",
      "Next.js build with a content workflow your team can use",
      "Technical SEO, analytics and lead-capture forms",
      "Performance, accessibility and security baseline",
    ],
    process: [
      {
        title: "Map",
        description: "Audit the current site, audience, offers and the journeys that should end in an inquiry.",
      },
      {
        title: "Design",
        description: "Wireframes first, then high-fidelity design for key templates on mobile and desktop.",
      },
      { title: "Build", description: "Component-based build, CMS or Supabase content model, forms and integrations." },
      { title: "Launch", description: "QA across devices, redirects, analytics verification and a guided handover." },
    ],
    deliverables: [
      "Sitemap and page wireframes",
      "Responsive UI design",
      "Production codebase in your repository",
      "Deployment on your hosting account",
      "Editing guide and handover session",
    ],
    timeline: "3–6 weeks",
    startingPrice: 60000,
  },
  {
    slug: "saas-dashboards-and-mvp-development",
    title: "SaaS dashboards & MVP development",
    category: "build",
    icon: "layout-dashboard",
    shortDescription:
      "From validated idea to a working product: authentication, data model, dashboards and the first release your users can log into.",
    fullDescription:
      "We scope a focused first version, design the core workflows and build a production-grade MVP with authentication, roles, a clean database design and the dashboards your users or internal team need.",
    problem:
      "You have a product idea or an internal process stuck in spreadsheets, and you need a real application — not a prototype that has to be thrown away.",
    idealClient:
      "Founders preparing a first release, and operating businesses replacing spreadsheet workflows with a proper internal tool.",
    whatWeDeliver: [
      "Scope workshop and a written MVP definition",
      "Product design for core user journeys",
      "Next.js + Supabase application with auth and role-based access",
      "Database schema with Row Level Security",
      "Admin dashboard, reporting and deployment pipeline",
    ],
    process: [
      {
        title: "Scope",
        description: "Agree the smallest version that proves value, and what is deliberately left out.",
      },
      { title: "Model", description: "Design the data model, permissions and core screens before writing features." },
      {
        title: "Build in sprints",
        description: "Weekly demos on a staging URL so you see progress, not status reports.",
      },
      { title: "Release", description: "Production deployment, monitoring and a prioritised backlog for version two." },
    ],
    deliverables: [
      "MVP specification and backlog",
      "Clickable prototype of key flows",
      "Production application and database",
      "Staging and production environments",
      "Technical documentation",
    ],
    timeline: "6–12 weeks",
    startingPrice: 400000,
  },
  {
    slug: "ui-ux-and-product-design",
    title: "UI/UX & product design",
    category: "design",
    icon: "pen-tool",
    shortDescription:
      "Research-backed interface design that makes complex products feel obvious — delivered as a usable design system, not just screens.",
    fullDescription:
      "We untangle confusing flows, design new products and build design systems that keep teams consistent. Every design decision is tied to a user task and a business goal.",
    problem:
      "Users drop off, support tickets pile up, or the product looks inconsistent because every screen was designed in isolation.",
    idealClient:
      "Product teams, SaaS companies and businesses redesigning a customer-facing platform or launching a new one.",
    whatWeDeliver: [
      "UX audit with prioritised findings",
      "User flows and wireframes",
      "High-fidelity UI for web and mobile",
      "Design system with reusable components",
      "Developer-ready specifications",
    ],
    process: [
      { title: "Understand", description: "Stakeholder interviews, analytics review and a heuristic audit." },
      { title: "Structure", description: "Flows and low-fidelity wireframes validated before visual design." },
      { title: "Design", description: "High-fidelity screens, states and responsive behaviour." },
      { title: "Systemise", description: "Component library, tokens and handover to engineering." },
    ],
    deliverables: [
      "UX audit report",
      "Flow diagrams and wireframes",
      "UI design files",
      "Design tokens and component library",
      "Handover walkthrough",
    ],
    timeline: "2–6 weeks",
    startingPrice: 50000,
  },
  {
    slug: "ai-workflow-and-business-automation",
    title: "AI workflow & business automation",
    category: "operations",
    icon: "workflow",
    shortDescription:
      "Remove repetitive work: connect your tools, automate hand-offs and apply AI where it saves real hours — with human review built in.",
    fullDescription:
      "We map how work actually moves through your business, then automate the repetitive steps using integrations, scripts and carefully scoped AI assistance, with logging and human checkpoints.",
    problem:
      "Your team copies data between tools, chases approvals over chat and spends hours on reports that could assemble themselves.",
    idealClient:
      "Operations-heavy teams — agencies, service firms, e-commerce and back offices — with clear, repeatable processes.",
    whatWeDeliver: [
      "Process mapping and automation opportunity list",
      "Integrations between your existing tools",
      "AI-assisted drafting, classification or extraction steps",
      "Error handling, logging and human-in-the-loop review",
      "Runbooks your team can maintain",
    ],
    process: [
      { title: "Observe", description: "Document the current workflow, volumes, owners and failure points." },
      { title: "Prioritise", description: "Rank opportunities by hours saved, risk and effort." },
      { title: "Automate", description: "Build, test on real data and add monitoring." },
      { title: "Adopt", description: "Train the team, measure time saved and refine." },
    ],
    deliverables: [
      "Workflow map",
      "Automation build and configuration",
      "Monitoring and alerting",
      "Runbook and training session",
    ],
    timeline: "2–5 weeks",
    startingPrice: 40000,
  },
  {
    slug: "seo-content-and-digital-growth",
    title: "SEO, content & digital growth",
    category: "growth",
    icon: "trending-up",
    shortDescription:
      "Technical SEO, content systems and social distribution designed to compound — measured against inquiries, not vanity metrics.",
    fullDescription:
      "We fix the technical foundations, build a content plan around what your buyers search for, and set up a repeatable production system — including AI-assisted drafting with editorial review.",
    problem:
      "You publish sporadically, rank for the wrong terms, and cannot tell which channels actually produce customers.",
    idealClient: "Businesses with a clear offer that want a steady, measurable inbound channel alongside referrals.",
    whatWeDeliver: [
      "Technical SEO audit and fixes",
      "Keyword and topic strategy mapped to buyer intent",
      "Editorial calendar and content production workflow",
      "Social distribution system",
      "Monthly reporting tied to leads",
    ],
    process: [
      { title: "Audit", description: "Crawl, indexation, speed and competitor gap analysis." },
      { title: "Plan", description: "Topic clusters, page briefs and a realistic publishing cadence." },
      { title: "Produce", description: "Write, edit, optimise and publish with your subject-matter input." },
      { title: "Measure", description: "Track rankings, traffic quality and inquiry attribution." },
    ],
    deliverables: [
      "SEO audit and remediation list",
      "Content strategy and calendar",
      "Published articles and landing pages",
      "Analytics dashboard",
    ],
    timeline: "Ongoing · monthly",
    startingPrice: 35000,
  },
  {
    slug: "lead-generation-systems",
    title: "Lead-generation systems",
    category: "growth",
    icon: "magnet",
    shortDescription:
      "A connected pipeline — landing pages, offers, outreach and CRM — so inquiries are captured, followed up and never lost in an inbox.",
    fullDescription:
      "We design the full path from first touch to booked call: positioning, landing pages, outbound sequences, qualification and a CRM setup that shows where every lead stands.",
    problem:
      "Leads arrive from five places, follow-up depends on memory, and nobody can say which efforts produce revenue.",
    idealClient: "B2B service companies and consultants with a proven offer who need a predictable pipeline.",
    whatWeDeliver: [
      "Offer and positioning refinement",
      "Conversion-focused landing pages",
      "Outbound and follow-up sequences",
      "CRM pipeline, stages and automations",
      "Weekly pipeline reporting",
    ],
    process: [
      { title: "Position", description: "Clarify ideal customer, offer and proof points." },
      { title: "Build", description: "Landing pages, forms, sequences and CRM configuration." },
      { title: "Launch", description: "Controlled rollout with tracking on every step." },
      { title: "Tune", description: "Weekly reviews of reply rates, conversion and lead quality." },
    ],
    deliverables: [
      "Positioning brief",
      "Landing pages and forms",
      "Email/LinkedIn sequences",
      "CRM setup and documentation",
      "Reporting dashboard",
    ],
    timeline: "3–6 weeks",
    startingPrice: 75000,
  },
  {
    slug: "operations-and-compliance-coordination",
    title: "Operations & compliance coordination",
    category: "operations",
    icon: "shield-check",
    shortDescription:
      "Documentation, process design and compliance coordination — organised by us, with licensed professionals engaged wherever the law requires.",
    fullDescription:
      "We bring order to the operational side of growth: SOPs, vendor and contract trackers, finance workflows, and coordination of statutory and compliance tasks with qualified chartered accountants, company secretaries and lawyers.",
    problem:
      "Filings, contracts, invoices and policies live in scattered folders. Deadlines are tracked in someone's head, and the business depends on reminders.",
    idealClient:
      "Founders and small leadership teams who need operational structure without building an in-house operations department.",
    whatWeDeliver: [
      "Standard operating procedures and checklists",
      "Compliance and renewals calendar",
      "Document templates and organised records",
      "Finance workflow setup (invoicing, approvals, reporting)",
      "Coordination with your licensed professionals",
    ],
    process: [
      { title: "Inventory", description: "Collect current documents, obligations, owners and deadlines." },
      { title: "Structure", description: "Design folders, trackers, templates and approval steps." },
      { title: "Coordinate", description: "Engage or work alongside licensed professionals for regulated work." },
      { title: "Maintain", description: "Optional monthly upkeep and deadline monitoring." },
    ],
    deliverables: ["Operations handbook", "Compliance calendar", "Template library", "Finance and approval workflows"],
    timeline: "2–4 weeks, then optional retainer",
    startingPrice: null,
    needsProfessionalDisclaimer: true,
  },
];
