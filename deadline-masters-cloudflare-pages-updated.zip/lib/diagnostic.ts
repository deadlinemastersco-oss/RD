import type { DiagnosticAnswers } from "@/lib/constants/forms";
import { pricingTiers } from "@/lib/constants/engagement";

export type DiagnosticRecommendation = {
  primaryService: string; // service slug
  supportingServices: string[];
  engagementTierId: string;
  headline: string;
  rationale: string;
  firstSteps: string[];
  pace: string;
  needsProfessionalDisclaimer: boolean;
};

const problemToService: Record<DiagnosticAnswers["problem"], { primary: string; support: string[] }> = {
  website: {
    primary: "websites-and-web-applications",
    support: ["seo-content-and-digital-growth", "ui-ux-and-product-design"],
  },
  product: {
    primary: "saas-dashboards-and-mvp-development",
    support: ["ui-ux-and-product-design", "ai-workflow-and-business-automation"],
  },
  experience: { primary: "ui-ux-and-product-design", support: ["websites-and-web-applications"] },
  "manual-work": {
    primary: "ai-workflow-and-business-automation",
    support: ["saas-dashboards-and-mvp-development", "operations-and-compliance-coordination"],
  },
  visibility: {
    primary: "seo-content-and-digital-growth",
    support: ["websites-and-web-applications", "lead-generation-systems"],
  },
  pipeline: {
    primary: "lead-generation-systems",
    support: ["websites-and-web-applications", "ai-workflow-and-business-automation"],
  },
  operations: { primary: "operations-and-compliance-coordination", support: ["ai-workflow-and-business-automation"] },
};

const outcomeSupport: Record<DiagnosticAnswers["outcome"], string> = {
  launch: "saas-dashboards-and-mvp-development",
  leads: "lead-generation-systems",
  time: "ai-workflow-and-business-automation",
  experience: "ui-ux-and-product-design",
  control: "operations-and-compliance-coordination",
};

/**
 * Deterministic, rules-based recommendation. It is a starting point for a
 * conversation — not professional, legal, tax or financial advice.
 * Runs on both client (preview) and server (stored value is recomputed server-side).
 */
export function recommend(answers: DiagnosticAnswers): DiagnosticRecommendation {
  const base = problemToService[answers.problem];
  const extra = outcomeSupport[answers.outcome];
  const supporting = Array.from(new Set([...(extra !== base.primary ? [extra] : []), ...base.support]))
    .filter((s) => s !== base.primary)
    .slice(0, 2);

  let engagementTierId = "growth-system";
  if (answers.urgency === "critical" && answers.problem !== "product") engagementTierId = "quick-fix";
  else if (answers.problem === "product" || answers.outcome === "launch") engagementTierId = "saas-mvp";
  else if (answers.stage === "established" && supporting.length > 1) engagementTierId = "custom-mission";

  const tier = pricingTiers.find((t) => t.id === engagementTierId);

  const pace =
    answers.urgency === "critical"
      ? "Stabilise first: fix what is actively causing damage within days, then plan the structural work."
      : answers.urgency === "high"
        ? "Scope this week and start within days, with a first visible milestone inside two weeks."
        : answers.urgency === "planned"
          ? "Use the time to diagnose properly and agree a phased roadmap before next quarter."
          : "Start with a short diagnostic call to size the opportunity before committing budget.";

  const stageNote: Record<DiagnosticAnswers["stage"], string> = {
    idea: "At the idea stage, the priority is proving value with the smallest credible release.",
    early: "With first customers in place, the priority is removing friction before it compounds.",
    growing: "When processes are straining, systems that remove manual hand-offs pay back fastest.",
    established: "For an established business, the priority is modernising without disrupting what works.",
  };

  const firstSteps = [
    "30-minute diagnostic call to confirm the real constraint",
    "Written findings and a scoped plan with a fixed or phased quote",
    answers.urgency === "critical"
      ? "Immediate stabilisation fix while the full plan is agreed"
      : "Kick-off with a named lead from the relevant discipline",
  ];

  return {
    primaryService: base.primary,
    supportingServices: supporting,
    engagementTierId,
    headline: tier ? `Suggested engagement: ${tier.name}` : "Suggested engagement",
    rationale: stageNote[answers.stage],
    firstSteps,
    pace,
    needsProfessionalDisclaimer:
      base.primary === "operations-and-compliance-coordination" ||
      supporting.includes("operations-and-compliance-coordination"),
  };
}
