import "server-only";

import { createClient as createSupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/lib/types/database";
import { isSupabaseConfigured, supabasePublicKey, supabaseUrl } from "@/lib/env";

/**
 * Cookie-less client for reading PUBLIC marketing content (published services,
 * case studies, testimonials, team). Because it never touches cookies, pages that
 * use it stay statically renderable with ISR. Access is limited by RLS to published rows.
 * Also used for anonymous form inserts (contact, inquiries, newsletter).
 */
export function createPublicClient() {
  if (!isSupabaseConfigured) return null;
  return createSupabaseClient<Database>(supabaseUrl, supabasePublicKey, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
  });
}
