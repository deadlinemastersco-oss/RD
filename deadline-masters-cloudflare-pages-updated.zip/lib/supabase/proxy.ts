import { NextResponse, type NextRequest } from "next/server";
import { createServerClient } from "@supabase/ssr";
import type { Database } from "@/lib/types/database";
import { isSupabaseConfigured, supabasePublicKey, supabaseUrl } from "@/lib/env";

const PROTECTED_PREFIXES = ["/dashboard"];
const GUEST_ONLY = ["/auth/sign-in", "/auth/sign-up", "/auth/forgot-password"];

/**
 * Runs in proxy.ts on every matched request:
 *  1. refreshes the Supabase session and writes updated cookies,
 *  2. redirects signed-out visitors away from /dashboard,
 *  3. redirects signed-in users away from sign-in / sign-up.
 * Pages still re-check auth on the server (defence in depth).
 */
export async function updateSession(request: NextRequest) {
  let response = NextResponse.next({ request });
  const { pathname, search } = request.nextUrl;
  const isProtected = PROTECTED_PREFIXES.some((p) => pathname === p || pathname.startsWith(`${p}/`));

  if (!isSupabaseConfigured) {
    // Without Supabase there is no way to sign in. Dashboard pages render a setup notice.
    return response;
  }

  const supabase = createServerClient<Database>(supabaseUrl, supabasePublicKey, {
    cookies: {
      getAll() {
        return request.cookies.getAll();
      },
      setAll(cookiesToSet, headers) {
        cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
        response = NextResponse.next({ request });
        cookiesToSet.forEach(({ name, value, options }) => response.cookies.set(name, value, options));
        Object.entries(headers ?? {}).forEach(([key, value]) => response.headers.set(key, value));
      },
    },
  });

  // IMPORTANT: do not run code between createServerClient and getClaims().
  // getClaims() validates the JWT signature (and refreshes the session if needed).
  const { data } = await supabase.auth.getClaims();
  const isSignedIn = Boolean(data?.claims?.sub);

  if (isProtected && !isSignedIn) {
    const url = request.nextUrl.clone();
    url.pathname = "/auth/sign-in";
    url.search = `?next=${encodeURIComponent(pathname + search)}`;
    return redirectWithCookies(url, response);
  }

  if (isSignedIn && GUEST_ONLY.includes(pathname)) {
    const url = request.nextUrl.clone();
    url.pathname = "/dashboard";
    url.search = "";
    return redirectWithCookies(url, response);
  }

  return response;
}

function redirectWithCookies(url: URL, from: NextResponse) {
  const redirect = NextResponse.redirect(url);
  from.cookies.getAll().forEach((c) => redirect.cookies.set(c));
  return redirect;
}
