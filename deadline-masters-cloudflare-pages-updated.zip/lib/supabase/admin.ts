import "server-only";

import { createClient as createSupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/lib/types/database";
import { supabaseUrl } from "@/lib/env";

/**
 * SERVICE-ROLE client. Bypasses Row Level Security.
 *
 * - The `server-only` import makes the build fail if a Client Component imports this file.
 * - Only call it from Server Actions / Route Handlers AFTER verifying the caller is an admin.
 * - Never log the key, never return it, never prefix it with NEXT_PUBLIC_.
 *
 * Currently used only for inviting new team users (auth.admin.inviteUserByEmail).
 */
export function createAdminClient() {
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!supabaseUrl || !serviceRoleKey) return null;
  return createSupabaseClient<Database>(supabaseUrl, serviceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

export const isAdminClientConfigured = () => Boolean(supabaseUrl && process.env.SUPABASE_SERVICE_ROLE_KEY);
