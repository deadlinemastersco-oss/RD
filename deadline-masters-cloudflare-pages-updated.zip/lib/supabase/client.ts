"use client";

import { createBrowserClient } from "@supabase/ssr";
import type { Database } from "@/lib/types/database";
import { isSupabaseConfigured, supabasePublicKey, supabaseUrl } from "@/lib/env";

/**
 * Browser Supabase client. Uses only the public (publishable/anon) key.
 * Row Level Security is what protects data — never rely on this client for authorization.
 */
export function createClient() {
  if (!isSupabaseConfigured) {
    throw new Error(
      "Supabase is not configured. Add NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY to .env.local.",
    );
  }
  return createBrowserClient<Database>(supabaseUrl, supabasePublicKey);
}
