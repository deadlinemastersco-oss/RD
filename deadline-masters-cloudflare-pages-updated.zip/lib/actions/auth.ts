"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { siteUrl } from "@/lib/env";
import { rateLimit } from "@/lib/rate-limit";
import {
  forgotPasswordSchema,
  magicLinkSchema,
  safeNextPath,
  signInSchema,
  signUpSchema,
  updatePasswordSchema,
  type ForgotPasswordInput,
  type SignInInput,
  type SignUpInput,
  type UpdatePasswordInput,
} from "@/lib/validations/auth";
import { notConfigured, type ActionResult } from "@/lib/actions/types";

const confirmUrl = (next: string) => `${siteUrl}/auth/confirm?next=${encodeURIComponent(next)}`;

export async function signInWithPassword(raw: SignInInput, next?: string): Promise<ActionResult> {
  const parsed = signInSchema.safeParse(raw);
  if (!parsed.success)
    return { ok: false, message: "Check your details.", fieldErrors: z.flattenError(parsed.error).fieldErrors };

  const limited = await rateLimit("sign-in", 10, 10 * 60 * 1000);
  if (!limited.ok) return { ok: false, message: "Too many sign-in attempts. Please wait a few minutes." };

  const supabase = await createClient();
  if (!supabase) return notConfigured;

  const { error } = await supabase.auth.signInWithPassword(parsed.data);
  if (error) {
    // Deliberately vague — do not reveal whether the email exists.
    const unconfirmed = error.code === "email_not_confirmed";
    return {
      ok: false,
      message: unconfirmed
        ? "Please confirm your email address first — check your inbox for the link."
        : "Email or password is incorrect.",
    };
  }

  revalidatePath("/", "layout");
  redirect(safeNextPath(next));
}

export async function sendMagicLink(raw: { email: string }, next?: string): Promise<ActionResult> {
  const parsed = magicLinkSchema.safeParse(raw);
  if (!parsed.success)
    return { ok: false, message: "Enter a valid email.", fieldErrors: z.flattenError(parsed.error).fieldErrors };

  const limited = await rateLimit("magic-link", 5, 10 * 60 * 1000);
  if (!limited.ok) return { ok: false, message: "Too many requests. Please wait a few minutes." };

  const supabase = await createClient();
  if (!supabase) return notConfigured;

  // shouldCreateUser: false → magic links only work for existing team accounts.
  await supabase.auth.signInWithOtp({
    email: parsed.data.email,
    options: { shouldCreateUser: false, emailRedirectTo: confirmUrl(safeNextPath(next)) },
  });
  return { ok: true, message: "If an account exists for that address, a sign-in link is on its way." };
}

export async function signUp(raw: SignUpInput): Promise<ActionResult> {
  const parsed = signUpSchema.safeParse(raw);
  if (!parsed.success)
    return {
      ok: false,
      message: "Check the highlighted fields.",
      fieldErrors: z.flattenError(parsed.error).fieldErrors,
    };

  const limited = await rateLimit("sign-up", 5, 60 * 60 * 1000);
  if (!limited.ok) return { ok: false, message: "Too many attempts. Please try again later." };

  const supabase = await createClient();
  if (!supabase) return notConfigured;

  const { data, error } = await supabase.auth.signUp({
    email: parsed.data.email,
    password: parsed.data.password,
    options: {
      data: { full_name: parsed.data.full_name },
      emailRedirectTo: confirmUrl("/dashboard"),
    },
  });

  if (error) {
    if (error.code === "weak_password") return { ok: false, message: "Choose a stronger password." };
    if (error.code === "signup_disabled")
      return { ok: false, message: "New sign-ups are currently closed. Ask an admin for an invite." };
    return { ok: false, message: "We could not create the account. Please try again." };
  }

  // If email confirmation is disabled in Supabase, a session exists already.
  if (data.session) {
    revalidatePath("/", "layout");
    redirect("/dashboard");
  }
  return {
    ok: true,
    message:
      "Check your inbox to confirm your email. New accounts start with viewer access until an admin upgrades them.",
  };
}

export async function requestPasswordReset(raw: ForgotPasswordInput): Promise<ActionResult> {
  const parsed = forgotPasswordSchema.safeParse(raw);
  if (!parsed.success)
    return { ok: false, message: "Enter a valid email.", fieldErrors: z.flattenError(parsed.error).fieldErrors };

  const limited = await rateLimit("reset", 5, 30 * 60 * 1000);
  if (!limited.ok) return { ok: false, message: "Too many requests. Please try again later." };

  const supabase = await createClient();
  if (!supabase) return notConfigured;

  await supabase.auth.resetPasswordForEmail(parsed.data.email, {
    redirectTo: confirmUrl("/auth/update-password"),
  });
  // Same response whether or not the account exists.
  return { ok: true, message: "If an account exists for that address, a reset link is on its way." };
}

export async function updatePassword(raw: UpdatePasswordInput): Promise<ActionResult> {
  const parsed = updatePasswordSchema.safeParse(raw);
  if (!parsed.success)
    return {
      ok: false,
      message: "Check the highlighted fields.",
      fieldErrors: z.flattenError(parsed.error).fieldErrors,
    };

  const supabase = await createClient();
  if (!supabase) return notConfigured;

  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) {
    return { ok: false, message: "Your reset link has expired. Request a new one." };
  }

  const { error } = await supabase.auth.updateUser({ password: parsed.data.password });
  if (error) {
    if (error.code === "same_password") return { ok: false, message: "Choose a password you have not used before." };
    return { ok: false, message: "We could not update your password. Please request a new link." };
  }

  revalidatePath("/", "layout");
  redirect("/dashboard?password=updated");
}

export async function signOut() {
  const supabase = await createClient();
  if (supabase) await supabase.auth.signOut();
  revalidatePath("/", "layout");
  redirect("/auth/sign-in?signed_out=1");
}
