"use server";

import { after } from "next/server";
import { z } from "zod";
import { createPublicClient } from "@/lib/supabase/public";
import { rateLimit } from "@/lib/rate-limit";
import { notifyNewLead } from "@/lib/email";
import { recommend } from "@/lib/diagnostic";
import { labelFor, serviceInterestOptions } from "@/lib/constants/forms";
import {
  contactSchema,
  diagnosticSubmissionSchema,
  newsletterSchema,
  nullIfEmpty,
  type ContactInput,
  type DiagnosticSubmissionInput,
  type NewsletterInput,
} from "@/lib/validations/public";
import { genericError, notConfigured, type ActionResult } from "@/lib/actions/types";

const MIN_FILL_MS = 2000;

/** True when the submission looks automated. We then pretend success and store nothing. */
function isLikelyBot(input: { company_website?: string; started_at?: number }) {
  if (input.company_website && input.company_website.trim() !== "") return true;
  if (input.started_at && Date.now() - input.started_at < MIN_FILL_MS) return true;
  return false;
}

export async function submitContact(raw: ContactInput): Promise<ActionResult> {
  const parsed = contactSchema.safeParse(raw);
  if (!parsed.success) {
    return {
      ok: false,
      message: "Please check the highlighted fields.",
      fieldErrors: z.flattenError(parsed.error).fieldErrors,
    };
  }
  const input = parsed.data;
  if (isLikelyBot(input)) return { ok: true };

  const limited = await rateLimit("contact", 5, 10 * 60 * 1000);
  if (!limited.ok) {
    return { ok: false, message: `Too many submissions. Please try again in ${limited.retryAfterSeconds} seconds.` };
  }

  const supabase = createPublicClient();
  if (!supabase) return notConfigured;

  const { error } = await supabase.from("contact_submissions").insert({
    full_name: input.full_name,
    email: input.email.toLowerCase(),
    phone: nullIfEmpty(input.phone),
    company: nullIfEmpty(input.company),
    service_interest: input.service_interest,
    budget_range: input.budget_range,
    deadline: input.deadline,
    message: input.message,
    source: "contact_form",
    consent_at: new Date().toISOString(),
  });

  if (error) {
    console.error("[contact] insert failed:", error.code, error.message);
    return genericError;
  }

  after(() =>
    notifyNewLead({
      kind: "contact",
      name: input.full_name,
      email: input.email,
      company: input.company,
      topic: labelFor(serviceInterestOptions, input.service_interest),
      message: input.message,
    }),
  );

  return { ok: true, message: "Thank you — your message is with the team." };
}

export async function subscribeNewsletter(raw: NewsletterInput): Promise<ActionResult> {
  const parsed = newsletterSchema.safeParse(raw);
  if (!parsed.success) {
    return {
      ok: false,
      message: "Please enter a valid email address.",
      fieldErrors: z.flattenError(parsed.error).fieldErrors,
    };
  }
  if (isLikelyBot(parsed.data)) return { ok: true, message: "You're on the list." };

  const limited = await rateLimit("newsletter", 5, 10 * 60 * 1000);
  if (!limited.ok) return { ok: false, message: "Too many attempts. Please try again later." };

  const supabase = createPublicClient();
  if (!supabase) return notConfigured;

  const { error } = await supabase.from("newsletter_subscribers").insert({
    email: parsed.data.email.toLowerCase(),
    source: parsed.data.source?.slice(0, 60) || "website",
  });

  // 23505 = unique violation → already subscribed. Respond identically to avoid
  // revealing whether an address is on the list.
  if (error && error.code !== "23505") {
    console.error("[newsletter] insert failed:", error.code, error.message);
    return genericError;
  }
  return { ok: true, message: "You're on the list. Expect occasional, useful notes — never spam." };
}

export async function submitDiagnostic(raw: DiagnosticSubmissionInput): Promise<ActionResult> {
  const parsed = diagnosticSubmissionSchema.safeParse(raw);
  if (!parsed.success) {
    return {
      ok: false,
      message: "Please check the highlighted fields.",
      fieldErrors: z.flattenError(parsed.error).fieldErrors,
    };
  }
  const input = parsed.data;
  if (isLikelyBot(input)) return { ok: true };

  const limited = await rateLimit("diagnostic", 5, 10 * 60 * 1000);
  if (!limited.ok) return { ok: false, message: "Too many submissions. Please try again later." };

  const supabase = createPublicClient();
  if (!supabase) return notConfigured;

  // Recompute server-side: never trust a recommendation computed in the browser.
  const rec = recommend(input.answers);

  const { error } = await supabase.from("project_inquiries").insert({
    name: input.name,
    email: input.email.toLowerCase(),
    phone: nullIfEmpty(input.phone),
    company: nullIfEmpty(input.company),
    project_type: input.answers.problem,
    project_description: nullIfEmpty(input.notes),
    desired_timeline: input.answers.urgency,
    source: "diagnostic",
    diagnostic: { ...input.answers, engagement: rec.engagementTierId, supporting: rec.supportingServices },
    recommended_service: rec.primaryService,
    consent_at: new Date().toISOString(),
  });

  if (error) {
    console.error("[diagnostic] insert failed:", error.code, error.message);
    return genericError;
  }

  after(() =>
    notifyNewLead({
      kind: "diagnostic",
      name: input.name,
      email: input.email,
      company: input.company,
      topic: rec.primaryService,
      message: input.notes,
    }),
  );

  return { ok: true, message: "Received. A specialist will review your answers and reply within one business day." };
}
