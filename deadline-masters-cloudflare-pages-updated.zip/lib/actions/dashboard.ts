"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { authorize } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { siteUrl } from "@/lib/env";
import {
  inviteSchema,
  leadNoteSchema,
  profileSchema,
  projectSchema,
  roleUpdateSchema,
  siteSettingSchema,
  taskSchema,
  taskStatusSchema,
  toggleSchema,
  updateLeadSchema,
  uuid,
  type ProfileInput,
  type ProjectInput,
  type TaskInput,
} from "@/lib/validations/dashboard";
import { genericError, notConfigured, type ActionResult } from "@/lib/actions/types";
import type { Json } from "@/lib/types/database";

/**
 * Every action:
 *  1. verifies the session + role on the server (authorize),
 *  2. validates input with Zod,
 *  3. writes through the user's own Supabase client so RLS is enforced a second time.
 * The service-role client is used ONLY for inviting users, after an admin check.
 */

const denied: ActionResult = { ok: false, message: "You do not have permission to do that." };
const invalid = (e: z.ZodError): ActionResult => ({
  ok: false,
  message: e.issues[0]?.message ?? "Please check the form.",
  fieldErrors: z.flattenError(e).fieldErrors,
});
const blank = (v: string) => (v.trim() === "" ? null : v.trim());

function dbError(scope: string, error: { code?: string; message: string }): ActionResult {
  console.error(`[dashboard:${scope}]`, error.code, error.message);
  if (error.code === "42501") return denied;
  return genericError;
}

/* --------------------------------------------------------------- Leads -- */

export async function updateLead(input: z.input<typeof updateLeadSchema>): Promise<ActionResult> {
  const user = await authorize("team_member");
  if (!user) return denied;
  const parsed = updateLeadSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  const { type, id, status, assigned_to } = parsed.data;

  if (assigned_to !== undefined && user.role !== "admin") return denied;

  const supabase = await createClient();
  if (!supabase) return notConfigured;

  const patch: { status?: typeof status; assigned_to?: string | null } = {};
  if (status) patch.status = status;
  if (assigned_to !== undefined) patch.assigned_to = assigned_to;

  const table = type === "contact" ? "contact_submissions" : "project_inquiries";
  const { error, count } = await supabase.from(table).update(patch, { count: "exact" }).eq("id", id);
  if (error) return dbError("updateLead", error);
  if (!count) return denied;

  revalidatePath("/dashboard", "layout");
  return { ok: true, message: "Lead updated." };
}

export async function addLeadNote(input: z.input<typeof leadNoteSchema>): Promise<ActionResult> {
  const user = await authorize("team_member");
  if (!user) return denied;
  const parsed = leadNoteSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);

  const supabase = await createClient();
  if (!supabase) return notConfigured;

  const { error } = await supabase.from("inquiry_notes").insert({
    submission_type: parsed.data.type,
    submission_id: parsed.data.id,
    body: parsed.data.body,
    author_id: user.id,
  });
  if (error) return dbError("addLeadNote", error);
  return { ok: true, message: "Note added." };
}

export async function getLeadNotes(type: "contact" | "project", id: string) {
  const user = await authorize("team_member");
  if (!user || !uuid.safeParse(id).success) return [];
  const supabase = await createClient();
  if (!supabase) return [];
  const { data } = await supabase
    .from("inquiry_notes")
    .select("id, body, created_at, author_id")
    .eq("submission_type", type)
    .eq("submission_id", id)
    .order("created_at", { ascending: false })
    .limit(50);
  return data ?? [];
}

export async function deleteLead(input: { type: "contact" | "project"; id: string }): Promise<ActionResult> {
  const user = await authorize("admin");
  if (!user) return denied;
  if (!uuid.safeParse(input.id).success || !["contact", "project"].includes(input.type)) {
    return { ok: false, message: "Invalid lead." };
  }
  const supabase = await createClient();
  if (!supabase) return notConfigured;

  const table = input.type === "contact" ? "contact_submissions" : "project_inquiries";
  const { error } = await supabase.from(table).delete().eq("id", input.id);
  if (error) return dbError("deleteLead", error);
  await supabase.from("inquiry_notes").delete().eq("submission_type", input.type).eq("submission_id", input.id);

  revalidatePath("/dashboard", "layout");
  return { ok: true, message: "Lead deleted." };
}

/* ------------------------------------------------------------ Projects -- */

function projectRow(d: ProjectInput) {
  return {
    title: d.title,
    client_name: blank(d.client_name),
    description: blank(d.description),
    status: d.status,
    progress: d.progress,
    start_date: blank(d.start_date),
    due_date: blank(d.due_date),
    owner_id: blank(d.owner_id),
  };
}

export async function createProject(input: ProjectInput): Promise<ActionResult<{ id: string }>> {
  const user = await authorize("admin");
  if (!user) return denied;
  const parsed = projectSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);

  const supabase = await createClient();
  if (!supabase) return notConfigured;

  const { data, error } = await supabase.from("projects").insert(projectRow(parsed.data)).select("id").single();
  if (error) return dbError("createProject", error);

  revalidatePath("/dashboard", "layout");
  return { ok: true, message: "Project created.", data: { id: data.id } };
}

export async function updateProject(id: string, input: ProjectInput): Promise<ActionResult> {
  const user = await authorize("team_member");
  if (!user) return denied;
  if (!uuid.safeParse(id).success) return { ok: false, message: "Invalid project." };
  const parsed = projectSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);

  const supabase = await createClient();
  if (!supabase) return notConfigured;

  const row = projectRow(parsed.data);
  // Only admins may reassign ownership.
  const patch = user.role === "admin" ? row : { ...row, owner_id: undefined };

  const { error, count } = await supabase.from("projects").update(patch, { count: "exact" }).eq("id", id);
  if (error) return dbError("updateProject", error);
  if (!count) return denied;

  revalidatePath("/dashboard", "layout");
  return { ok: true, message: "Project saved." };
}

export async function deleteProject(id: string): Promise<ActionResult> {
  const user = await authorize("admin");
  if (!user) return denied;
  if (!uuid.safeParse(id).success) return { ok: false, message: "Invalid project." };

  const supabase = await createClient();
  if (!supabase) return notConfigured;
  const { error } = await supabase.from("projects").delete().eq("id", id);
  if (error) return dbError("deleteProject", error);

  revalidatePath("/dashboard", "layout");
  return { ok: true, message: "Project deleted." };
}

/* --------------------------------------------------------------- Tasks -- */

function taskRow(d: TaskInput) {
  return {
    project_id: d.project_id,
    title: d.title,
    description: blank(d.description),
    status: d.status,
    priority: d.priority,
    assigned_to: blank(d.assigned_to),
    due_date: blank(d.due_date),
  };
}

export async function createTask(input: TaskInput): Promise<ActionResult> {
  const user = await authorize("team_member");
  if (!user) return denied;
  const parsed = taskSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);

  const supabase = await createClient();
  if (!supabase) return notConfigured;
  const { error } = await supabase.from("project_tasks").insert(taskRow(parsed.data));
  if (error) return dbError("createTask", error);

  revalidatePath("/dashboard", "layout");
  return { ok: true, message: "Task added." };
}

export async function updateTask(id: string, input: TaskInput): Promise<ActionResult> {
  const user = await authorize("team_member");
  if (!user) return denied;
  if (!uuid.safeParse(id).success) return { ok: false, message: "Invalid task." };
  const parsed = taskSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);

  const supabase = await createClient();
  if (!supabase) return notConfigured;
  const { project_id: _ignored, ...row } = taskRow(parsed.data);
  void _ignored;
  const { error, count } = await supabase.from("project_tasks").update(row, { count: "exact" }).eq("id", id);
  if (error) return dbError("updateTask", error);
  if (!count) return denied;

  revalidatePath("/dashboard", "layout");
  return { ok: true, message: "Task saved." };
}

export async function updateTaskStatus(input: z.input<typeof taskStatusSchema>): Promise<ActionResult> {
  const user = await authorize("team_member");
  if (!user) return denied;
  const parsed = taskStatusSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);

  const supabase = await createClient();
  if (!supabase) return notConfigured;
  const { error, count } = await supabase
    .from("project_tasks")
    .update({ status: parsed.data.status }, { count: "exact" })
    .eq("id", parsed.data.id);
  if (error) return dbError("updateTaskStatus", error);
  if (!count) return denied;

  revalidatePath("/dashboard", "layout");
  return { ok: true, message: "Status updated." };
}

export async function deleteTask(id: string): Promise<ActionResult> {
  const user = await authorize("team_member");
  if (!user) return denied;
  if (!uuid.safeParse(id).success) return { ok: false, message: "Invalid task." };

  const supabase = await createClient();
  if (!supabase) return notConfigured;
  const { error, count } = await supabase.from("project_tasks").delete({ count: "exact" }).eq("id", id);
  if (error) return dbError("deleteTask", error);
  if (!count) return denied;

  revalidatePath("/dashboard", "layout");
  return { ok: true, message: "Task deleted." };
}

/* ------------------------------------------------------- Notifications -- */

export async function markNotificationRead(id: string): Promise<ActionResult> {
  const user = await authorize("viewer");
  if (!user) return denied;
  if (!uuid.safeParse(id).success) return { ok: false, message: "Invalid notification." };
  const supabase = await createClient();
  if (!supabase) return notConfigured;
  const { error } = await supabase.from("notifications").update({ is_read: true }).eq("id", id).eq("user_id", user.id);
  if (error) return dbError("markNotificationRead", error);
  revalidatePath("/dashboard", "layout");
  return { ok: true };
}

export async function markAllNotificationsRead(): Promise<ActionResult> {
  const user = await authorize("viewer");
  if (!user) return denied;
  const supabase = await createClient();
  if (!supabase) return notConfigured;
  const { error } = await supabase
    .from("notifications")
    .update({ is_read: true })
    .eq("user_id", user.id)
    .eq("is_read", false);
  if (error) return dbError("markAllNotificationsRead", error);
  revalidatePath("/dashboard", "layout");
  return { ok: true, message: "All caught up." };
}

/* ----------------------------------------------------- Profile & team -- */

export async function updateProfile(input: ProfileInput): Promise<ActionResult> {
  const user = await authorize("viewer");
  if (!user) return denied;
  const parsed = profileSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);

  const supabase = await createClient();
  if (!supabase) return notConfigured;
  const { error } = await supabase
    .from("profiles")
    .update({
      full_name: parsed.data.full_name,
      bio: blank(parsed.data.bio),
      avatar_url: blank(parsed.data.avatar_url),
    })
    .eq("id", user.id);
  if (error) return dbError("updateProfile", error);

  revalidatePath("/dashboard", "layout");
  return { ok: true, message: "Profile saved." };
}

export async function updateUserRole(input: z.input<typeof roleUpdateSchema>): Promise<ActionResult> {
  const user = await authorize("admin");
  if (!user) return denied;
  const parsed = roleUpdateSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  if (parsed.data.user_id === user.id) {
    return { ok: false, message: "You cannot change your own role. Ask another admin." };
  }

  const supabase = await createClient();
  if (!supabase) return notConfigured;
  const { error, count } = await supabase
    .from("profiles")
    .update({ role: parsed.data.role }, { count: "exact" })
    .eq("id", parsed.data.user_id);
  if (error) return dbError("updateUserRole", error);
  if (!count) return denied;

  revalidatePath("/dashboard/team");
  return { ok: true, message: "Role updated." };
}

export async function inviteUser(input: z.input<typeof inviteSchema>): Promise<ActionResult> {
  const user = await authorize("admin");
  if (!user) return denied;
  const parsed = inviteSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);

  const admin = createAdminClient();
  if (!admin) {
    return {
      ok: false,
      message:
        "Invites need SUPABASE_SERVICE_ROLE_KEY on the server. Alternatively invite the user from Supabase → Authentication → Users.",
    };
  }

  const { data, error } = await admin.auth.admin.inviteUserByEmail(parsed.data.email, {
    redirectTo: `${siteUrl}/auth/confirm?next=/auth/update-password`,
  });
  if (error || !data.user) {
    console.error("[dashboard:inviteUser]", error?.code, error?.message);
    return {
      ok: false,
      message: error?.code === "email_exists" ? "That user already has an account." : "Invite failed.",
    };
  }

  if (parsed.data.role !== "viewer") {
    // Profile row is created by the auth trigger; set the requested role.
    await admin.from("profiles").update({ role: parsed.data.role }).eq("id", data.user.id);
  }

  revalidatePath("/dashboard/team");
  return { ok: true, message: `Invite sent to ${parsed.data.email}.` };
}

export async function setTeamMemberPublished(input: z.input<typeof toggleSchema>): Promise<ActionResult> {
  const user = await authorize("admin");
  if (!user) return denied;
  const parsed = toggleSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);

  const supabase = await createClient();
  if (!supabase) return notConfigured;
  const { error } = await supabase
    .from("team_members")
    .update({ is_published: parsed.data.value })
    .eq("id", parsed.data.id);
  if (error) return dbError("setTeamMemberPublished", error);

  revalidatePath("/dashboard/team");
  revalidatePath("/", "layout");
  return { ok: true, message: parsed.data.value ? "Profile is now public." : "Profile hidden from the website." };
}

/* ------------------------------------------------------- Site settings -- */

export async function upsertSiteSetting(input: z.input<typeof siteSettingSchema>): Promise<ActionResult> {
  const user = await authorize("admin");
  if (!user) return denied;
  const parsed = siteSettingSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);

  let value: Json;
  try {
    value = JSON.parse(parsed.data.value) as Json;
  } catch {
    value = parsed.data.value;
  }

  const supabase = await createClient();
  if (!supabase) return notConfigured;
  const { error } = await supabase.from("site_settings").upsert({ key: parsed.data.key, value }, { onConflict: "key" });
  if (error) return dbError("upsertSiteSetting", error);

  revalidatePath("/dashboard/settings");
  return { ok: true, message: "Setting saved." };
}

export async function deleteSiteSetting(id: string): Promise<ActionResult> {
  const user = await authorize("admin");
  if (!user) return denied;
  if (!uuid.safeParse(id).success) return { ok: false, message: "Invalid setting." };
  const supabase = await createClient();
  if (!supabase) return notConfigured;
  const { error } = await supabase.from("site_settings").delete().eq("id", id);
  if (error) return dbError("deleteSiteSetting", error);
  revalidatePath("/dashboard/settings");
  return { ok: true, message: "Setting deleted." };
}
