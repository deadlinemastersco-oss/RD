/** Uniform result shape returned by every Server Action. */
export type ActionResult<T = undefined> =
  | { ok: true; message?: string; data?: T }
  | { ok: false; message: string; fieldErrors?: Record<string, string[] | undefined> };

export const notConfigured: ActionResult = {
  ok: false,
  message: "The database is not connected yet. Add your Supabase keys to .env.local (see SETUP.md), then try again.",
};

export const genericError: ActionResult = {
  ok: false,
  message: "Something went wrong on our side. Please try again in a moment.",
};
