import "server-only";

/**
 * EMAIL NOTIFICATION EXTENSION POINT
 *
 * By default no email is sent — leads are stored in Supabase and admins get an
 * in-dashboard notification (via database trigger). The UI never claims an email
 * was sent.
 *
 * To enable email alerts with Resend (https://resend.com):
 *   1. Verify your sending domain in Resend.
 *   2. Add to .env.local / Vercel:
 *        RESEND_API_KEY=re_...
 *        LEAD_NOTIFICATION_TO=you@yourdomain.com
 *        LEAD_NOTIFICATION_FROM="Deadline Masters <alerts@yourdomain.com>"
 *   3. Redeploy. That's it — `notifyNewLead` below starts sending.
 *
 * To use SMTP or another provider instead, replace the body of `sendEmail`.
 */

type LeadSummary = {
  kind: "contact" | "diagnostic";
  name: string;
  email: string;
  company?: string | null;
  topic?: string | null;
  message?: string | null;
};

export function isEmailConfigured() {
  return Boolean(process.env.RESEND_API_KEY && process.env.LEAD_NOTIFICATION_TO && process.env.LEAD_NOTIFICATION_FROM);
}

async function sendEmail(to: string, subject: string, text: string) {
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ from: process.env.LEAD_NOTIFICATION_FROM, to, subject, text }),
    signal: AbortSignal.timeout(8000),
  });
  if (!res.ok) throw new Error(`Email provider responded with ${res.status}`);
}

/** Fire-and-forget internal alert. Never throws; never blocks the visitor's success response. */
export async function notifyNewLead(lead: LeadSummary) {
  if (!isEmailConfigured()) return { sent: false as const };
  try {
    const lines = [
      `New ${lead.kind === "contact" ? "contact request" : "diagnostic inquiry"}`,
      "",
      `Name: ${lead.name}`,
      `Email: ${lead.email}`,
      lead.company ? `Company: ${lead.company}` : null,
      lead.topic ? `Topic: ${lead.topic}` : null,
      "",
      lead.message ? lead.message.slice(0, 2000) : null,
      "",
      "Open the dashboard to respond.",
    ].filter((l): l is string => l !== null);
    await sendEmail(
      process.env.LEAD_NOTIFICATION_TO as string,
      `New lead: ${lead.name}`.slice(0, 120),
      lines.join("\n"),
    );
    return { sent: true as const };
  } catch (err) {
    console.error("[email] lead notification failed:", err instanceof Error ? err.message : "unknown error");
    return { sent: false as const };
  }
}
