import { useSyncExternalStore } from "react";

const noop = () => () => {};

/**
 * true only after hydration. Use before rendering portals so the first client
 * render matches the server HTML (avoids hydration mismatches).
 */
export function useIsClient() {
  return useSyncExternalStore(
    noop,
    () => true,
    () => false,
  );
}
