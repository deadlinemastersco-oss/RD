import { z } from "zod";
import { budgetOptions, diagnosticQuestions, serviceInterestOptions, timelineOptions } from "@/lib/constants/forms";

const values = <T extends readonly { value: string }[]>(opts: T) =>
  opts.map((o) => o.value) as unknown as [T[number]["value"], ...T[number]["value"][]];

const name = z
  .string()
  .trim()
  .min(2, "Please enter your name.")
  .max(120, "Please keep your name under 120 characters.");

const email = z
  .string()
  .trim()
  .min(1, "Please enter your email address.")
  .max(254, "That email address is too long.")
  .email("Please enter a valid email address.");

const optionalPhone = z
  .string()
  .trim()
  .max(40, "Phone number is too long.")
  .regex(/^[+()\d\s.-]*$/, "Use digits, spaces and + ( ) - only.");

const optionalText = (max: number, label = "This field") =>
  z.string().trim().max(max, `${label} must be under ${max} characters.`);

/** Honeypot + timing fields added to every public form. */
const antiSpam = {
  /** Hidden field. Humans leave it empty; many bots fill every input. */
  company_website: z.string().max(500).optional(),
  /** Epoch ms when the form was first rendered. Submissions faster than ~2s are treated as bots. */
  started_at: z.number().int().nonnegative().optional(),
};

export const contactSchema = z.object({
  full_name: name,
  email,
  phone: optionalPhone,
  company: optionalText(160, "Company"),
  service_interest: z.enum(values(serviceInterestOptions), { message: "Choose the closest option." }),
  budget_range: z.enum(values(budgetOptions), { message: "Choose a budget range." }),
  deadline: z.enum(values(timelineOptions), { message: "Choose a timeline." }),
  message: z
    .string()
    .trim()
    .min(20, "A few more details help — at least 20 characters.")
    .max(5000, "Please keep the message under 5,000 characters."),
  consent: z.boolean().refine((v) => v === true, "Please agree so we can reply to you."),
  ...antiSpam,
});
export type ContactInput = z.infer<typeof contactSchema>;

export const newsletterSchema = z.object({
  email,
  source: z.string().trim().max(60).optional(),
  ...antiSpam,
});
export type NewsletterInput = z.infer<typeof newsletterSchema>;

const choose = { message: "Please choose an option." };

export const diagnosticAnswersSchema = z.object({
  problem: z.enum(values(diagnosticQuestions.problem.options), choose),
  urgency: z.enum(values(diagnosticQuestions.urgency.options), choose),
  stage: z.enum(values(diagnosticQuestions.stage.options), choose),
  outcome: z.enum(values(diagnosticQuestions.outcome.options), choose),
});

export const diagnosticContactSchema = z.object({
  name,
  email,
  phone: optionalPhone,
  company: optionalText(160, "Company"),
  notes: optionalText(2000, "Notes"),
  consent: z.boolean().refine((v) => v === true, "Please agree so we can reply to you."),
  company_website: antiSpam.company_website,
});

export const diagnosticSubmissionSchema = diagnosticContactSchema.extend({
  answers: diagnosticAnswersSchema,
  started_at: antiSpam.started_at,
});
export type DiagnosticContactInput = z.infer<typeof diagnosticContactSchema>;
export type DiagnosticSubmissionInput = z.infer<typeof diagnosticSubmissionSchema>;

/** Convert "" → null for optional DB columns. */
export const nullIfEmpty = (v: string | null | undefined) => {
  const t = v?.trim();
  return t ? t : null;
};
