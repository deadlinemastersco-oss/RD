import { z } from "zod";

// z.guid() accepts any 8-4-4-4-12 hex id (z.uuid() in Zod v4 also enforces RFC version bits).
export const uuid = z.guid("Invalid identifier.");

export const leadStatusValues = ["new", "contacted", "qualified", "proposal_sent", "won", "lost", "archived"] as const;
export const projectStatusValues = ["planning", "active", "on_hold", "review", "completed", "cancelled"] as const;
export const taskStatusValues = ["todo", "in_progress", "blocked", "review", "done"] as const;
export const taskPriorityValues = ["low", "medium", "high", "urgent"] as const;
export const roleValues = ["admin", "team_member", "viewer"] as const;

export const leadTypeSchema = z.enum(["contact", "project"]);

export const updateLeadSchema = z.object({
  type: leadTypeSchema,
  id: uuid,
  status: z.enum(leadStatusValues).optional(),
  assigned_to: uuid.nullable().optional(),
});

export const leadNoteSchema = z.object({
  type: leadTypeSchema,
  id: uuid,
  body: z.string().trim().min(1, "Write a note first.").max(4000),
});

const dateString = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/, "Use a valid date.")
  .or(z.literal(""));

export const projectSchema = z
  .object({
    title: z.string().trim().min(2, "Give the project a title.").max(200),
    client_name: z.string().trim().max(160),
    description: z.string().trim().max(8000),
    status: z.enum(projectStatusValues),
    progress: z.number().int().min(0).max(100),
    start_date: dateString,
    due_date: dateString,
    owner_id: uuid.or(z.literal("")),
  })
  .refine((d) => !d.start_date || !d.due_date || d.due_date >= d.start_date, {
    message: "Due date must be on or after the start date.",
    path: ["due_date"],
  });
export type ProjectInput = z.infer<typeof projectSchema>;

export const taskSchema = z.object({
  project_id: uuid,
  title: z.string().trim().min(2, "Give the task a title.").max(200),
  description: z.string().trim().max(4000),
  status: z.enum(taskStatusValues),
  priority: z.enum(taskPriorityValues),
  assigned_to: uuid.or(z.literal("")),
  due_date: dateString,
});
export type TaskInput = z.infer<typeof taskSchema>;

export const taskStatusSchema = z.object({ id: uuid, status: z.enum(taskStatusValues) });

export const profileSchema = z.object({
  full_name: z.string().trim().min(2, "Enter your name.").max(120),
  bio: z.string().trim().max(2000),
  avatar_url: z.string().trim().url("Enter a full https:// URL.").max(1000).or(z.literal("")),
});
export type ProfileInput = z.infer<typeof profileSchema>;

export const roleUpdateSchema = z.object({ user_id: uuid, role: z.enum(roleValues) });

export const inviteSchema = z.object({
  email: z.string().trim().email("Enter a valid email.").max(254),
  role: z.enum(roleValues),
});

export const siteSettingSchema = z.object({
  key: z
    .string()
    .trim()
    .regex(/^[a-z0-9_.-]{2,80}$/, "Use 2–80 lowercase letters, numbers, dots, dashes or underscores."),
  value: z.string().max(20000),
});

export const toggleSchema = z.object({ id: uuid, value: z.boolean() });
