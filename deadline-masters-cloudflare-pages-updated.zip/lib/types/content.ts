/** UI-facing content models. Supabase rows are mapped into these in lib/data/content.ts. */

export type IconName =
  | "globe"
  | "layout-dashboard"
  | "pen-tool"
  | "workflow"
  | "trending-up"
  | "magnet"
  | "shield-check"
  | "zap"
  | "layers"
  | "compass";

export type ServiceCategory = "build" | "design" | "growth" | "operations";

export type Service = {
  slug: string;
  title: string;
  category: ServiceCategory;
  icon: IconName;
  shortDescription: string;
  fullDescription: string;
  problem: string;
  idealClient: string;
  whatWeDeliver: string[];
  process: { title: string; description: string }[];
  deliverables: string[];
  timeline: string;
  /** In the configured currency. null → "Custom quote". */
  startingPrice: number | null;
  /** Set true when the service touches legal/finance/compliance and needs the disclaimer. */
  needsProfessionalDisclaimer?: boolean;
};

export type CaseStudy = {
  slug: string;
  title: string;
  clientName: string;
  industry: string;
  services: string[]; // service slugs
  summary: string;
  challenge: string;
  approach: string;
  solution: string;
  outcome: string;
  technologies: string[];
  coverImage: string | null;
  gallery: string[];
  /** Illustrative blueprint (not a real client engagement). Rendered with a clear label. */
  isIllustrative: boolean;
  publishedAt: string | null;
};

export type TeamMember = {
  id: string;
  name: string;
  role: string;
  discipline: string;
  shortBio: string;
  fullBio: string;
  avatarUrl: string | null;
  skills: string[];
  socialLinks: Partial<Record<"linkedin" | "x" | "github" | "website", string>>;
  /** Placeholder profile — replace with real names in Supabase or lib/constants/content.ts. */
  isPlaceholder: boolean;
};

export type Testimonial = {
  id: string;
  clientName: string;
  clientRole: string | null;
  company: string | null;
  quote: string;
  avatarUrl: string | null;
  rating: number | null;
};

export type FAQ = { question: string; answer: string };

export type PricingTier = {
  id: string;
  name: string;
  tagline: string;
  /** In the configured currency. null → "Custom quote". */
  startingPrice: number | null;
  priceNote: string;
  timeline: string;
  bestFor: string;
  includes: string[];
  excludes?: string[];
  cta: { label: string; href: string };
  highlighted?: boolean;
};

export type ProcessStep = {
  id: string;
  index: string;
  title: string;
  summary: string;
  activities: string[];
  output: string;
  duration: string;
};
