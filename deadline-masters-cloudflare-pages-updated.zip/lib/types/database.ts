/**
 * Supabase database types for the Deadline Masters schema.
 *
 * Hand-written to match supabase/migrations/*. If you change the schema,
 * regenerate with:
 *   npx supabase gen types typescript --project-id <your-project-ref> --schema public > lib/types/database.ts
 */

export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export type UserRole = "admin" | "team_member" | "viewer";
export type LeadStatus = "new" | "contacted" | "qualified" | "proposal_sent" | "won" | "lost" | "archived";
export type ProjectStatus = "planning" | "active" | "on_hold" | "review" | "completed" | "cancelled";
export type TaskStatus = "todo" | "in_progress" | "blocked" | "review" | "done";
export type TaskPriority = "low" | "medium" | "high" | "urgent";
export type NotificationType = "info" | "success" | "warning" | "inquiry" | "task" | "system";

type Table<Row, Insert, Update = Partial<Insert>> = {
  Row: Row;
  Insert: Insert;
  Update: Update;
  Relationships: [];
};

export type ProfileRow = {
  id: string;
  full_name: string | null;
  email: string | null;
  avatar_url: string | null;
  role: UserRole;
  bio: string | null;
  created_at: string;
  updated_at: string;
};

export type ContactSubmissionRow = {
  id: string;
  full_name: string;
  email: string;
  phone: string | null;
  company: string | null;
  service_interest: string | null;
  budget_range: string | null;
  deadline: string | null;
  message: string;
  source: string;
  status: LeadStatus;
  assigned_to: string | null;
  consent_at: string | null;
  created_at: string;
  updated_at: string;
};

export type ProjectInquiryRow = {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  company: string | null;
  project_type: string | null;
  project_description: string | null;
  estimated_budget: string | null;
  desired_timeline: string | null;
  source: string;
  diagnostic: Json;
  recommended_service: string | null;
  status: LeadStatus;
  assigned_to: string | null;
  consent_at: string | null;
  created_at: string;
  updated_at: string;
};

export type InquiryNoteRow = {
  id: string;
  submission_type: "contact" | "project";
  submission_id: string;
  author_id: string | null;
  body: string;
  created_at: string;
};

export type NewsletterSubscriberRow = {
  id: string;
  email: string;
  source: string;
  is_subscribed: boolean;
  created_at: string;
};

export type ServiceRow = {
  id: string;
  slug: string;
  title: string;
  short_description: string | null;
  full_description: string | null;
  icon: string | null;
  starting_price: number | null;
  delivery_time: string | null;
  features: string[];
  details: Json;
  is_active: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
};

export type CaseStudyRow = {
  id: string;
  slug: string;
  title: string;
  client_name: string | null;
  industry: string | null;
  summary: string | null;
  challenge: string | null;
  approach: string | null;
  solution: string | null;
  outcome: string | null;
  cover_image: string | null;
  gallery: string[];
  technologies: string[];
  service_slugs: string[];
  is_published: boolean;
  created_at: string;
  updated_at: string;
};

export type TestimonialRow = {
  id: string;
  client_name: string;
  client_role: string | null;
  company: string | null;
  quote: string;
  avatar_url: string | null;
  rating: number | null;
  is_published: boolean;
  created_at: string;
};

export type TeamMemberRow = {
  id: string;
  name: string;
  role: string;
  short_bio: string | null;
  full_bio: string | null;
  avatar_url: string | null;
  skills: string[];
  social_links: Json;
  sort_order: number;
  is_published: boolean;
  created_at: string;
  updated_at: string;
};

export type ProjectRow = {
  id: string;
  title: string;
  client_name: string | null;
  description: string | null;
  status: ProjectStatus;
  progress: number;
  start_date: string | null;
  due_date: string | null;
  owner_id: string | null;
  created_at: string;
  updated_at: string;
};

export type ProjectTaskRow = {
  id: string;
  project_id: string;
  title: string;
  description: string | null;
  status: TaskStatus;
  priority: TaskPriority;
  assigned_to: string | null;
  due_date: string | null;
  created_at: string;
  updated_at: string;
};

export type NotificationRow = {
  id: string;
  user_id: string;
  title: string;
  message: string | null;
  type: NotificationType;
  link: string | null;
  is_read: boolean;
  created_at: string;
};

export type SiteSettingRow = {
  id: string;
  key: string;
  value: Json;
  updated_at: string;
};

type WithOptional<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;
type Auto = "id" | "created_at";
type AutoU = Auto | "updated_at";

export type Database = {
  __InternalSupabase: { PostgrestVersion: "13.0.5" };
  public: {
    Tables: {
      profiles: Table<
        ProfileRow,
        WithOptional<ProfileRow, AutoU | "full_name" | "email" | "avatar_url" | "role" | "bio">
      >;
      contact_submissions: Table<
        ContactSubmissionRow,
        WithOptional<
          ContactSubmissionRow,
          | AutoU
          | "phone"
          | "company"
          | "service_interest"
          | "budget_range"
          | "deadline"
          | "source"
          | "status"
          | "assigned_to"
          | "consent_at"
        >
      >;
      project_inquiries: Table<
        ProjectInquiryRow,
        WithOptional<
          ProjectInquiryRow,
          | AutoU
          | "phone"
          | "company"
          | "project_type"
          | "project_description"
          | "estimated_budget"
          | "desired_timeline"
          | "source"
          | "diagnostic"
          | "recommended_service"
          | "status"
          | "assigned_to"
          | "consent_at"
        >
      >;
      inquiry_notes: Table<InquiryNoteRow, WithOptional<InquiryNoteRow, Auto | "author_id">>;
      newsletter_subscribers: Table<
        NewsletterSubscriberRow,
        WithOptional<NewsletterSubscriberRow, Auto | "source" | "is_subscribed">
      >;
      services: Table<
        ServiceRow,
        WithOptional<
          ServiceRow,
          | AutoU
          | "short_description"
          | "full_description"
          | "icon"
          | "starting_price"
          | "delivery_time"
          | "features"
          | "details"
          | "is_active"
          | "sort_order"
        >
      >;
      case_studies: Table<
        CaseStudyRow,
        WithOptional<
          CaseStudyRow,
          | AutoU
          | "client_name"
          | "industry"
          | "summary"
          | "challenge"
          | "approach"
          | "solution"
          | "outcome"
          | "cover_image"
          | "gallery"
          | "technologies"
          | "service_slugs"
          | "is_published"
        >
      >;
      testimonials: Table<
        TestimonialRow,
        WithOptional<TestimonialRow, Auto | "client_role" | "company" | "avatar_url" | "rating" | "is_published">
      >;
      team_members: Table<
        TeamMemberRow,
        WithOptional<
          TeamMemberRow,
          AutoU | "short_bio" | "full_bio" | "avatar_url" | "skills" | "social_links" | "sort_order" | "is_published"
        >
      >;
      projects: Table<
        ProjectRow,
        WithOptional<
          ProjectRow,
          AutoU | "client_name" | "description" | "status" | "progress" | "start_date" | "due_date" | "owner_id"
        >
      >;
      project_tasks: Table<
        ProjectTaskRow,
        WithOptional<ProjectTaskRow, AutoU | "description" | "status" | "priority" | "assigned_to" | "due_date">
      >;
      notifications: Table<
        NotificationRow,
        WithOptional<NotificationRow, Auto | "message" | "type" | "link" | "is_read">
      >;
      site_settings: Table<SiteSettingRow, WithOptional<SiteSettingRow, "id" | "updated_at" | "value">>;
    };
    Views: { [_ in never]: never };
    Functions: {
      current_user_role: { Args: Record<PropertyKey, never>; Returns: UserRole };
      is_admin: { Args: Record<PropertyKey, never>; Returns: boolean };
      is_staff: { Args: Record<PropertyKey, never>; Returns: boolean };
    };
    Enums: {
      user_role: UserRole;
      lead_status: LeadStatus;
      project_status: ProjectStatus;
      task_status: TaskStatus;
      task_priority: TaskPriority;
      notification_type: NotificationType;
    };
    CompositeTypes: { [_ in never]: never };
  };
};
