# SETUP — Deadline Masters

A step-by-step guide from unzip to live site. Budget about 30 minutes.

**You need:** Node.js 20.9+ (22 LTS recommended), npm, a Supabase project, and (for deployment) a
Vercel account.

---

## 1. Install dependencies

```bash
cd deadline-masters
npm install
```

## 2. Create `.env.local`

```bash
cp .env.example .env.local
```

Open `.env.local` and fill in:

| Variable                                                           | Where to find it                                                                                                                    | Required              |
| ------------------------------------------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------- | --------------------- |
| `NEXT_PUBLIC_SUPABASE_URL`                                         | Supabase → Project Settings → **API** → Project URL                                                                                 | Yes                   |
| `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`                             | Supabase → Project Settings → **API Keys** → Publishable key (`sb_publishable_…`)                                                   | Yes (or the anon key) |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY`                                    | Older projects: Project Settings → **API** → `anon` `public` key. Use this **instead of** the publishable key if you don't have one | Alternative           |
| `SUPABASE_SERVICE_ROLE_KEY`                                        | Project Settings → API → `service_role` (or a Secret key `sb_secret_…`). **Server only.** Enables in-app team invites               | Optional              |
| `NEXT_PUBLIC_SITE_URL`                                             | `http://localhost:3000` locally; your real domain in production (no trailing slash)                                                 | Yes                   |
| `NEXT_PUBLIC_APP_NAME`                                             | `Deadline Masters`                                                                                                                  | Optional              |
| `RESEND_API_KEY`, `LEAD_NOTIFICATION_TO`, `LEAD_NOTIFICATION_FROM` | See step 11                                                                                                                         | Optional              |

> The Supabase **URL and publishable/anon key are designed to be public** — Row Level Security protects
> the data. The **service role key is a secret**: never commit it, never prefix it with `NEXT_PUBLIC_`,
> never paste it into client code. The code imports it only from `lib/supabase/admin.ts`, which is marked
> `server-only` so a build fails if a browser component ever imports it.

The site runs without any keys (fallback content, forms show a "not connected" message, dashboard shows
a setup screen), so you can preview the design first.

## 3. Run the database migrations

Supabase dashboard → **SQL Editor** → run these files in order (paste each, click **Run**):

1. `supabase/migrations/20260929000001_schema.sql`
2. `supabase/migrations/20260929000002_rls_policies.sql`
3. `supabase/migrations/20260929000003_storage.sql` (optional — image buckets)
4. `supabase/seed.sql` (services + placeholder team seats)

Details, CLI alternative and a full policy description: [`supabase/README.md`](supabase/README.md).

## 4. Configure Supabase Auth URLs

Supabase → **Authentication** → **URL Configuration**:

- **Site URL:** `http://localhost:3000` during development, then your production URL (e.g. `https://deadlinemasters.com`).
- **Redirect URLs** — add each of these:
  - `http://localhost:3000/auth/confirm`
  - `https://YOUR-DOMAIN/auth/confirm`
  - `https://*-YOUR-VERCEL-TEAM.vercel.app/auth/confirm` (optional, for preview deployments)

### Recommended: email templates

The `/auth/confirm` route supports both the default links and the more robust `token_hash` links.
For best reliability (links work even if opened in a different browser), update templates in
**Authentication → Emails → Templates**:

| Template       | Link to use                                                                              |
| -------------- | ---------------------------------------------------------------------------------------- |
| Confirm signup | `{{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&type=email&next=/dashboard`     |
| Magic link     | `{{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&type=magiclink&next=/dashboard` |
| Reset password | `{{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&type=recovery`                  |
| Invite user    | `{{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&type=invite`                    |

Optional hardening: **Authentication → Providers → Email** — keep "Confirm email" on. If only your team
should have accounts, turn **off** "Allow new users to sign up" after creating your accounts and use
invites instead (the sign-up page will then show a friendly "sign-ups closed" message).

## 5. Run locally

```bash
npm run dev          # http://localhost:3000
```

Other scripts:

```bash
npm run lint         # ESLint
npm run typecheck    # generates route types + tsc --noEmit
npm run build        # production build
npm run start        # serve the production build
npm run format       # Prettier
npm run check        # lint + typecheck + build
```

## 6. Create the first admin user

1. Visit `/auth/sign-up`, create your account and click the confirmation email link.
2. In the Supabase SQL editor run:
   ```sql
   update public.profiles set role = 'admin' where email = 'you@yourcompany.com';
   ```
3. Sign in at `/auth/sign-in` → you land on `/dashboard` with full access.
4. Add teammates: they sign up (or you invite them from **Dashboard → Team**, which needs
   `SUPABASE_SERVICE_ROLE_KEY`, or from Supabase → Authentication → Users → Invite). Then set their role
   to `team_member` or `admin` on the Team page.

Want sample data to explore the dashboard? In a **development** project only, run
`supabase/seed-demo.sql` (rows are tagged `[DEMO]`; cleanup SQL is included).

## 7. Deploy to Vercel

1. Push the project to a GitHub/GitLab/Bitbucket repository (`.env.local` is git-ignored).
2. Vercel → **Add New… → Project** → import the repository. Framework preset: **Next.js** (auto-detected).
   Build command `next build`, output handled automatically, Node.js 20+ (default 22 is fine).
3. **Environment Variables** (Settings → Environment Variables), for Production (and Preview if you use it):

   | Name                                   | Value                                   |
   | -------------------------------------- | --------------------------------------- |
   | `NEXT_PUBLIC_SUPABASE_URL`             | your project URL                        |
   | `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` | publishable key (or set `..._ANON_KEY`) |
   | `NEXT_PUBLIC_SITE_URL`                 | `https://your-domain.com`               |
   | `NEXT_PUBLIC_APP_NAME`                 | `Deadline Masters`                      |
   | `SUPABASE_SERVICE_ROLE_KEY`            | optional; mark as **Sensitive**         |
   | `RESEND_API_KEY` etc.                  | optional (step 11)                      |

4. **Deploy.** Then add the production URL to Supabase Auth (step 4) and set Supabase **Site URL** to it.
5. Verify: open `https://your-domain.com/api/health` — it reports (as true/false only) whether Supabase,
   the service role and email are configured.

> `NEXT_PUBLIC_*` values are baked in at build time. After changing them in Vercel, **redeploy**.

## 8. Connect a custom domain

1. Vercel → Project → **Settings → Domains** → add `yourdomain.com` and `www.yourdomain.com`.
2. At your DNS provider add the records Vercel shows (usually an `A` record `76.76.21.21` for the apex and a
   `CNAME` `cname.vercel-dns.com` for `www`). HTTPS is issued automatically.
3. Update `NEXT_PUBLIC_SITE_URL` in Vercel to the final domain and redeploy.
4. Update Supabase Auth **Site URL** and **Redirect URLs** to the final domain.
5. Submit `https://yourdomain.com/sitemap.xml` in Google Search Console.

## 9. Replace placeholder contact details and brand copy

Everything editable lives in `lib/constants/`:

| File                 | What to change                                                                 |
| -------------------- | ------------------------------------------------------------------------------ |
| `site.ts`            | **Email, phone, WhatsApp, address, hours, social links**, legal name, CTA text |
| `copy.ts`            | Home-page and About-page wording, trust indicators                             |
| `services.ts`        | Fallback service catalogue and starting prices (INR)                           |
| `engagement.ts`      | Pricing tiers, pricing notes, process steps, FAQs                              |
| `people-and-work.ts` | Fallback team seats and illustrative work blueprints                           |
| `forms.ts`           | Contact-form options (services, budgets, timelines) and diagnostic questions   |

Search the project for `example.com` and `00000 00000` to confirm nothing is left. Legal pages
(`app/(marketing)/privacy`, `terms`, `disclaimer`) are sensible templates — have a lawyer review them.

## 10. Manage services, case studies, testimonials and team

Use **Supabase → Table Editor**. Public pages refresh every 5 minutes (ISR).

- **services** — a row with the same `slug` as a built-in service overrides it; new slugs create new pages at
  `/services/<slug>`. `starting_price` empty = "Custom quote". `features` = bullet list. `details` (JSON) can
  hold `problem`, `idealClient`, `deliverables` (array), `process` (array of `{title, description}`),
  `category` (`build|design|growth|operations`), `needsProfessionalDisclaimer` (true/false). `is_active`
  controls visibility. `icon`: one of `globe, layout-dashboard, pen-tool, workflow, trending-up, magnet,
shield-check, zap, layers, compass`.
- **case_studies** — set `is_published = true` to show. As soon as one real case study is published, the
  illustrative blueprints disappear and the "publishing in progress" notice is removed.
  `service_slugs` drives the Service filter on `/work`. Upload images to the `public-assets` bucket and paste
  the public URL into `cover_image` / `gallery`.
- **testimonials** — only publish real quotes you have written permission to use. `is_published = true`.
- **team_members** — replace the four placeholder seats with real names, roles, bios and photos
  (`avatar_url`). Toggle visibility from **Dashboard → Team**. `social_links` JSON:
  `{"linkedin":"https://…","github":"https://…","x":"https://…","website":"https://…"}`.

## 11. Add email notifications later

By default new leads are saved to Supabase and admins get an in-dashboard notification. **No email is sent
and the site never claims one was.** To also email yourself:

1. Create a [Resend](https://resend.com) account and verify your domain.
2. Add to `.env.local` / Vercel:
   ```
   RESEND_API_KEY=re_xxx
   LEAD_NOTIFICATION_TO=you@yourdomain.com
   LEAD_NOTIFICATION_FROM="Deadline Masters <alerts@yourdomain.com>"
   ```
3. Redeploy. Alerts are sent after the response (`after()`), so visitors are never slowed down.

To use SMTP or another provider, replace `sendEmail()` in `lib/email.ts`. For **auth** emails (sign-up,
reset), configure custom SMTP in Supabase → Authentication → Emails → SMTP Settings — the built-in Supabase
sender is rate-limited and meant for testing.

## 12. Production checklist

- [ ] Real contact details in `lib/constants/site.ts`
- [ ] Prices confirmed in `services.ts` / `engagement.ts`
- [ ] Team seats replaced with real people
- [ ] Legal pages reviewed
- [ ] Supabase Site URL + Redirect URLs set to production domain
- [ ] Custom SMTP configured in Supabase Auth
- [ ] First admin created; public sign-up disabled if you only want invited users
- [ ] `/api/health` shows `supabaseConfigured: true`
- [ ] Rate limiting upgraded for high traffic (see README → Security)
