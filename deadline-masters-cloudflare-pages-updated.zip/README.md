# Deadline Masters

Production website and internal dashboard for **Deadline Masters** — a four-specialist digital execution
team (design, engineering, growth & automation, operations).

- **Public site:** home, about, services (+ detail pages), work (+ detail pages), process, pricing, contact,
  interactive diagnostic, privacy/terms/disclaimer, 404.
- **Team dashboard:** inquiry pipeline with owners, statuses and notes; projects and tasks; team and role
  management; notifications; profile and site settings.
- **Backend:** Supabase Postgres with Row Level Security on every table, Supabase Auth (password, magic link,
  password reset, invites), database-triggered notifications.

**→ Setup and deployment: see [SETUP.md](SETUP.md).** Database details: [supabase/README.md](supabase/README.md).

## Stack

| Layer       | Choice                                                                                   |
| ----------- | ---------------------------------------------------------------------------------------- |
| Framework   | Next.js 16 (App Router, Turbopack, React 19, Server Components, Server Actions, `proxy`) |
| Language    | TypeScript (strict)                                                                      |
| Styling     | Tailwind CSS v4 (design tokens in `app/globals.css`)                                     |
| Data & auth | Supabase (`@supabase/ssr` + `@supabase/supabase-js`), PostgreSQL, RLS, Storage           |
| Forms       | React Hook Form + Zod v4 (same schemas on client and server)                             |
| Motion      | Framer Motion (with `MotionConfig reducedMotion="user"`) + CSS keyframes                 |
| Icons       | Lucide React                                                                             |
| Charts      | Recharts (lazy-loaded, dashboard only)                                                   |
| Fonts       | Geist Sans/Mono (self-hosted via `geist`) + Instrument Serif italic (OFL, self-hosted)   |
| Quality     | ESLint (next/core-web-vitals + TS), Prettier (+ Tailwind plugin)                         |

## Quick start

```bash
npm install
cp .env.example .env.local   # add Supabase URL + publishable key
npm run dev
```

The site renders fully **without** Supabase keys using typed fallback content — useful for previewing.

## Project structure

```
app/
  (marketing)/          public pages sharing Navbar + Footer
    page.tsx            home
    about/ services/ services/[slug]/ work/ work/[slug]/ process/ pricing/
    contact/ diagnostic/ privacy/ terms/ disclaimer/
  (auth)/auth/          sign-in, sign-up, forgot-password, update-password, error, confirm (route handler)
  dashboard/            protected workspace: overview, inquiries, projects, projects/[id], tasks, team, settings
  api/health/           configuration health check (booleans only)
  sitemap.ts robots.ts opengraph-image.tsx icon.svg not-found.tsx error.tsx global-error.tsx
components/
  ui/                   Button, MagneticButton, AnimatedText, Reveal/Stagger, SectionHeading, StatusBadge,
                        EmptyState, LoadingSkeleton, Modal/Drawer, ConfirmDialog, Toast, DataTable,
                        FormField, ErrorBoundary, RouteProgress, JsonLd, Logo, CountUp
  marketing/            Navbar, MobileNav, Footer, Hero, ServiceCard, CaseStudyCard, TeamCard,
                        TestimonialCard, PricingCard, ProcessTimeline, FAQAccordion, ContactForm,
                        DiagnosticFlow, WorkGrid, NewsletterForm, CTASection, …
  dashboard/            DashboardSidebar (+ mobile drawer), NotificationCenter, ProtectedRoute, MetricCard,
                        InquiriesView, ProjectsView, ProjectDetail, TasksView, TeamView, settings forms
  auth/                 sign-in / sign-up / reset forms
lib/
  constants/            ALL editable copy, contact details, prices, FAQs, form options
  supabase/             client.ts (browser) · server.ts (cookies) · public.ts (cookie-less, ISR-safe)
                        · admin.ts (service role, server-only) · proxy.ts (session refresh + guards)
  actions/              Server Actions: public forms, auth, dashboard mutations
  data/                 content.ts (public content + fallbacks) · dashboard.ts (RLS-scoped queries)
  validations/          Zod schemas
  types/                database.ts (Supabase types) · content.ts (UI models)
  auth.ts               getSessionUser / requireUser / hasRole
  diagnostic.ts         rules-based recommendation engine
  email.ts              email extension point (Resend)
  rate-limit.ts         basic per-IP limiter
  seo.ts                metadata + JSON-LD helpers
proxy.ts                Next.js 16 proxy (formerly middleware) for /dashboard and /auth
supabase/               migrations, seed.sql, seed-demo.sql, README
```

## Content model and fallbacks

Marketing pages read from Supabase through a cookie-less client (so they stay static with 5-minute ISR)
and **fall back to typed constants** in `lib/constants/` when Supabase is not configured, unreachable or
empty. Nothing fabricated is shown as real:

- **Testimonials** — none ship. The section shows an honest "publishing with permission" state until real
  testimonials are published in Supabase.
- **Work** — ships three clearly-labelled **illustrative blueprints** (no client names, no metrics). They are
  replaced automatically by real published case studies.
- **Trust indicators** — factual statements about how the team works, not client counts or revenue.
- **Team** — four placeholder "seats" described by role until you add real people.

## Security

- **RLS on every table**, verified with role-by-role tests (anon, viewer, team member, admin). Visitors can
  insert leads but never read them; team members only see what is assigned to them; roles can only be
  changed by admins (enforced by a database trigger, not the UI).
- **Server-side auth**: `proxy.ts` refreshes the session and blocks `/dashboard` for signed-out users;
  every dashboard page and every Server Action re-verifies the user with `supabase.auth.getUser()` and
  reads the role from the database. Client-side checks are cosmetic only.
- **Service role key** is only referenced in `lib/supabase/admin.ts` (marked `server-only`), used only
  after an admin check, never logged. The health endpoint reports booleans only.
- **Validation**: Zod on client and server for every form; database `CHECK` constraints as a final layer
  (lengths, email format, enums). No raw SQL from the app — all queries use the Supabase query builder;
  search input is sanitised before PostgREST filters.
- **Spam**: hidden honeypot field + minimum fill-time check on public forms (bots get a fake success and
  nothing is stored), plus a per-IP rate limiter.
- **No unsanitised HTML**: user content is rendered as text. The only `dangerouslySetInnerHTML` is JSON-LD
  built from our own constants with `<` escaped.
- **Open-redirect protection** on all post-auth redirects (`safeNextPath`).
- **Headers**: `X-Content-Type-Options`, `X-Frame-Options: DENY`, `Referrer-Policy`, `Permissions-Policy`,
  HSTS, and `noindex` on `/dashboard` and `/auth`.
- **Secrets**: `.env*` files are git-ignored except `.env.example`.

### Rate limiting — upgrade path

`lib/rate-limit.ts` is an in-memory fixed-window limiter. On serverless platforms each instance has its own
memory, so treat it as a speed bump. For stronger protection:

1. **Vercel Firewall** → add a rate-limit rule for `POST` requests to `/contact` and `/diagnostic`, or
2. **Upstash Redis** → `npm i @upstash/ratelimit @upstash/redis`, then replace the body of `rateLimit()`
   with `Ratelimit.slidingWindow(...)` using `UPSTASH_REDIS_REST_URL` / `UPSTASH_REDIS_REST_TOKEN`.
3. Optionally add Cloudflare Turnstile to the contact form for CAPTCHA-style protection.

## Accessibility

Semantic landmarks and headings, skip link, visible `:focus-visible` rings, labelled inputs with linked
error messages (`aria-invalid`, `aria-describedby`), focus-trapped dialogs that close on Escape and restore
focus, keyboard-operable tables and accordions, status text alongside every colour badge, reduced-motion
support (Framer Motion `reducedMotion="user"` plus a global CSS rule), and chart summaries for screen
readers.

## Performance

Server Components by default; client components only where interaction is needed. Marketing pages are
statically generated with ISR. The hero headline animates with CSS so it paints before JavaScript loads.
Fonts are self-hosted. Recharts loads only on the dashboard overview. `next/image` for all raster images.

## Scripts

| Script              | Does                                   |
| ------------------- | -------------------------------------- |
| `npm run dev`       | Development server                     |
| `npm run build`     | Production build                       |
| `npm run start`     | Serve production build                 |
| `npm run lint`      | ESLint                                 |
| `npm run typecheck` | Route type generation + `tsc --noEmit` |
| `npm run format`    | Prettier write                         |
| `npm run check`     | Lint + typecheck + build               |

## Licences

Instrument Serif is licensed under the SIL Open Font License (`app/fonts/InstrumentSerif-OFL.txt`).
Geist is licensed under the SIL Open Font License via the `geist` package. All copy, illustrations and the
logo mark are original to this project.
