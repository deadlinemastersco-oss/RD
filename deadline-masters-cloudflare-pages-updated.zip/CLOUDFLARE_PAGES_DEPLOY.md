# Deadline Masters — Cloudflare Pages Deployment

## Important
This package is prepared for **Cloudflare Pages static deployment** only.

Cloudflare Pages static hosting can serve the exported Next.js frontend, but
Next.js server actions, API routes, server-side Supabase admin operations,
email sending, and other Node/server runtime features are not executed by a
plain static Pages deployment.

### Build configuration
- Framework preset: Next.js (Static HTML Export) / or None + custom build
- Build command: `npm run build`
- Build output directory: `out`
- Node version: 20 or newer

### Environment variables for the browser
Set only values that are safe to expose:
- NEXT_PUBLIC_SUPABASE_URL
- NEXT_PUBLIC_SUPABASE_ANON_KEY
- NEXT_PUBLIC_SITE_URL

### NEVER put these in NEXT_PUBLIC_ variables
- SUPABASE_SERVICE_ROLE_KEY
- RESEND_API_KEY
- any private API key

### If this project requires dashboard/server actions
Use a server-capable deployment (Cloudflare Workers/Pages Functions,
Vercel, or another Next.js server runtime) for those routes. Do not expose
the Supabase service-role key in client-side code.

## Before production
1. Run `npm ci`
2. Run `npm run build`
3. Confirm `out/` is generated
4. Test authentication and all forms
5. Test Supabase RLS with anonymous and authenticated users
6. Configure the custom domain
