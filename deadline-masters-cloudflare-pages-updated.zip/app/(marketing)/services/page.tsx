import type { Metadata } from "next";
import Link from "next/link";
import { ArrowUpRight, Check } from "lucide-react";
import { PageHeader } from "@/components/marketing/page-header";
import { CTASection } from "@/components/marketing/cta-section";
import { ProfessionalDisclaimer } from "@/components/marketing/professional-disclaimer";
import { ServiceIcon } from "@/components/ui/icon";
import { ButtonLink } from "@/components/ui/button";
import { Reveal } from "@/components/ui/reveal";
import { Accent } from "@/components/ui/section-heading";
import { JsonLd } from "@/components/ui/json-ld";
import { getServices } from "@/lib/data/content";
import { buildMetadata } from "@/lib/seo";
import { siteConfig } from "@/lib/constants/site";
import { absoluteUrl, formatPrice } from "@/lib/utils";
import type { ServiceCategory } from "@/lib/types/content";

export const revalidate = 300;

export const metadata: Metadata = buildMetadata({
  title: "Services & capabilities",
  description:
    "Websites and web apps, SaaS dashboards and MVPs, UI/UX design, AI workflow automation, SEO and content, lead-generation systems, and operations and compliance coordination.",
  path: "/services",
});

const categoryLabel: Record<ServiceCategory, string> = {
  build: "Build",
  design: "Design",
  growth: "Growth",
  operations: "Operations",
};

export default async function ServicesPage() {
  const { services } = await getServices();

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    itemListElement: services.map((s, i) => ({
      "@type": "ListItem",
      position: i + 1,
      url: absoluteUrl(`/services/${s.slug}`),
      name: s.title,
    })),
  };

  return (
    <>
      <JsonLd data={jsonLd} />
      <PageHeader
        eyebrow="Capabilities"
        title={
          <>
            Everything behind a business that <Accent>moves fast.</Accent>
          </>
        }
        description="Choose one capability, or let us combine several into a single, coordinated engagement."
      >
        <nav aria-label="Jump to a service">
          <ul className="flex flex-wrap gap-2">
            {services.map((s) => (
              <li key={s.slug}>
                <a
                  href={`#${s.slug}`}
                  className="inline-flex items-center gap-2 rounded-full border border-line-strong px-3.5 py-1.5 text-sm text-fg-muted transition-colors hover:border-fg/40 hover:text-fg"
                >
                  <ServiceIcon name={s.icon} className="size-3.5 text-lime" />
                  {s.title}
                </a>
              </li>
            ))}
          </ul>
        </nav>
      </PageHeader>

      <div className="container-page space-y-6 pb-8">
        {services.map((s, i) => (
          <Reveal key={s.slug} as="article">
            <section id={s.slug} aria-labelledby={`${s.slug}-title`} className="card scroll-mt-28 overflow-hidden">
              <div className="grid lg:grid-cols-12">
                {/* Left: summary */}
                <div className="border-b border-line p-7 sm:p-10 lg:col-span-5 lg:border-r lg:border-b-0">
                  <div className="flex items-center gap-3">
                    <span className="grid size-11 place-items-center rounded-xl border border-line-strong bg-surface-2">
                      <ServiceIcon name={s.icon} className="size-5 text-lime" />
                    </span>
                    <span className="label-mono text-fg-subtle">
                      {String(i + 1).padStart(2, "0")} · {categoryLabel[s.category]}
                    </span>
                  </div>
                  <h2 id={`${s.slug}-title`} className="mt-8 text-3xl font-semibold tracking-tight">
                    {s.title}
                  </h2>
                  <p className="mt-4 leading-relaxed text-fg-muted">{s.fullDescription}</p>

                  <dl className="mt-8 grid grid-cols-2 gap-4 border-t border-line pt-6 text-sm">
                    <div>
                      <dt className="label-mono text-fg-subtle">Timeline</dt>
                      <dd className="mt-1.5">{s.timeline}</dd>
                    </div>
                    <div>
                      <dt className="label-mono text-fg-subtle">
                        {s.startingPrice === null ? "Pricing" : "Starting from"}
                      </dt>
                      <dd className="mt-1.5">{formatPrice(s.startingPrice)}</dd>
                    </div>
                  </dl>

                  <div className="mt-8 flex flex-wrap gap-3">
                    <ButtonLink href={`/contact?service=${s.slug}`} size="sm">
                      {siteConfig.cta.primary.label}
                    </ButtonLink>
                    <ButtonLink href={`/services/${s.slug}`} variant="outline" size="sm">
                      Full details <ArrowUpRight className="size-3.5" aria-hidden />
                    </ButtonLink>
                  </div>
                </div>

                {/* Right: problem / ideal client / delivery / process */}
                <div className="grid gap-8 p-7 sm:p-10 md:grid-cols-2 lg:col-span-7">
                  <div>
                    <h3 className="label-mono text-lime">The problem</h3>
                    <p className="mt-3 text-sm leading-relaxed text-fg-muted">{s.problem}</p>
                  </div>
                  <div>
                    <h3 className="label-mono text-lime">Ideal client</h3>
                    <p className="mt-3 text-sm leading-relaxed text-fg-muted">{s.idealClient}</p>
                  </div>
                  <div>
                    <h3 className="label-mono text-lime">What we deliver</h3>
                    <ul className="mt-3 space-y-2 text-sm">
                      {s.whatWeDeliver.map((d) => (
                        <li key={d} className="flex gap-2">
                          <Check className="mt-0.5 size-4 shrink-0 text-lime/80" aria-hidden />
                          {d}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h3 className="label-mono text-lime">Process</h3>
                    <ol className="mt-3 space-y-3 text-sm">
                      {s.process.map((p, idx) => (
                        <li key={p.title} className="flex gap-3">
                          <span className="font-mono text-xs text-fg-subtle">{String(idx + 1).padStart(2, "0")}</span>
                          <span>
                            <span className="font-medium">{p.title}</span>
                            <span className="block text-fg-muted">{p.description}</span>
                          </span>
                        </li>
                      ))}
                    </ol>
                  </div>
                  <div className="md:col-span-2">
                    <h3 className="label-mono text-lime">Deliverables</h3>
                    <ul className="mt-3 flex flex-wrap gap-2">
                      {s.deliverables.map((d) => (
                        <li key={d} className="rounded-full border border-line px-3 py-1 text-xs text-fg-muted">
                          {d}
                        </li>
                      ))}
                    </ul>
                  </div>
                  {s.needsProfessionalDisclaimer ? <ProfessionalDisclaimer compact className="md:col-span-2" /> : null}
                </div>
              </div>
            </section>
          </Reveal>
        ))}

        <p className="pt-4 text-sm text-fg-subtle">
          Prices are starting points in INR, excluding taxes. Final pricing depends on scope —{" "}
          <Link href="/pricing" className="text-fg underline underline-offset-4">
            see how we price
          </Link>
          .
        </p>
      </div>

      <CTASection
        title="Not sure which capability you need?"
        body="Describe the situation. We will recommend the smallest effective engagement — or tell you if you do not need us."
      />
    </>
  );
}
