import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowUpRight, Check, Clock, Wallet } from "lucide-react";
import { CTASection } from "@/components/marketing/cta-section";
import { ServiceCard } from "@/components/marketing/service-card";
import { ProfessionalDisclaimer } from "@/components/marketing/professional-disclaimer";
import { ButtonLink } from "@/components/ui/button";
import { ServiceIcon } from "@/components/ui/icon";
import { JsonLd } from "@/components/ui/json-ld";
import { MagneticButton } from "@/components/ui/magnetic-button";
import { Reveal, Stagger, StaggerItem } from "@/components/ui/reveal";
import { SectionLabel } from "@/components/ui/section-heading";
import { getService, getServices } from "@/lib/data/content";
import { fallbackServices } from "@/lib/constants/services";
import { siteConfig } from "@/lib/constants/site";
import { breadcrumbJsonLd, buildMetadata } from "@/lib/seo";
import { absoluteUrl, formatPrice } from "@/lib/utils";

export const revalidate = 300;
// New services added in Supabase are rendered on demand, then cached.
export const dynamicParams = true;

export async function generateStaticParams() {
  return fallbackServices.map((s) => ({ slug: s.slug }));
}

export async function generateMetadata({ params }: PageProps<"/services/[slug]">): Promise<Metadata> {
  const { slug } = await params;
  const service = await getService(slug);
  if (!service) return { title: "Service not found", robots: { index: false } };
  return buildMetadata({
    title: service.title,
    description: service.shortDescription,
    path: `/services/${service.slug}`,
  });
}

export default async function ServicePage({ params }: PageProps<"/services/[slug]">) {
  const { slug } = await params;
  const [service, { services }] = await Promise.all([getService(slug), getServices()]);
  if (!service) notFound();

  const related = services
    .filter((s) => s.slug !== service.slug)
    .sort((a, b) => Number(b.category === service.category) - Number(a.category === service.category))
    .slice(0, 3);

  const serviceJsonLd = {
    "@context": "https://schema.org",
    "@type": "Service",
    name: service.title,
    description: service.fullDescription,
    serviceType: service.title,
    url: absoluteUrl(`/services/${service.slug}`),
    provider: { "@id": `${siteConfig.url}/#organization` },
    areaServed: ["IN", "Worldwide"],
    ...(service.startingPrice !== null
      ? {
          offers: {
            "@type": "Offer",
            priceCurrency: siteConfig.currency.code,
            priceSpecification: {
              "@type": "PriceSpecification",
              minPrice: service.startingPrice,
              priceCurrency: siteConfig.currency.code,
            },
          },
        }
      : {}),
  };

  return (
    <>
      <JsonLd
        data={[
          serviceJsonLd,
          breadcrumbJsonLd([
            { name: "Home", path: "/" },
            { name: "Services", path: "/services" },
            { name: service.title, path: `/services/${service.slug}` },
          ]),
        ]}
      />

      <section className="noise relative isolate overflow-hidden pt-32 pb-16 md:pt-40">
        <div aria-hidden className="bg-grid bg-grid-fade absolute inset-0 -z-10" />
        <div className="container-page">
          <Link href="/services" className="inline-flex items-center gap-2 text-sm text-fg-muted hover:text-fg">
            <ArrowLeft className="size-4" aria-hidden /> All capabilities
          </Link>

          <div className="mt-10 grid gap-12 lg:grid-cols-12">
            <div className="lg:col-span-8">
              <span className="grid size-14 place-items-center rounded-2xl border border-line-strong bg-surface-2">
                <ServiceIcon name={service.icon} className="size-6 text-lime" />
              </span>
              <h1 className="mt-8 text-4xl leading-[1.02] font-semibold tracking-[-0.04em] sm:text-6xl">
                {service.title}
              </h1>
              <p className="mt-6 max-w-2xl text-xl leading-relaxed text-fg-muted">{service.fullDescription}</p>
            </div>

            <aside className="lg:col-span-4" aria-label="Engagement summary">
              <div className="glass rounded-3xl border border-line-strong p-6">
                <dl className="space-y-5">
                  <div className="flex items-start gap-3">
                    <Wallet className="mt-0.5 size-4 text-lime" aria-hidden />
                    <div>
                      <dt className="label-mono text-fg-subtle">
                        {service.startingPrice === null ? "Pricing" : "Starting from"}
                      </dt>
                      <dd className="mt-1 text-2xl font-semibold">{formatPrice(service.startingPrice)}</dd>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Clock className="mt-0.5 size-4 text-lime" aria-hidden />
                    <div>
                      <dt className="label-mono text-fg-subtle">Suggested timeline</dt>
                      <dd className="mt-1">{service.timeline}</dd>
                    </div>
                  </div>
                </dl>
                <MagneticButton className="mt-6 w-full">
                  <ButtonLink href={`/contact?service=${service.slug}`} className="w-full">
                    {siteConfig.cta.primary.label} <ArrowUpRight className="size-4" aria-hidden />
                  </ButtonLink>
                </MagneticButton>
                <p className="mt-3 text-center text-xs text-fg-subtle">Final pricing depends on scope. Excl. taxes.</p>
              </div>
            </aside>
          </div>
        </div>
      </section>

      <div className="container-page grid gap-6 pb-12 md:grid-cols-2">
        <Reveal className="card p-8">
          <SectionLabel index="01">The problem</SectionLabel>
          <p className="mt-5 text-lg leading-relaxed">{service.problem}</p>
        </Reveal>
        <Reveal className="card p-8" delay={0.05}>
          <SectionLabel index="02">Ideal client</SectionLabel>
          <p className="mt-5 text-lg leading-relaxed">{service.idealClient}</p>
        </Reveal>
      </div>

      <section className="container-page grid gap-12 py-12 lg:grid-cols-12" aria-labelledby="deliver-heading">
        <div className="lg:col-span-5">
          <SectionLabel index="03">What we deliver</SectionLabel>
          <h2 id="deliver-heading" className="mt-5 text-3xl font-semibold tracking-tight">
            Scope you can hold us to.
          </h2>
          <ul className="mt-8 space-y-4">
            {service.whatWeDeliver.map((d) => (
              <li key={d} className="flex gap-3 border-b border-line pb-4">
                <Check className="mt-0.5 size-5 shrink-0 text-lime" aria-hidden />
                <span>{d}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="lg:col-span-7">
          <SectionLabel index="04">Process</SectionLabel>
          <Stagger as="ol" className="mt-5 grid gap-3 sm:grid-cols-2">
            {service.process.map((p, i) => (
              <StaggerItem key={p.title} as="li" className="card p-6">
                <span className="font-mono text-sm text-lime">{String(i + 1).padStart(2, "0")}</span>
                <h3 className="mt-4 text-lg font-semibold">{p.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-fg-muted">{p.description}</p>
              </StaggerItem>
            ))}
          </Stagger>

          <div className="mt-10">
            <SectionLabel index="05">Deliverables</SectionLabel>
            <ul className="mt-5 flex flex-wrap gap-2">
              {service.deliverables.map((d) => (
                <li key={d} className="rounded-full border border-line-strong px-3.5 py-1.5 text-sm">
                  {d}
                </li>
              ))}
            </ul>
          </div>

          {service.needsProfessionalDisclaimer ? <ProfessionalDisclaimer className="mt-10" /> : null}
        </div>
      </section>

      {related.length ? (
        <section className="container-page py-16" aria-labelledby="related-heading">
          <h2 id="related-heading" className="text-2xl font-semibold tracking-tight">
            Often combined with
          </h2>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {related.map((s) => (
              <ServiceCard key={s.slug} service={s} index={services.findIndex((x) => x.slug === s.slug)} />
            ))}
          </div>
        </section>
      ) : null}

      <CTASection
        title={`Ready to start on ${service.title}?`}
        body="Tell us the problem and your deadline. You will get a candid reply within one business day."
      />
    </>
  );
}
