import type { Metadata } from "next";
import { Check } from "lucide-react";
import { PageHeader } from "@/components/marketing/page-header";
import { TeamSection } from "@/components/marketing/team-section";
import { CTASection } from "@/components/marketing/cta-section";
import { ProfessionalDisclaimer } from "@/components/marketing/professional-disclaimer";
import { Accent, SectionHeading, SectionLabel } from "@/components/ui/section-heading";
import { Reveal, Stagger, StaggerItem } from "@/components/ui/reveal";
import { getTeam } from "@/lib/data/content";
import { aboutCopy } from "@/lib/constants/copy";
import { buildMetadata } from "@/lib/seo";

export const revalidate = 300;

export const metadata: Metadata = buildMetadata({
  title: "About",
  description:
    "Deadline Masters is a four-specialist team covering product design, engineering, digital growth and business operations — one coordinated team for businesses that cannot afford to slow down.",
  path: "/about",
});

const disciplines = [
  { name: "Design", color: "bg-violet", body: "Research, interfaces and design systems." },
  { name: "Engineering", color: "bg-cyan", body: "Websites, SaaS, dashboards and integrations." },
  { name: "Growth", color: "bg-amber", body: "SEO, content, social and automation." },
  { name: "Operations", color: "bg-lime", body: "Pipeline, finance workflows and compliance coordination." },
];

export default async function AboutPage() {
  const team = await getTeam();
  const { story, mission, values, principles, advantage } = aboutCopy;

  return (
    <>
      <PageHeader
        eyebrow="About Deadline Masters"
        title={
          <>
            A small team built for <Accent>serious</Accent> execution.
          </>
        }
        description="Four senior specialists who plan together, build together and answer to one deadline — yours."
      />

      {/* Story */}
      <section className="container-page grid gap-12 pb-24 lg:grid-cols-12" aria-labelledby="story-heading">
        <div className="lg:col-span-4">
          <SectionLabel index="01">{story.eyebrow}</SectionLabel>
        </div>
        <div className="lg:col-span-8">
          <Reveal>
            <h2 id="story-heading" className="text-3xl leading-tight font-semibold tracking-[-0.03em] sm:text-4xl">
              {story.title}
            </h2>
          </Reveal>
          <div className="mt-8 space-y-5 text-lg leading-relaxed text-fg-muted">
            {story.paragraphs.map((p, i) => (
              <Reveal key={i} delay={0.05 * i}>
                <p>{p}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Mission */}
      <section
        className="noise relative overflow-hidden border-y border-line bg-surface/40 py-24"
        aria-labelledby="mission-heading"
      >
        <div aria-hidden className="bg-grid bg-grid-fade absolute inset-0" />
        <div className="container-page relative text-center">
          <SectionLabel index="02" className="justify-center">
            {mission.eyebrow}
          </SectionLabel>
          <Reveal>
            <p
              id="mission-heading"
              className="mx-auto mt-8 max-w-4xl text-3xl leading-snug font-medium tracking-[-0.02em] sm:text-5xl"
            >
              “{mission.statement}”
            </p>
          </Reveal>
        </div>
      </section>

      {/* Values */}
      <section className="container-page py-24 md:py-32" aria-labelledby="values-heading">
        <SectionHeading
          index="03"
          eyebrow="Values"
          title={
            <span id="values-heading">
              What we <Accent>hold</Accent> ourselves to.
            </span>
          }
        />
        <Stagger className="mt-14 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {values.map((v, i) => (
            <StaggerItem key={v.title} className="card p-7">
              <span className="label-mono text-lime">0{i + 1}</span>
              <h3 className="mt-6 text-xl font-semibold tracking-tight">{v.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-fg-muted">{v.body}</p>
            </StaggerItem>
          ))}
        </Stagger>
      </section>

      {/* Multidisciplinary advantage */}
      <section className="border-y border-line bg-surface/30 py-24 md:py-32" aria-labelledby="advantage-heading">
        <div className="container-page grid items-center gap-16 lg:grid-cols-2">
          <SectionHeading
            index="04"
            eyebrow={advantage.eyebrow}
            title={<span id="advantage-heading">{advantage.title}</span>}
            description={advantage.body}
          />
          <Reveal>
            <div className="grid grid-cols-2 gap-3" aria-label="Our four disciplines">
              {disciplines.map((d) => (
                <div key={d.name} className="card relative overflow-hidden p-6">
                  <span
                    aria-hidden
                    className={`absolute -top-6 -right-6 size-20 rounded-full opacity-20 blur-xl ${d.color}`}
                  />
                  <span aria-hidden className={`block size-2 rounded-full ${d.color}`} />
                  <p className="mt-5 text-lg font-semibold">{d.name}</p>
                  <p className="mt-1 text-sm text-fg-muted">{d.body}</p>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      <TeamSection team={team} index="05" />

      {/* Principles */}
      <section className="container-page pb-8" aria-labelledby="principles-heading">
        <div className="grid gap-12 rounded-[2rem] border border-line p-8 md:p-12 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <SectionLabel index="06">Working principles</SectionLabel>
            <h2 id="principles-heading" className="mt-6 text-3xl font-semibold tracking-tight">
              How every engagement runs.
            </h2>
          </div>
          <ul className="grid gap-x-8 gap-y-5 sm:grid-cols-2 lg:col-span-8">
            {principles.map((p) => (
              <li key={p} className="flex gap-3 border-b border-line pb-5">
                <Check className="mt-1 size-4 shrink-0 text-lime" aria-hidden />
                <span className="text-lg">{p}</span>
              </li>
            ))}
          </ul>
        </div>
        <ProfessionalDisclaimer className="mt-8" />
      </section>

      <CTASection />
    </>
  );
}
