import type { Metadata } from "next";
import { LegalPage } from "@/components/marketing/legal-page";
import { legalDisclaimer, siteConfig } from "@/lib/constants/site";
import { buildMetadata } from "@/lib/seo";

export const metadata: Metadata = buildMetadata({
  title: "Terms of service",
  description: `Terms that apply to using the ${siteConfig.name} website.`,
  path: "/terms",
});

export default function TermsPage() {
  return (
    <LegalPage
      eyebrow="Legal"
      title="Terms of service"
      updated="29 September 2026"
      intro={
        <p>
          These terms govern your use of this website. Client engagements are governed by the specific proposal and
          agreement signed for that engagement; where those documents conflict with these terms, the signed agreement
          applies.
        </p>
      }
      sections={[
        {
          heading: "Use of the website",
          body: (
            <p>
              You may use this website to learn about our services and to contact us. Do not misuse it, attempt to gain
              unauthorised access, or submit content that is unlawful or that you do not have the right to share.
            </p>
          ),
        },
        {
          heading: "Information on this site",
          body: (
            <p>
              Content is provided for general information. Prices are indicative starting points and are not offers; a
              binding price exists only in a signed proposal. Illustrative blueprints on the Work page describe
              approaches, not client results.
            </p>
          ),
        },
        {
          heading: "Professional services",
          body: <p>{legalDisclaimer}</p>,
        },
        {
          heading: "Diagnostic tool",
          body: (
            <p>
              The diagnostic produces an automated, rules-based suggestion to help start a conversation. It is not
              professional advice and should not be relied on as such.
            </p>
          ),
        },
        {
          heading: "Intellectual property",
          body: (
            <p>
              The website design, copy and code are owned by {siteConfig.legalName} unless stated otherwise. Ownership
              of work produced for clients is set out in each client agreement.
            </p>
          ),
        },
        {
          heading: "Liability",
          body: (
            <p>
              To the extent permitted by law, we are not liable for losses arising from use of this website or reliance
              on its general content.
            </p>
          ),
        },
        {
          heading: "Governing law",
          body: (
            <p>
              These terms are governed by the laws of India. Courts at the location of our registered office have
              jurisdiction, subject to any mandatory rights you have under local law.
            </p>
          ),
        },
        {
          heading: "Changes",
          body: <p>We may update these terms. The date at the top of this page shows when they last changed.</p>,
        },
      ]}
    />
  );
}
