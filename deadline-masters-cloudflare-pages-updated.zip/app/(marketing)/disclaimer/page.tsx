import type { Metadata } from "next";
import { LegalPage } from "@/components/marketing/legal-page";
import { legalDisclaimer, siteConfig } from "@/lib/constants/site";
import { buildMetadata } from "@/lib/seo";

export const metadata: Metadata = buildMetadata({
  title: "Professional services disclaimer",
  description: `${siteConfig.name} is not a law firm or chartered accountancy. How legal, tax and finance-related work is delivered.`,
  path: "/disclaimer",
});

export default function DisclaimerPage() {
  return (
    <LegalPage
      eyebrow="Legal"
      title="Professional services disclaimer"
      updated="29 September 2026"
      intro={<p>{legalDisclaimer}</p>}
      sections={[
        {
          heading: "What we do",
          body: (
            <ul>
              <li>Organise documents, records and recurring obligations.</li>
              <li>Design operational, finance and approval workflows.</li>
              <li>Prepare drafts, checklists and templates for review by qualified professionals.</li>
              <li>Coordinate with your chartered accountant, company secretary, lawyer or other licensed advisors.</li>
            </ul>
          ),
        },
        {
          heading: "What we do not do",
          body: (
            <ul>
              <li>Provide legal opinions or represent you in legal matters.</li>
              <li>File tax returns, conduct audits or certify financial statements.</li>
              <li>Give personalised investment or regulated financial advice.</li>
            </ul>
          ),
        },
        {
          heading: "How regulated work is handled",
          body: (
            <p>
              Where a task legally requires a licensed professional, it is performed by — or under the responsibility of
              — a qualified professional whom you engage directly or whom we introduce with your agreement. Their fees
              and terms are separate and disclosed in advance.
            </p>
          ),
        },
        {
          heading: "No reliance",
          body: (
            <p>
              General information on this website, including the diagnostic tool, is not legal, tax or financial advice.
              Consult a licensed professional about your specific situation.
            </p>
          ),
        },
      ]}
    />
  );
}
