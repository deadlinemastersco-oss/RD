import type { Metadata } from "next";
import { PageHeader } from "@/components/marketing/page-header";
import { DiagnosticFlow } from "@/components/marketing/diagnostic-flow";
import { Accent } from "@/components/ui/section-heading";
import { buildMetadata } from "@/lib/seo";

export const metadata: Metadata = buildMetadata({
  title: "Project diagnostic",
  description:
    "Answer four questions about your situation and get a suggested service path and engagement model from Deadline Masters.",
  path: "/diagnostic",
});

export default function DiagnosticPage() {
  return (
    <>
      <PageHeader
        eyebrow="Situation assessment · 2 minutes"
        title={
          <>
            Find the <Accent>right</Accent> starting point.
          </>
        }
        description="Four questions. An instant, rules-based suggestion. Optionally, a specialist's review of your answers."
      />
      <section className="container-page pb-8" aria-label="Diagnostic">
        <div className="mx-auto max-w-5xl">
          <DiagnosticFlow />
          <p className="mt-6 text-center text-xs text-fg-subtle">
            Your answers are only stored if you choose to send them for review.
          </p>
        </div>
      </section>
    </>
  );
}
