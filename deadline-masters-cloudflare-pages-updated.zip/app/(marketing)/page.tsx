import type { Metadata } from "next";
import { ArrowRight } from "lucide-react";
import { Hero } from "@/components/marketing/hero";
import { TrustStrip } from "@/components/marketing/trust-strip";
import { ServicesOverview } from "@/components/marketing/services-overview";
import { WhySection } from "@/components/marketing/why-section";
import { TeamSection } from "@/components/marketing/team-section";
import { FeaturedWork } from "@/components/marketing/featured-work";
import { ProcessTimeline } from "@/components/marketing/process-timeline";
import { PricingCard } from "@/components/marketing/pricing-card";
import { TestimonialsSection } from "@/components/marketing/testimonials-section";
import { FAQAccordion } from "@/components/marketing/faq-accordion";
import { CTASection } from "@/components/marketing/cta-section";
import { NewsletterForm } from "@/components/marketing/newsletter-form";
import { ButtonLink } from "@/components/ui/button";
import { JsonLd } from "@/components/ui/json-ld";
import { Reveal } from "@/components/ui/reveal";
import { Accent, SectionHeading } from "@/components/ui/section-heading";
import { getCaseStudies, getServices, getTeam, getTestimonials } from "@/lib/data/content";
import { faqs, pricingTiers, processSteps } from "@/lib/constants/engagement";
import { siteConfig } from "@/lib/constants/site";
import { buildMetadata } from "@/lib/seo";

export const revalidate = 300;

export const metadata: Metadata = {
  ...buildMetadata({
    title: `${siteConfig.name} — Digital execution for ambitious businesses`,
    description: siteConfig.description,
    path: "/",
  }),
  title: { absolute: `${siteConfig.name} — Digital execution for ambitious businesses` },
};

export default async function HomePage() {
  const [{ services }, work, team, testimonials] = await Promise.all([
    getServices(),
    getCaseStudies(),
    getTeam(),
    getTestimonials(),
  ]);

  const faqJsonLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({
      "@type": "Question",
      name: f.question,
      acceptedAnswer: { "@type": "Answer", text: f.answer },
    })),
  };

  return (
    <>
      <JsonLd data={faqJsonLd} />
      <Hero />
      <TrustStrip />
      <ServicesOverview services={services} />
      <WhySection />
      <TeamSection team={team} />
      <FeaturedWork items={work.items} fromDatabase={work.fromDatabase} />

      {/* Process */}
      <section className="border-y border-line bg-surface/30 py-24 md:py-32" aria-labelledby="process-heading">
        <div className="container-page grid gap-16 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <div className="lg:sticky lg:top-28">
              <SectionHeading
                index="05"
                eyebrow="Process"
                title={
                  <span id="process-heading">
                    From first call to <Accent>live</Accent> system.
                  </span>
                }
                description="Seven clear stages. You always know what is happening, what comes next and what you will receive."
              />
              <Reveal delay={0.1}>
                <ButtonLink href="/process" variant="outline" className="mt-8">
                  See the full process <ArrowRight className="size-4" aria-hidden />
                </ButtonLink>
              </Reveal>
            </div>
          </div>
          <div className="lg:col-span-7">
            <ProcessTimeline steps={processSteps} variant="compact" />
          </div>
        </div>
      </section>

      {/* Engagement models */}
      <section className="container-page py-24 md:py-32" aria-labelledby="pricing-heading">
        <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <SectionHeading
            index="06"
            eyebrow="Engagement models"
            title={
              <span id="pricing-heading">
                Clear starting points. <Accent>Honest</Accent> scoping.
              </span>
            }
            description="Every engagement begins with a written scope. These starting prices help you plan; the final figure depends on what we agree to build."
          />
          <ButtonLink href="/pricing" variant="outline" className="shrink-0">
            Compare engagements <ArrowRight className="size-4" aria-hidden />
          </ButtonLink>
        </div>
        <div className="mt-14 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {pricingTiers.map((t, i) => (
            <Reveal key={t.id} delay={i * 0.06} className="h-full">
              <PricingCard tier={t} />
            </Reveal>
          ))}
        </div>
      </section>

      {siteConfig.showTestimonialsSection ? <TestimonialsSection testimonials={testimonials} /> : null}

      {/* FAQ */}
      <section className="container-page grid gap-12 py-24 md:py-32 lg:grid-cols-12" aria-labelledby="faq-heading">
        <div className="lg:col-span-4">
          <SectionHeading index="08" eyebrow="FAQ" title={<span id="faq-heading">Questions, answered plainly.</span>} />
          <div className="mt-10 rounded-2xl border border-line p-6">
            <p className="font-medium">Get occasional field notes</p>
            <p className="mt-1 text-sm text-fg-muted">
              Practical notes on digital systems. No spam, unsubscribe anytime.
            </p>
            <NewsletterForm source="home-faq" className="mt-5" />
          </div>
        </div>
        <div className="lg:col-span-8">
          <FAQAccordion items={faqs} />
        </div>
      </section>

      <CTASection />
    </>
  );
}
