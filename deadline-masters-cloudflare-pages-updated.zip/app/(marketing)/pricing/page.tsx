import type { Metadata } from "next";
import { Check, Minus } from "lucide-react";
import { PageHeader } from "@/components/marketing/page-header";
import { PricingCard } from "@/components/marketing/pricing-card";
import { FAQAccordion } from "@/components/marketing/faq-accordion";
import { CTASection } from "@/components/marketing/cta-section";
import { ProfessionalDisclaimer } from "@/components/marketing/professional-disclaimer";
import { Accent, SectionHeading } from "@/components/ui/section-heading";
import { Reveal } from "@/components/ui/reveal";
import { faqs, pricingNotes, pricingTiers } from "@/lib/constants/engagement";
import { buildMetadata } from "@/lib/seo";

export const metadata: Metadata = buildMetadata({
  title: "Pricing & engagement models",
  description:
    "Quick Fix, Business Growth System, SaaS/MVP Launch and Custom Mission — starting prices and what each engagement includes. Final pricing depends on scope.",
  path: "/pricing",
});

type Cell = boolean | string;
const comparison: { feature: string; values: [Cell, Cell, Cell, Cell] }[] = [
  { feature: "Written scope before work starts", values: [true, true, true, true] },
  { feature: "Named lead specialist", values: [true, true, true, true] },
  { feature: "Disciplines involved", values: ["1", "2–3", "2–3", "All 4"] },
  { feature: "Design work", values: ["Minor", true, true, true] },
  { feature: "Custom build / engineering", values: ["Targeted fix", "Website", "Full application", true] },
  { feature: "Lead pipeline & CRM wiring", values: [false, true, "Optional", true] },
  { feature: "Automation", values: ["Single flow", "Lead follow-up", "In-app", true] },
  { feature: "Weekly progress demos", values: [false, true, true, true] },
  { feature: "Post-launch support window", values: ["7 days", "30 days", "30 days", "Agreed per plan"] },
  { feature: "Ongoing retainer option", values: [false, true, true, true] },
];

function CellValue({ v }: { v: Cell }) {
  if (v === true) return <Check className="mx-auto size-4 text-lime" aria-label="Included" />;
  if (v === false) return <Minus className="mx-auto size-4 text-fg-subtle" aria-label="Not included" />;
  return <span className="text-sm">{v}</span>;
}

const pricingFaqs = [
  faqs.find((f) => f.question.startsWith("How do you price"))!,
  {
    question: "Why are prices shown as “starting from”?",
    answer:
      "Because two projects with the same name can differ a lot in effort. Integrations, content readiness, number of templates, data migration and deadlines all change the work involved. The starting price is what the smallest sensible version usually costs; your proposal states the exact figure.",
  },
  {
    question: "Do you require a deposit?",
    answer:
      "Fixed-price projects are typically billed in milestones, with the first milestone due at kick-off. Retainers are billed monthly in advance. Exact terms are in your proposal.",
  },
  {
    question: "What is not included?",
    answer:
      "Third-party costs — hosting, domains, paid software, stock assets, ad spend and fees of licensed professionals such as lawyers or chartered accountants — are billed at cost or paid directly by you. We list them in the proposal so there are no surprises.",
  },
].filter(Boolean);

export default function PricingPage() {
  return (
    <>
      <PageHeader
        eyebrow="Pricing"
        title={
          <>
            Transparent starting points. <Accent>No</Accent> surprise invoices.
          </>
        }
        description="Choose the engagement closest to your situation. Every project begins with a free call and a written proposal — the final price depends on scope."
      />

      <section className="container-page" aria-label="Engagement levels">
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {pricingTiers.map((t, i) => (
            <Reveal key={t.id} delay={i * 0.06} className="h-full">
              <PricingCard tier={t} />
            </Reveal>
          ))}
        </div>
        <ul className="mt-8 grid gap-2 text-sm text-fg-muted md:grid-cols-2">
          {pricingNotes.map((n) => (
            <li key={n} className="flex gap-2">
              <span aria-hidden className="mt-2 size-1 shrink-0 rounded-full bg-lime" />
              {n}
            </li>
          ))}
        </ul>
      </section>

      <section className="container-page py-24" aria-labelledby="compare-heading">
        <SectionHeading eyebrow="Compare" title={<span id="compare-heading">What each engagement covers</span>} />
        <div className="mt-10 overflow-x-auto rounded-3xl border border-line">
          <table className="w-full min-w-[720px] border-collapse text-left">
            <caption className="sr-only">Comparison of engagement levels</caption>
            <thead>
              <tr className="border-b border-line bg-surface/60">
                <th scope="col" className="p-5 text-sm font-medium text-fg-muted">
                  Feature
                </th>
                {pricingTiers.map((t) => (
                  <th
                    key={t.id}
                    scope="col"
                    className={`p-5 text-center text-sm font-semibold ${t.highlighted ? "text-lime" : ""}`}
                  >
                    {t.name}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {comparison.map((row) => (
                <tr key={row.feature} className="border-b border-line last:border-0">
                  <th scope="row" className="p-5 text-sm font-normal text-fg-muted">
                    {row.feature}
                  </th>
                  {row.values.map((v, i) => (
                    <td key={i} className="p-5 text-center">
                      <CellValue v={v} />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <ProfessionalDisclaimer compact className="mt-8" />
      </section>

      <section className="container-page grid gap-12 pb-8 lg:grid-cols-12" aria-labelledby="pricing-faq-heading">
        <div className="lg:col-span-4">
          <SectionHeading eyebrow="Pricing FAQ" title={<span id="pricing-faq-heading">Money questions.</span>} />
        </div>
        <div className="lg:col-span-8">
          <FAQAccordion items={pricingFaqs} />
        </div>
      </section>

      <CTASection />
    </>
  );
}
