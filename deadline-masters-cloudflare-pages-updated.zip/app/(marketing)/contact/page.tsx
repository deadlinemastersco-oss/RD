import type { Metadata } from "next";
import { Suspense } from "react";
import Link from "next/link";
import { Clock, Mail, MapPin, Phone, Sparkles } from "lucide-react";
import { PageHeader } from "@/components/marketing/page-header";
import { ContactForm } from "@/components/marketing/contact-form";
import { ProfessionalDisclaimer } from "@/components/marketing/professional-disclaimer";
import { Accent } from "@/components/ui/section-heading";
import { Skeleton } from "@/components/ui/loading-skeleton";
import { siteConfig } from "@/lib/constants/site";
import { buildMetadata } from "@/lib/seo";

export const metadata: Metadata = buildMetadata({
  title: "Start a project",
  description:
    "Tell Deadline Masters what you need and when you need it. We reply to every inquiry within one business day.",
  path: "/contact",
});

export default function ContactPage() {
  const whatsapp = siteConfig.contact.whatsapp;
  return (
    <>
      <PageHeader
        eyebrow="Contact"
        title={
          <>
            Start a project. <Accent>Keep</Accent> your deadline.
          </>
        }
        description="Share the problem, your budget and your timeline. A specialist — not a sales script — will reply."
      />

      <section className="container-page grid gap-12 pb-8 lg:grid-cols-12" aria-label="Contact form and details">
        <div className="lg:col-span-8">
          <Suspense fallback={<Skeleton className="h-[52rem] w-full rounded-[var(--radius-card)]" />}>
            <ContactForm />
          </Suspense>
        </div>

        <aside className="space-y-6 lg:col-span-4" aria-label="Other ways to reach us">
          <div className="card p-6">
            <p className="label-mono text-fg-subtle">Direct</p>
            <ul className="mt-5 space-y-4 text-sm">
              <li>
                <a href={`mailto:${siteConfig.contact.email}`} className="flex items-center gap-3 hover:text-lime">
                  <Mail className="size-4 text-lime" aria-hidden /> {siteConfig.contact.email}
                </a>
              </li>
              <li>
                <a
                  href={`tel:${siteConfig.contact.phone.replace(/\s/g, "")}`}
                  className="flex items-center gap-3 hover:text-lime"
                >
                  <Phone className="size-4 text-lime" aria-hidden /> {siteConfig.contact.phone}
                </a>
              </li>
              {whatsapp ? (
                <li>
                  <a
                    href={`https://wa.me/${whatsapp}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 hover:text-lime"
                  >
                    <Phone className="size-4 text-lime" aria-hidden /> WhatsApp
                  </a>
                </li>
              ) : null}
              <li className="flex items-start gap-3 text-fg-muted">
                <MapPin className="mt-0.5 size-4 shrink-0 text-lime" aria-hidden /> {siteConfig.contact.address}
              </li>
              <li className="flex items-center gap-3 text-fg-muted">
                <Clock className="size-4 text-lime" aria-hidden /> {siteConfig.contact.hours}
              </li>
            </ul>
          </div>

          <div className="card p-6">
            <Sparkles className="size-5 text-lime" aria-hidden />
            <p className="mt-4 font-medium">Not sure what to ask for?</p>
            <p className="mt-2 text-sm text-fg-muted">
              Answer four quick questions and get a suggested service path before you talk to anyone.
            </p>
            <Link href="/diagnostic" className="mt-4 inline-flex text-sm text-lime underline underline-offset-4">
              Take the diagnostic →
            </Link>
          </div>

          <div className="card p-6">
            <p className="label-mono text-fg-subtle">What happens next</p>
            <ol className="mt-4 space-y-3 text-sm text-fg-muted">
              <li>1. We review your message within one business day.</li>
              <li>2. A short call to understand the problem properly.</li>
              <li>3. A written proposal with scope, timeline and price.</li>
            </ol>
          </div>

          <ProfessionalDisclaimer compact />
        </aside>
      </section>
    </>
  );
}
