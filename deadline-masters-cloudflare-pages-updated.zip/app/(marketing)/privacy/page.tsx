import type { Metadata } from "next";
import { LegalPage } from "@/components/marketing/legal-page";
import { siteConfig } from "@/lib/constants/site";
import { buildMetadata } from "@/lib/seo";

export const metadata: Metadata = buildMetadata({
  title: "Privacy policy",
  description: `How ${siteConfig.name} collects, uses and protects personal data submitted through this website.`,
  path: "/privacy",
});

export default function PrivacyPage() {
  const email = siteConfig.contact.email;
  return (
    <LegalPage
      eyebrow="Legal"
      title="Privacy policy"
      updated="29 September 2026"
      intro={
        <p>
          This policy explains what personal data {siteConfig.legalName} (“we”, “us”) collects through this website,
          why, and the choices you have. We aim to comply with India&apos;s Digital Personal Data Protection Act, 2023
          and, for visitors from other regions, applicable local law such as the GDPR.
        </p>
      }
      sections={[
        {
          heading: "Data we collect",
          body: (
            <ul>
              <li>
                <strong className="text-fg">Contact and diagnostic forms:</strong> name, email, and optionally phone,
                company, budget range, timeline, your message and your diagnostic answers.
              </li>
              <li>
                <strong className="text-fg">Newsletter:</strong> your email address and the page you subscribed from.
              </li>
              <li>
                <strong className="text-fg">Team accounts:</strong> name, email and profile details for people who sign
                in to our internal dashboard.
              </li>
              <li>
                <strong className="text-fg">Technical data:</strong> standard server logs (such as IP address and
                browser type) used for security and abuse prevention.
              </li>
            </ul>
          ),
        },
        {
          heading: "How we use it",
          body: (
            <ul>
              <li>To reply to your inquiry and prepare proposals you ask for.</li>
              <li>To send the newsletter you subscribed to — you can unsubscribe at any time.</li>
              <li>To protect the website from spam and abuse.</li>
            </ul>
          ),
        },
        {
          heading: "Legal basis and consent",
          body: (
            <p>
              We process form data on the basis of the consent you give when you submit a form, and to take steps at
              your request before entering into a contract. You may withdraw consent at any time by emailing{" "}
              <a href={`mailto:${email}`}>{email}</a>.
            </p>
          ),
        },
        {
          heading: "Where data is stored",
          body: (
            <p>
              Form submissions are stored in a managed PostgreSQL database provided by Supabase, and the website is
              hosted on Vercel. These providers act as processors and may store data outside India. Access inside our
              team is restricted by role.
            </p>
          ),
        },
        {
          heading: "Sharing",
          body: (
            <p>
              We do not sell personal data. We share it only with service providers that help us operate the website,
              and — with your agreement — with licensed professionals (for example, a chartered accountant or lawyer)
              when your engagement requires regulated work.
            </p>
          ),
        },
        {
          heading: "Retention",
          body: (
            <p>
              Inquiries that do not become projects are deleted or anonymised within 24 months. Project records are kept
              as long as needed for the engagement and applicable legal obligations.
            </p>
          ),
        },
        {
          heading: "Your rights",
          body: (
            <p>
              You can ask to access, correct or erase your personal data, or to nominate another person to exercise
              these rights. Email <a href={`mailto:${email}`}>{email}</a> and we will respond within a reasonable time.
              You may also raise a grievance with the relevant data protection authority.
            </p>
          ),
        },
        {
          heading: "Cookies",
          body: (
            <p>
              The public website does not use advertising or tracking cookies. Signing in to the team dashboard sets
              essential authentication cookies, which are required for the dashboard to work.
            </p>
          ),
        },
        {
          heading: "Contact",
          body: (
            <p>
              Questions about this policy: <a href={`mailto:${email}`}>{email}</a>.
            </p>
          ),
        },
      ]}
    />
  );
}
