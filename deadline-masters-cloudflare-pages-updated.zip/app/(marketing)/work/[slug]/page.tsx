import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ImageIcon, Info } from "lucide-react";
import Image from "next/image";
import { CaseStudyCard, CaseStudyCover } from "@/components/marketing/case-study-card";
import { CTASection } from "@/components/marketing/cta-section";
import { JsonLd } from "@/components/ui/json-ld";
import { Reveal } from "@/components/ui/reveal";
import { SectionLabel } from "@/components/ui/section-heading";
import { getCaseStudies, getCaseStudy, getServices } from "@/lib/data/content";
import { fallbackCaseStudies } from "@/lib/constants/people-and-work";
import { siteConfig } from "@/lib/constants/site";
import { breadcrumbJsonLd, buildMetadata } from "@/lib/seo";
import { absoluteUrl } from "@/lib/utils";

export const revalidate = 300;
export const dynamicParams = true;

export async function generateStaticParams() {
  return fallbackCaseStudies.map((c) => ({ slug: c.slug }));
}

export async function generateMetadata({ params }: PageProps<"/work/[slug]">): Promise<Metadata> {
  const { slug } = await params;
  const study = await getCaseStudy(slug);
  if (!study) return { title: "Not found", robots: { index: false } };
  return buildMetadata({
    title: study.title,
    description: study.summary,
    path: `/work/${study.slug}`,
    type: "article",
    image: study.coverImage,
    publishedTime: study.publishedAt,
  });
}

export default async function CaseStudyPage({ params }: PageProps<"/work/[slug]">) {
  const { slug } = await params;
  const [study, { items }, { services }] = await Promise.all([getCaseStudy(slug), getCaseStudies(), getServices()]);
  if (!study) notFound();

  const usedServices = services.filter((s) => study.services.includes(s.slug));
  const more = items.filter((i) => i.slug !== study.slug).slice(0, 2);

  const sections = [
    { id: "challenge", label: "Challenge", body: study.challenge },
    { id: "approach", label: "Approach", body: study.approach },
    { id: "solution", label: "Solution", body: study.solution },
    { id: "outcome", label: study.isIllustrative ? "Expected outcome" : "Outcome", body: study.outcome },
  ].filter((s) => s.body);

  const articleJsonLd = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: study.title,
    description: study.summary,
    url: absoluteUrl(`/work/${study.slug}`),
    author: { "@id": `${siteConfig.url}/#organization` },
    publisher: { "@id": `${siteConfig.url}/#organization` },
    ...(study.publishedAt ? { datePublished: study.publishedAt } : {}),
    ...(study.coverImage ? { image: study.coverImage } : {}),
    about: study.industry,
  };

  return (
    <>
      <JsonLd
        data={[
          articleJsonLd,
          breadcrumbJsonLd([
            { name: "Home", path: "/" },
            { name: "Work", path: "/work" },
            { name: study.title, path: `/work/${study.slug}` },
          ]),
        ]}
      />

      <article>
        <header className="pt-32 md:pt-40">
          <div className="container-page">
            <Link href="/work" className="inline-flex items-center gap-2 text-sm text-fg-muted hover:text-fg">
              <ArrowLeft className="size-4" aria-hidden /> All work
            </Link>
            <div className="mt-10 flex flex-wrap items-center gap-3">
              <span className="label-mono text-fg-subtle">{study.industry}</span>
              {study.isIllustrative ? (
                <span className="label-mono rounded-full border border-amber/40 px-2.5 py-1 !text-[0.62rem] text-amber">
                  Illustrative blueprint
                </span>
              ) : null}
            </div>
            <h1 className="mt-5 max-w-4xl text-4xl leading-[1.04] font-semibold tracking-[-0.04em] sm:text-6xl">
              {study.title}
            </h1>
            <p className="mt-6 max-w-2xl text-xl leading-relaxed text-fg-muted">{study.summary}</p>

            <dl className="mt-10 grid grid-cols-2 gap-6 border-y border-line py-6 text-sm md:grid-cols-4">
              <div>
                <dt className="label-mono text-fg-subtle">Client</dt>
                <dd className="mt-1.5">{study.clientName}</dd>
              </div>
              <div>
                <dt className="label-mono text-fg-subtle">Industry</dt>
                <dd className="mt-1.5">{study.industry}</dd>
              </div>
              <div className="col-span-2">
                <dt className="label-mono text-fg-subtle">Capabilities</dt>
                <dd className="mt-1.5 flex flex-wrap gap-x-3 gap-y-1">
                  {usedServices.map((s) => (
                    <Link
                      key={s.slug}
                      href={`/services/${s.slug}`}
                      className="underline decoration-line-strong underline-offset-4 hover:decoration-lime"
                    >
                      {s.title}
                    </Link>
                  ))}
                </dd>
              </div>
            </dl>
          </div>
        </header>

        <div className="container-page mt-12">
          <div className="relative aspect-[16/8] overflow-hidden rounded-[2rem] border border-line">
            <CaseStudyCover study={study} priority />
          </div>
        </div>

        {study.isIllustrative ? (
          <div className="container-page mt-8">
            <p className="flex max-w-3xl items-start gap-3 rounded-2xl border border-amber/30 bg-amber/[0.05] p-4 text-sm text-fg-muted">
              <Info className="mt-0.5 size-4 shrink-0 text-amber" aria-hidden />
              This is an illustrative scenario that explains our approach. It does not describe a specific client, and
              it makes no claims about results.
            </p>
          </div>
        ) : null}

        <div className="container-page mt-16 grid gap-16 lg:grid-cols-12">
          <nav aria-label="On this page" className="hidden lg:col-span-3 lg:block">
            <div className="sticky top-28">
              <p className="label-mono mb-4 text-fg-subtle">On this page</p>
              <ul className="space-y-2 border-l border-line text-sm">
                {sections.map((s) => (
                  <li key={s.id}>
                    <a
                      href={`#${s.id}`}
                      className="-ml-px block border-l border-transparent pl-4 text-fg-muted hover:border-lime hover:text-fg"
                    >
                      {s.label}
                    </a>
                  </li>
                ))}
                <li>
                  <a
                    href="#technology"
                    className="-ml-px block border-l border-transparent pl-4 text-fg-muted hover:border-lime hover:text-fg"
                  >
                    Technology
                  </a>
                </li>
              </ul>
            </div>
          </nav>

          <div className="space-y-16 lg:col-span-9">
            {sections.map((s, i) => (
              <Reveal key={s.id} as="section">
                <div id={s.id} className="scroll-mt-28">
                  <SectionLabel index={String(i + 1).padStart(2, "0")}>{s.label}</SectionLabel>
                  <p className="mt-5 max-w-3xl text-xl leading-relaxed">{s.body}</p>
                </div>
              </Reveal>
            ))}

            <section id="technology" className="scroll-mt-28" aria-labelledby="tech-heading">
              <SectionLabel index={String(sections.length + 1).padStart(2, "0")}>
                <span id="tech-heading">Technology</span>
              </SectionLabel>
              <ul className="mt-5 flex flex-wrap gap-2">
                {study.technologies.map((t) => (
                  <li key={t} className="rounded-full border border-line-strong px-3.5 py-1.5 text-sm">
                    {t}
                  </li>
                ))}
              </ul>
            </section>

            <section aria-labelledby="gallery-heading">
              <h2 id="gallery-heading" className="label-mono text-fg-subtle">
                Gallery
              </h2>
              <div className="mt-5 grid gap-4 sm:grid-cols-2">
                {study.gallery.length
                  ? study.gallery.map((src, i) => (
                      <div key={src} className="relative aspect-[4/3] overflow-hidden rounded-2xl border border-line">
                        <Image
                          src={src}
                          alt={`${study.title} — image ${i + 1}`}
                          fill
                          sizes="(min-width: 640px) 40vw, 100vw"
                          className="object-cover"
                          loading="lazy"
                        />
                      </div>
                    ))
                  : Array.from({ length: 2 }).map((_, i) => (
                      <div
                        key={i}
                        className="bg-grid grid aspect-[4/3] place-items-center rounded-2xl border border-dashed border-line-strong text-center"
                      >
                        <div className="px-6">
                          <ImageIcon className="mx-auto size-6 text-fg-subtle" aria-hidden />
                          <p className="mt-3 text-sm text-fg-subtle">Screens will be published with client approval.</p>
                        </div>
                      </div>
                    ))}
              </div>
            </section>
          </div>
        </div>
      </article>

      {more.length ? (
        <section className="container-page mt-24" aria-labelledby="more-heading">
          <h2 id="more-heading" className="text-2xl font-semibold tracking-tight">
            More work
          </h2>
          <div className="mt-8 grid gap-6 md:grid-cols-2">
            {more.map((m) => (
              <CaseStudyCard key={m.slug} study={m} />
            ))}
          </div>
        </section>
      ) : null}

      <CTASection />
    </>
  );
}
