import type { Metadata } from "next";
import { Info } from "lucide-react";
import { PageHeader } from "@/components/marketing/page-header";
import { WorkGrid } from "@/components/marketing/work-grid";
import { CTASection } from "@/components/marketing/cta-section";
import { Accent } from "@/components/ui/section-heading";
import { getCaseStudies, getServices } from "@/lib/data/content";
import { buildMetadata } from "@/lib/seo";

export const revalidate = 300;

export const metadata: Metadata = buildMetadata({
  title: "Work",
  description:
    "How Deadline Masters approaches websites, SaaS products, automation, growth and operations engagements.",
  path: "/work",
});

export default async function WorkPage() {
  const [{ items, fromDatabase }, { services }] = await Promise.all([getCaseStudies(), getServices()]);

  return (
    <>
      <PageHeader
        eyebrow="Work"
        title={
          <>
            Problems solved <Accent>end to end.</Accent>
          </>
        }
        description="Filter by industry or capability to see how design, engineering, growth and operations come together."
      />
      <section className="container-page pb-8" aria-label="Case studies">
        {!fromDatabase ? (
          <div className="mb-12 flex max-w-3xl items-start gap-3 rounded-2xl border border-amber/30 bg-amber/[0.05] p-5 text-sm">
            <Info className="mt-0.5 size-4 shrink-0 text-amber" aria-hidden />
            <p className="leading-relaxed text-fg-muted">
              <strong className="font-medium text-fg">Case study publishing in progress.</strong> We only publish client
              work with explicit permission. The blueprints below are illustrative scenarios describing how we would
              approach common engagements — they are not client projects and contain no client results.
            </p>
          </div>
        ) : null}
        <WorkGrid items={items} services={services.map((s) => ({ slug: s.slug, title: s.title }))} />
      </section>
      <CTASection />
    </>
  );
}
