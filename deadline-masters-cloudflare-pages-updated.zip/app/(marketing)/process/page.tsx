import type { Metadata } from "next";
import { PageHeader } from "@/components/marketing/page-header";
import { ProcessTimeline } from "@/components/marketing/process-timeline";
import { CTASection } from "@/components/marketing/cta-section";
import { Accent } from "@/components/ui/section-heading";
import { Stagger, StaggerItem } from "@/components/ui/reveal";
import { processSteps } from "@/lib/constants/engagement";
import { buildMetadata } from "@/lib/seo";

export const metadata: Metadata = buildMetadata({
  title: "Process",
  description:
    "Discovery, diagnosis, strategy, design, build, launch and optimisation — how Deadline Masters runs every engagement.",
  path: "/process",
});

const guarantees = [
  { title: "Written scope", body: "Nothing starts without an agreed scope, timeline and price in writing." },
  { title: "Weekly visibility", body: "A short update every week and a live staging link during build." },
  { title: "Early risk flags", body: "If a date is at risk, you hear it the day we know — with options." },
  { title: "Clean handover", body: "Documentation, credentials and a walkthrough. You own everything." },
];

export default function ProcessPage() {
  return (
    <>
      <PageHeader
        eyebrow="Process"
        title={
          <>
            Seven stages. <Accent>Zero</Accent> guesswork.
          </>
        }
        description="A repeatable way of working that keeps scope clear, progress visible and deadlines realistic. Scroll to follow the path."
      />

      <section className="container-page grid gap-16 pb-24 lg:grid-cols-12" aria-label="Process stages">
        <div className="lg:col-span-8 lg:col-start-3">
          <ProcessTimeline steps={processSteps} variant="full" />
        </div>
      </section>

      <section className="border-y border-line bg-surface/30 py-20" aria-labelledby="commitments-heading">
        <div className="container-page">
          <h2 id="commitments-heading" className="text-3xl font-semibold tracking-tight">
            Commitments at every stage
          </h2>
          <Stagger className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {guarantees.map((g) => (
              <StaggerItem key={g.title} className="card p-6">
                <span aria-hidden className="block h-px w-8 bg-lime" />
                <h3 className="mt-5 font-semibold">{g.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-fg-muted">{g.body}</p>
              </StaggerItem>
            ))}
          </Stagger>
        </div>
      </section>

      <CTASection />
    </>
  );
}
