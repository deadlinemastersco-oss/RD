import type { Metadata } from "next";
import { PageTitle, ProtectedRoute, SetupRequired } from "@/components/dashboard/protected-route";
import { TeamView } from "@/components/dashboard/team-view";
import { requireUser } from "@/lib/auth";
import { listProfiles, listTeamMembersAdmin } from "@/lib/data/dashboard";
import { isAdminClientConfigured } from "@/lib/supabase/admin";

export const metadata: Metadata = { title: "Team" };

export default async function TeamPage() {
  const user = await requireUser("viewer", "/dashboard/team");
  const isAdmin = user.role === "admin";

  return (
    <ProtectedRoute minRole="team_member">
      <PageTitle
        title="Team"
        description={isAdmin ? "Manage access and the public team profiles." : "Your teammates."}
      />
      <TeamContent userId={user.id} isAdmin={isAdmin} />
    </ProtectedRoute>
  );
}

async function TeamContent({ userId, isAdmin }: { userId: string; isAdmin: boolean }) {
  const [profiles, members] = await Promise.all([
    listProfiles(),
    isAdmin ? listTeamMembersAdmin() : Promise.resolve({ data: [], setupRequired: false }),
  ]);
  if (profiles.setupRequired) return <SetupRequired what="team accounts" />;
  return (
    <TeamView
      profiles={profiles.data}
      publicMembers={members.data}
      currentUserId={userId}
      isAdmin={isAdmin}
      inviteEnabled={isAdminClientConfigured()}
    />
  );
}
