import type { Metadata } from "next";
import { PageTitle, ProtectedRoute, SetupRequired } from "@/components/dashboard/protected-route";
import { TasksView } from "@/components/dashboard/tasks-view";
import { requireUser } from "@/lib/auth";
import { listStaff, listTasks } from "@/lib/data/dashboard";
import { taskPriorityValues, taskStatusValues } from "@/lib/validations/dashboard";
import type { TaskPriority, TaskStatus } from "@/lib/types/database";

export const metadata: Metadata = { title: "Tasks" };

export default async function TasksPage({ searchParams }: PageProps<"/dashboard/tasks">) {
  const user = await requireUser("viewer", "/dashboard/tasks");
  const sp = await searchParams;
  const isAdmin = user.role === "admin";
  const scope = isAdmin && sp.scope === "all" ? "all" : "mine";
  const status =
    sp.status === "all" ||
    (typeof sp.status === "string" && (taskStatusValues as readonly string[]).includes(sp.status))
      ? (sp.status as TaskStatus | "all")
      : "open";
  const priority =
    typeof sp.priority === "string" && (taskPriorityValues as readonly string[]).includes(sp.priority)
      ? (sp.priority as TaskPriority)
      : "all";

  return (
    <ProtectedRoute minRole="team_member">
      <PageTitle title="Tasks" description="Everything on your plate, sorted by due date." />
      <TasksContent userId={user.id} isAdmin={isAdmin} scope={scope} status={status} priority={priority} />
    </ProtectedRoute>
  );
}

async function TasksContent({
  userId,
  isAdmin,
  scope,
  status,
  priority,
}: {
  userId: string;
  isAdmin: boolean;
  scope: "mine" | "all";
  status: TaskStatus | "all" | "open";
  priority: TaskPriority | "all";
}) {
  const [tasks, staff] = await Promise.all([
    listTasks({ assignedTo: scope === "mine" ? userId : undefined, status, priority }),
    listStaff(),
  ]);
  if (tasks.setupRequired) return <SetupRequired what="tasks" />;
  return (
    <TasksView
      tasks={tasks.data}
      staff={staff.data.map((s) => ({ id: s.id, label: s.full_name || s.email || "Teammate" }))}
      userId={userId}
      isAdmin={isAdmin}
      scope={scope}
      status={status}
      priority={priority}
      today={new Date().toISOString().slice(0, 10)}
    />
  );
}
