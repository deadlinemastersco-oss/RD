import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ProjectDetail } from "@/components/dashboard/project-detail";
import { ProtectedRoute, SetupRequired } from "@/components/dashboard/protected-route";
import { requireUser } from "@/lib/auth";
import { getProject, listStaff } from "@/lib/data/dashboard";
import { uuid } from "@/lib/validations/dashboard";

export const metadata: Metadata = { title: "Project" };

export default async function ProjectPage({ params }: PageProps<"/dashboard/projects/[id]">) {
  const { id } = await params;
  const user = await requireUser("viewer", `/dashboard/projects/${id}`);
  if (!uuid.safeParse(id).success) notFound();

  return (
    <ProtectedRoute minRole="team_member">
      <ProjectContent id={id} userId={user.id} isAdmin={user.role === "admin"} />
    </ProtectedRoute>
  );
}

async function ProjectContent({ id, userId, isAdmin }: { id: string; userId: string; isAdmin: boolean }) {
  const [result, staff] = await Promise.all([getProject(id), listStaff()]);
  if (result.setupRequired) return <SetupRequired what="projects" />;
  // RLS returns nothing for projects the user cannot access → treat as not found.
  if (!result.data.project) notFound();

  return (
    <ProjectDetail
      project={result.data.project}
      tasks={result.data.tasks}
      staff={staff.data.map((s) => ({ id: s.id, label: s.full_name || s.email || "Teammate" }))}
      userId={userId}
      isAdmin={isAdmin}
    />
  );
}
