import type { Metadata } from "next";
import { PageTitle, ProtectedRoute, SetupRequired } from "@/components/dashboard/protected-route";
import { ProjectsView } from "@/components/dashboard/projects-view";
import { requireUser } from "@/lib/auth";
import { listProjects, listStaff } from "@/lib/data/dashboard";
import { projectStatusValues } from "@/lib/validations/dashboard";

export const metadata: Metadata = { title: "Projects" };

export default async function ProjectsPage({ searchParams }: PageProps<"/dashboard/projects">) {
  const user = await requireUser("viewer", "/dashboard/projects");
  const sp = await searchParams;
  const status =
    typeof sp.status === "string" && (projectStatusValues as readonly string[]).includes(sp.status) ? sp.status : "all";
  const q = typeof sp.q === "string" ? sp.q.slice(0, 80) : "";

  return (
    <ProtectedRoute minRole="team_member">
      <PageTitle title="Projects" description="Delivery status, owners and deadlines across active engagements." />
      <ProjectsContent status={status} q={q} isAdmin={user.role === "admin"} openNew={sp.new === "1"} />
    </ProtectedRoute>
  );
}

async function ProjectsContent({
  status,
  q,
  isAdmin,
  openNew,
}: {
  status: string;
  q: string;
  isAdmin: boolean;
  openNew: boolean;
}) {
  const [projects, staff] = await Promise.all([listProjects({ status, q }), listStaff()]);
  if (projects.setupRequired) return <SetupRequired what="projects" />;
  return (
    <ProjectsView
      key={`${status}-${q}`}
      projects={projects.data}
      staff={staff.data.map((s) => ({ id: s.id, label: s.full_name || s.email || "Teammate" }))}
      isAdmin={isAdmin}
      status={status}
      q={q}
      openNew={openNew}
      today={new Date().toISOString().slice(0, 10)}
    />
  );
}
