import type { Metadata } from "next";
import Link from "next/link";
import { AlertTriangle, ArrowRight, FolderKanban, Inbox, ListChecks, Mail, Sparkles } from "lucide-react";
import { MetricCard } from "@/components/dashboard/metric-card";
import { InquiriesChartLazy } from "@/components/dashboard/inquiries-chart-lazy";
import { PageTitle, SetupRequired } from "@/components/dashboard/protected-route";
import { EmptyState } from "@/components/ui/empty-state";
import { ErrorBoundary } from "@/components/ui/error-boundary";
import { StatusBadge } from "@/components/ui/status-badge";
import { ButtonLink } from "@/components/ui/button";
import { hasRole, requireUser } from "@/lib/auth";
import { topicLabel } from "@/lib/constants/forms";
import { getOverview } from "@/lib/data/dashboard";
import { cn, formatDate, humanize } from "@/lib/utils";

export const metadata: Metadata = { title: "Overview" };

function greeting() {
  const h = Number(
    new Intl.DateTimeFormat("en-IN", { hour: "numeric", hour12: false, timeZone: "Asia/Kolkata" }).format(new Date()),
  );
  return h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening";
}

export default async function DashboardHome({ searchParams }: PageProps<"/dashboard">) {
  const user = await requireUser("viewer");
  const sp = await searchParams;
  const firstName = (user.profile?.full_name || user.email || "there").split(/[\s@]/)[0];

  const header = (
    <PageTitle
      title={`${greeting()}, ${firstName}.`}
      description="Here is what is moving across the workspace."
      actions={
        hasRole(user, "admin") ? (
          <ButtonLink href="/dashboard/projects?new=1" size="sm">
            New project
          </ButtonLink>
        ) : null
      }
    />
  );

  const notices = (
    <>
      {sp.denied ? (
        <p role="alert" className="mb-6 rounded-xl border border-amber/30 bg-amber/10 p-3 text-sm">
          You do not have permission to open that page.
        </p>
      ) : null}
      {sp.password === "updated" ? (
        <p role="status" className="mb-6 rounded-xl border border-success/30 bg-success/10 p-3 text-sm">
          Your password has been updated.
        </p>
      ) : null}
    </>
  );

  if (!hasRole(user, "team_member")) {
    return (
      <>
        {header}
        {notices}
        <EmptyState
          icon={Sparkles}
          title="Your account is ready"
          description="You currently have viewer access. An admin can grant team access from the Team page — once they do, leads, projects and tasks will appear here."
          action={
            <ButtonLink href="/dashboard/settings" variant="outline" size="sm">
              Complete your profile
            </ButtonLink>
          }
        />
      </>
    );
  }

  const overview = await getOverview(user.id, user.role === "admin");
  if (overview.setupRequired) {
    return (
      <>
        {header}
        <SetupRequired what="the dashboard" />
      </>
    );
  }
  const o = overview.data;
  if (!o) {
    return (
      <>
        {header}
        <EmptyState icon={AlertTriangle} title="Could not load the overview" description="Please refresh the page." />
      </>
    );
  }

  const pipelineMax = Math.max(1, ...o.pipeline.map((p) => p.count));

  return (
    <>
      {header}
      {notices}

      <section aria-label="Key metrics" className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <MetricCard
          label="New inquiries"
          value={o.counts.newLeads}
          icon={Inbox}
          tone="lime"
          hint="Last 8 weeks, not yet contacted"
        />
        <MetricCard
          label="Open pipeline"
          value={o.counts.openLeads}
          icon={ArrowRight}
          tone="cyan"
          hint="Leads not yet won, lost or archived"
        />
        <MetricCard
          label="Active projects"
          value={o.counts.activeProjects}
          icon={FolderKanban}
          hint="Planning, active or in review"
        />
        <MetricCard
          label="Open tasks"
          value={o.counts.openTasks}
          icon={ListChecks}
          tone={o.counts.overdueTasks ? "danger" : "neutral"}
          hint={o.counts.overdueTasks ? `${o.counts.overdueTasks} overdue` : "Nothing overdue"}
        />
      </section>

      <div className="mt-6 grid gap-6 xl:grid-cols-3">
        <section className="card p-6 xl:col-span-2" aria-labelledby="volume-heading">
          <div className="flex items-center justify-between">
            <h2 id="volume-heading" className="font-semibold">
              Inquiry volume
            </h2>
            <span className="label-mono text-fg-subtle">8 weeks</span>
          </div>
          <div className="mt-4">
            <ErrorBoundary label="chart">
              <InquiriesChartLazy data={o.weekly} />
            </ErrorBoundary>
          </div>
        </section>

        <section className="card p-6" aria-labelledby="pipeline-heading">
          <div className="flex items-center justify-between">
            <h2 id="pipeline-heading" className="font-semibold">
              Pipeline
            </h2>
            {o.counts.subscribers !== null ? (
              <span className="inline-flex items-center gap-1.5 text-xs text-fg-muted">
                <Mail className="size-3.5" aria-hidden /> {o.counts.subscribers} subscribers
              </span>
            ) : null}
          </div>
          <ul className="mt-6 space-y-4">
            {o.pipeline.map((p) => (
              <li key={p.status}>
                <div className="mb-1.5 flex items-center justify-between text-sm">
                  <span>{humanize(p.status)}</span>
                  <span className="font-mono text-fg-muted">{p.count}</span>
                </div>
                <div className="h-1.5 overflow-hidden rounded-full bg-fg/[0.06]">
                  <div
                    className={cn(
                      "h-full rounded-full",
                      p.status === "won" ? "bg-success" : p.status === "lost" ? "bg-danger/70" : "bg-lime",
                    )}
                    style={{ width: `${(p.count / pipelineMax) * 100}%` }}
                  />
                </div>
              </li>
            ))}
          </ul>
        </section>
      </div>

      <div className="mt-6 grid gap-6 xl:grid-cols-3">
        <section className="card overflow-hidden xl:col-span-2" aria-labelledby="recent-heading">
          <div className="flex items-center justify-between border-b border-line px-6 py-4">
            <h2 id="recent-heading" className="font-semibold">
              Recent inquiries
            </h2>
            <Link href="/dashboard/inquiries" className="text-sm text-fg-muted hover:text-fg">
              View all →
            </Link>
          </div>
          {o.recentLeads.length ? (
            <ul className="divide-y divide-line">
              {o.recentLeads.map((l) => (
                <li key={`${l.type}-${l.id}`}>
                  <Link
                    href={`/dashboard/inquiries?type=${l.type}&id=${l.id}`}
                    className="flex items-center gap-4 px-6 py-3.5 hover:bg-fg/[0.02]"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{l.name}</p>
                      <p className="truncate text-xs text-fg-muted">
                        {l.company ? `${l.company} · ` : ""}
                        {topicLabel(l.topic)}
                      </p>
                    </div>
                    <span className="hidden text-xs text-fg-subtle sm:block">{formatDate(l.created_at)}</span>
                    <StatusBadge status={l.status} />
                  </Link>
                </li>
              ))}
            </ul>
          ) : (
            <p className="px-6 py-12 text-center text-sm text-fg-muted">No inquiries in the last eight weeks yet.</p>
          )}
        </section>

        <section className="card overflow-hidden" aria-labelledby="mytasks-heading">
          <div className="flex items-center justify-between border-b border-line px-6 py-4">
            <h2 id="mytasks-heading" className="font-semibold">
              My open tasks
            </h2>
            <Link href="/dashboard/tasks" className="text-sm text-fg-muted hover:text-fg">
              All →
            </Link>
          </div>
          {o.myTasks.length ? (
            <ul className="divide-y divide-line">
              {o.myTasks.map((t) => (
                <li key={t.id}>
                  <Link href={`/dashboard/projects/${t.project_id}`} className="block px-6 py-3.5 hover:bg-fg/[0.02]">
                    <p className="truncate text-sm font-medium">{t.title}</p>
                    <div className="mt-1.5 flex items-center gap-2">
                      <StatusBadge status={t.priority} />
                      <span className="truncate text-xs text-fg-subtle">
                        {t.project_title ?? "Project"} · due {formatDate(t.due_date)}
                      </span>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          ) : (
            <p className="px-6 py-12 text-center text-sm text-fg-muted">Nothing assigned to you. Nice.</p>
          )}
        </section>
      </div>

      {o.upcomingProjects.length ? (
        <section className="mt-6" aria-labelledby="upcoming-heading">
          <h2 id="upcoming-heading" className="mb-4 font-semibold">
            Upcoming deadlines
          </h2>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            {o.upcomingProjects.map((p) => (
              <Link
                key={p.id}
                href={`/dashboard/projects/${p.id}`}
                className="card block p-5 transition-colors hover:border-line-strong"
              >
                <div className="flex items-center justify-between gap-2">
                  <StatusBadge status={p.status} />
                  <span className="font-mono text-xs text-fg-subtle">{formatDate(p.due_date)}</span>
                </div>
                <p className="mt-4 truncate font-medium">{p.title}</p>
                <p className="truncate text-xs text-fg-muted">{p.client_name ?? "—"}</p>
                <div
                  className="mt-4 h-1.5 overflow-hidden rounded-full bg-fg/[0.06]"
                  role="progressbar"
                  aria-valuenow={p.progress}
                  aria-valuemin={0}
                  aria-valuemax={100}
                  aria-label={`${p.title} progress`}
                >
                  <div className="h-full rounded-full bg-lime" style={{ width: `${p.progress}%` }} />
                </div>
                <p className="mt-1.5 text-right font-mono text-[0.7rem] text-fg-subtle">{p.progress}%</p>
              </Link>
            ))}
          </div>
        </section>
      ) : null}
    </>
  );
}
