import type { Metadata } from "next";
import { DatabaseZap } from "lucide-react";
import { DashboardSidebar } from "@/components/dashboard/dashboard-sidebar";
import { NotificationCenter } from "@/components/dashboard/notification-center";
import { ErrorBoundary } from "@/components/ui/error-boundary";
import { EmptyState } from "@/components/ui/empty-state";
import { Logo } from "@/components/ui/logo";
import { ButtonLink } from "@/components/ui/button";
import { requireUser } from "@/lib/auth";
import { listNotifications } from "@/lib/data/dashboard";
import { isSupabaseConfigured } from "@/lib/env";

// Always render per request: every dashboard view depends on the signed-in user.
export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: { default: "Dashboard", template: "%s · Dashboard" },
  robots: { index: false, follow: false },
};

export default async function DashboardLayout({ children }: LayoutProps<"/dashboard">) {
  if (!isSupabaseConfigured) {
    return (
      <main id="main" className="mx-auto flex min-h-dvh max-w-2xl flex-col justify-center gap-10 px-6 py-16">
        <Logo />
        <EmptyState
          icon={DatabaseZap}
          title="Connect Supabase to use the dashboard"
          description={
            <>
              Add <code className="font-mono text-xs">NEXT_PUBLIC_SUPABASE_URL</code> and{" "}
              <code className="font-mono text-xs">NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY</code> to{" "}
              <code className="font-mono text-xs">.env.local</code> (or your Vercel project), run the SQL migrations,
              and restart. The public website keeps working without them.
            </>
          }
          action={
            <ButtonLink href="/" variant="outline" size="sm">
              Back to website
            </ButtonLink>
          }
        />
      </main>
    );
  }

  const user = await requireUser("viewer");
  const notifications = await listNotifications(user.id, 15);

  return (
    <DashboardSidebar
      user={{
        name: user.profile?.full_name || user.email?.split("@")[0] || "Team member",
        email: user.email,
        role: user.role,
        avatarUrl: user.profile?.avatar_url ?? null,
      }}
      topbar={
        <ErrorBoundary label="notifications" fallback={null}>
          <NotificationCenter items={notifications.data} />
        </ErrorBoundary>
      }
    >
      {children}
    </DashboardSidebar>
  );
}
