import type { Metadata } from "next";
import { InquiriesView } from "@/components/dashboard/inquiries-view";
import { PageTitle, ProtectedRoute, SetupRequired } from "@/components/dashboard/protected-route";
import { requireUser } from "@/lib/auth";
import { listLeads, listStaff } from "@/lib/data/dashboard";
import { leadStatusValues } from "@/lib/validations/dashboard";
import type { LeadStatus } from "@/lib/types/database";

export const metadata: Metadata = { title: "Inquiries" };

export default async function InquiriesPage({ searchParams }: PageProps<"/dashboard/inquiries">) {
  const user = await requireUser("viewer", "/dashboard/inquiries");
  const sp = await searchParams;
  const type = sp.type === "project" ? "project" : "contact";
  const q = typeof sp.q === "string" ? sp.q.slice(0, 80) : "";
  const status =
    typeof sp.status === "string" && (leadStatusValues as readonly string[]).includes(sp.status)
      ? (sp.status as LeadStatus)
      : "all";
  const openId = typeof sp.id === "string" ? sp.id : null;

  return (
    <ProtectedRoute minRole="team_member">
      <PageTitle
        title="Inquiries"
        description={
          user.role === "admin"
            ? "Every lead from the website. Assign an owner, update the status and keep notes."
            : "Leads assigned to you."
        }
      />
      <InquiriesContent type={type} q={q} status={status} openId={openId} isAdmin={user.role === "admin"} />
    </ProtectedRoute>
  );
}

async function InquiriesContent({
  type,
  q,
  status,
  openId,
  isAdmin,
}: {
  type: "contact" | "project";
  q: string;
  status: LeadStatus | "all";
  openId: string | null;
  isAdmin: boolean;
}) {
  const [leads, staff] = await Promise.all([listLeads({ type, q, status }), listStaff()]);
  if (leads.setupRequired) return <SetupRequired what="inquiries" />;
  return (
    <InquiriesView
      key={`${type}-${q}-${status}`}
      leads={leads.data}
      staff={staff.data}
      isAdmin={isAdmin}
      type={type}
      q={q}
      status={status}
      openId={openId}
    />
  );
}
