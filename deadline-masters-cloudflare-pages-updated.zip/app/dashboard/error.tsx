"use client";

import { useEffect } from "react";
import { RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function DashboardError({ error, retry }: { error: Error & { digest?: string }; retry: () => void }) {
  useEffect(() => {
    console.error("[dashboard-error]", error.digest ?? "", error.message);
  }, [error]);

  return (
    <div role="alert" className="mx-auto max-w-lg py-24 text-center">
      <p className="label-mono text-danger">Dashboard error</p>
      <h1 className="mt-4 text-2xl font-semibold tracking-tight">This view could not be loaded.</h1>
      <p className="mt-3 text-sm text-fg-muted">
        Try again. If the problem continues, check that the database migrations have been applied.
        {error.digest ? (
          <span className="mt-2 block font-mono text-xs text-fg-subtle">Reference: {error.digest}</span>
        ) : null}
      </p>
      <Button className="mt-8" onClick={() => retry()}>
        <RefreshCw className="size-4" aria-hidden /> Retry
      </Button>
    </div>
  );
}
