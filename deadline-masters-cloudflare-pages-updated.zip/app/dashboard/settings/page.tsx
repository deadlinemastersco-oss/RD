import type { Metadata } from "next";
import { CircleCheck, CircleDashed } from "lucide-react";
import { PageTitle } from "@/components/dashboard/protected-route";
import { NotificationsList, ProfileForm, SiteSettingsEditor } from "@/components/dashboard/settings-forms";
import { StatusBadge } from "@/components/ui/status-badge";
import { requireUser } from "@/lib/auth";
import { listNotifications, listSiteSettings } from "@/lib/data/dashboard";
import { isEmailConfigured } from "@/lib/email";
import { isAdminClientConfigured } from "@/lib/supabase/admin";

export const metadata: Metadata = { title: "Settings" };

function Section({
  id,
  title,
  description,
  children,
}: {
  id: string;
  title: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <section id={id} aria-labelledby={`${id}-heading`} className="card scroll-mt-24 p-6 sm:p-8">
      <h2 id={`${id}-heading`} className="text-lg font-semibold">
        {title}
      </h2>
      {description ? <p className="mt-1 text-sm text-fg-muted">{description}</p> : null}
      <div className="mt-6">{children}</div>
    </section>
  );
}

export default async function SettingsPage() {
  const user = await requireUser("viewer", "/dashboard/settings");
  const isAdmin = user.role === "admin";
  const [notifications, settings] = await Promise.all([
    listNotifications(user.id, 50),
    isAdmin ? listSiteSettings() : Promise.resolve({ data: [], setupRequired: false }),
  ]);

  const integrations = [
    { label: "Supabase (database & auth)", ok: true, note: "Connected" },
    { label: "Service role key (in-app invites)", ok: isAdminClientConfigured(), note: "SUPABASE_SERVICE_ROLE_KEY" },
    {
      label: "Email alerts for new leads (Resend)",
      ok: isEmailConfigured(),
      note: "RESEND_API_KEY + LEAD_NOTIFICATION_*",
    },
  ];

  return (
    <>
      <PageTitle title="Settings" description="Your profile, notifications and workspace configuration." />
      <div className="grid gap-6 xl:grid-cols-3">
        <div className="space-y-6 xl:col-span-2">
          <Section id="profile" title="Profile" description="How you appear to teammates.">
            <ProfileForm
              email={user.email}
              defaults={{
                full_name: user.profile?.full_name ?? "",
                bio: user.profile?.bio ?? "",
                avatar_url: user.profile?.avatar_url ?? "",
              }}
            />
          </Section>

          <Section
            id="notifications"
            title="Notifications"
            description="Created automatically for new leads and assignments."
          >
            <NotificationsList items={notifications.data} />
          </Section>

          {isAdmin ? (
            <Section id="site-settings" title="Site settings">
              <SiteSettingsEditor settings={settings.data} />
            </Section>
          ) : null}
        </div>

        <div className="space-y-6">
          <Section id="access" title="Your access">
            <div className="flex items-center gap-3">
              <StatusBadge status={user.role} />
              <span className="text-sm text-fg-muted">Roles are managed by admins on the Team page.</span>
            </div>
          </Section>

          {isAdmin ? (
            <>
              <Section id="integrations" title="Integrations">
                <ul className="space-y-3 text-sm">
                  {integrations.map((i) => (
                    <li key={i.label} className="flex items-start gap-3">
                      {i.ok ? (
                        <CircleCheck className="mt-0.5 size-4 shrink-0 text-success" aria-hidden />
                      ) : (
                        <CircleDashed className="mt-0.5 size-4 shrink-0 text-fg-subtle" aria-hidden />
                      )}
                      <span>
                        <span className="block">{i.label}</span>
                        <span className="block font-mono text-[0.68rem] text-fg-subtle">
                          {i.ok ? "Configured" : `Not configured · ${i.note}`}
                        </span>
                      </span>
                    </li>
                  ))}
                </ul>
              </Section>

              <Section id="content" title="Managing website content">
                <ol className="space-y-3 text-sm text-fg-muted">
                  <li>
                    <strong className="text-fg">Services, case studies, testimonials, team:</strong> Supabase → Table
                    editor. Only rows with <code className="font-mono text-xs">is_active</code> /{" "}
                    <code className="font-mono text-xs">is_published</code> = true appear publicly.
                  </li>
                  <li>
                    <strong className="text-fg">Images:</strong> upload to the{" "}
                    <code className="font-mono text-xs">public-assets</code> storage bucket and paste the public URL
                    into the row.
                  </li>
                  <li>
                    <strong className="text-fg">Timing:</strong> public pages refresh every 5 minutes.
                  </li>
                  <li>
                    <strong className="text-fg">Fallback copy:</strong> edit files in{" "}
                    <code className="font-mono text-xs">lib/constants/</code>.
                  </li>
                </ol>
              </Section>
            </>
          ) : null}
        </div>
      </div>
    </>
  );
}
