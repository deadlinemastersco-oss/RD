import Link from "next/link";
import { FolderSearch } from "lucide-react";
import { EmptyState } from "@/components/ui/empty-state";

export default function DashboardNotFound() {
  return (
    <EmptyState
      icon={FolderSearch}
      title="Not found"
      description="This item does not exist, was deleted, or you do not have access to it."
      action={
        <Link href="/dashboard" className="text-sm text-lime underline underline-offset-4">
          Back to overview
        </Link>
      }
    />
  );
}
