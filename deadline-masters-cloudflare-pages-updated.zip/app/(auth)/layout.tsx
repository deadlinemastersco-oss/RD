import Link from "next/link";
import { ArrowLeft, ShieldCheck } from "lucide-react";
import { Logo } from "@/components/ui/logo";
import { isSupabaseConfigured } from "@/lib/env";

export default function AuthLayout({ children }: LayoutProps<"/">) {
  return (
    <main id="main" className="grid min-h-dvh lg:grid-cols-2">
      <aside className="noise relative hidden overflow-hidden border-r border-line bg-surface lg:flex lg:flex-col lg:justify-between lg:p-12">
        <div aria-hidden className="bg-grid bg-grid-fade absolute inset-0" />
        <div
          aria-hidden
          className="absolute -bottom-40 -left-20 h-[520px] w-[520px] rounded-full bg-[radial-gradient(circle,rgb(200_243_74/0.14),transparent_65%)] blur-2xl"
        />
        <div className="relative">
          <Logo />
        </div>
        <div className="relative max-w-md">
          <p className="label-mono text-lime">Team workspace</p>
          <p className="mt-5 text-4xl leading-tight font-semibold tracking-[-0.03em]">
            Every lead, project and deadline —{" "}
            <span className="font-serif font-normal text-lime italic">in one place.</span>
          </p>
          <ul className="mt-8 space-y-3 text-sm text-fg-muted">
            <li>· Inquiry pipeline with owners and notes</li>
            <li>· Projects, tasks and progress tracking</li>
            <li>· Role-based access enforced by the database</li>
          </ul>
        </div>
        <p className="relative flex items-center gap-2 text-xs text-fg-subtle">
          <ShieldCheck className="size-4" aria-hidden /> Protected by Supabase Auth and Row Level Security.
        </p>
      </aside>

      <div className="flex flex-col px-5 py-8 sm:px-10">
        <div className="flex items-center justify-between">
          <div className="lg:hidden">
            <Logo />
          </div>
          <Link href="/" className="ml-auto inline-flex items-center gap-2 text-sm text-fg-muted hover:text-fg">
            <ArrowLeft className="size-4" aria-hidden /> Back to website
          </Link>
        </div>
        <div className="mx-auto flex w-full max-w-md flex-1 flex-col justify-center py-12">
          {!isSupabaseConfigured ? (
            <div
              role="note"
              className="mb-8 rounded-2xl border border-amber/30 bg-amber/[0.06] p-4 text-sm text-fg-muted"
            >
              <strong className="text-fg">Setup required.</strong> Supabase keys are not configured, so sign-in is
              disabled. Add them to <code className="font-mono text-xs">.env.local</code> — see SETUP.md.
            </div>
          ) : null}
          {children}
        </div>
      </div>
    </main>
  );
}
