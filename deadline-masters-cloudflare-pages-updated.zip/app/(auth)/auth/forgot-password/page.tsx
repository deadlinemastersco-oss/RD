import type { Metadata } from "next";
import Link from "next/link";
import { AuthHeading } from "@/components/auth/auth-heading";
import { ForgotPasswordForm } from "@/components/auth/auth-forms";

export const metadata: Metadata = { title: "Reset password", robots: { index: false, follow: false } };

export default function ForgotPasswordPage() {
  return (
    <>
      <AuthHeading
        eyebrow="Password reset"
        title="Forgot your password?"
        description="Enter your email and we will send a secure link to choose a new one."
      />
      <ForgotPasswordForm />
      <p className="mt-8 text-center text-sm text-fg-muted">
        Remembered it?{" "}
        <Link href="/auth/sign-in" className="text-fg underline underline-offset-4">
          Back to sign in
        </Link>
      </p>
    </>
  );
}
