import type { Metadata } from "next";
import Link from "next/link";
import { AuthHeading } from "@/components/auth/auth-heading";
import { SignUpForm } from "@/components/auth/auth-forms";

export const metadata: Metadata = { title: "Create account", robots: { index: false, follow: false } };

export default function SignUpPage() {
  return (
    <>
      <AuthHeading
        eyebrow="Create account"
        title="Join the workspace."
        description="For Deadline Masters team members and invited collaborators."
      />
      <SignUpForm />
      <p className="mt-8 text-center text-sm text-fg-muted">
        Already have an account?{" "}
        <Link href="/auth/sign-in" className="text-fg underline underline-offset-4">
          Sign in
        </Link>
      </p>
    </>
  );
}
