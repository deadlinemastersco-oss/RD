import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { AuthHeading } from "@/components/auth/auth-heading";
import { UpdatePasswordForm } from "@/components/auth/auth-forms";
import { getSessionUser } from "@/lib/auth";
import { isSupabaseConfigured } from "@/lib/env";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Choose a new password", robots: { index: false, follow: false } };

export default async function UpdatePasswordPage() {
  // The recovery link (via /auth/confirm) creates a short-lived session.
  const user = isSupabaseConfigured ? await getSessionUser() : null;
  if (isSupabaseConfigured && !user) {
    redirect("/auth/error?reason=expired");
  }

  return (
    <>
      <AuthHeading
        eyebrow="Security"
        title="Choose a new password."
        description={user?.email ? <>For {user.email}</> : undefined}
      />
      <UpdatePasswordForm />
      <p className="mt-8 text-center text-sm text-fg-muted">
        <Link href="/dashboard" className="underline underline-offset-4 hover:text-fg">
          Skip for now
        </Link>
      </p>
    </>
  );
}
