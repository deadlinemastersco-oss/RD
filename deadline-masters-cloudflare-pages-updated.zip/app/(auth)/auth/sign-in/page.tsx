import type { Metadata } from "next";
import Link from "next/link";
import { Suspense } from "react";
import { AuthHeading } from "@/components/auth/auth-heading";
import { SignInForm } from "@/components/auth/sign-in-form";
import { Skeleton } from "@/components/ui/loading-skeleton";

export const metadata: Metadata = { title: "Sign in", robots: { index: false, follow: false } };

export default function SignInPage() {
  return (
    <>
      <AuthHeading
        eyebrow="Team sign in"
        title="Welcome back."
        description="Sign in to the Deadline Masters workspace."
      />
      <Suspense fallback={<Skeleton className="h-80 w-full" />}>
        <SignInForm />
      </Suspense>
      <p className="mt-8 text-center text-sm text-fg-muted">
        No account yet?{" "}
        <Link href="/auth/sign-up" className="text-fg underline underline-offset-4">
          Create one
        </Link>
      </p>
    </>
  );
}
