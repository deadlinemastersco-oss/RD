import { NextResponse, type NextRequest } from "next/server";
import type { EmailOtpType } from "@supabase/supabase-js";
import { createClient } from "@/lib/supabase/server";
import { safeNextPath } from "@/lib/validations/auth";

const OTP_TYPES: EmailOtpType[] = ["signup", "invite", "magiclink", "recovery", "email_change", "email"];

/**
 * Handles every email link from Supabase Auth:
 *  - `?token_hash=…&type=…`  (recommended custom email templates, see SETUP.md)
 *  - `?code=…`               (default PKCE redirect flow)
 * On success the session cookie is set and the user is redirected to `next`.
 */
export async function GET(request: NextRequest) {
  const { searchParams, origin } = request.nextUrl;
  const tokenHash = searchParams.get("token_hash");
  const type = searchParams.get("type") as EmailOtpType | null;
  const code = searchParams.get("code");
  const next = safeNextPath(searchParams.get("next"), "/dashboard");

  const fail = (reason: string) => NextResponse.redirect(new URL(`/auth/error?reason=${reason}`, origin));

  // Supabase forwards provider errors as query params.
  if (searchParams.get("error")) return fail(searchParams.get("error_code") === "otp_expired" ? "expired" : "link");

  const supabase = await createClient();
  if (!supabase) return fail("config");

  if (tokenHash && type && OTP_TYPES.includes(type)) {
    const { error } = await supabase.auth.verifyOtp({ type, token_hash: tokenHash });
    if (error) return fail(error.code === "otp_expired" ? "expired" : "link");
    const destination = type === "recovery" || type === "invite" ? "/auth/update-password" : next;
    return NextResponse.redirect(new URL(destination, origin));
  }

  if (code) {
    const { error } = await supabase.auth.exchangeCodeForSession(code);
    if (error) return fail("link");
    return NextResponse.redirect(new URL(next, origin));
  }

  return fail("missing");
}
