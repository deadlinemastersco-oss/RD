import type { Metadata } from "next";
import { CircleAlert } from "lucide-react";
import { AuthHeading } from "@/components/auth/auth-heading";
import { ButtonLink } from "@/components/ui/button";

export const metadata: Metadata = { title: "Authentication problem", robots: { index: false, follow: false } };

const reasons: Record<string, { title: string; body: string }> = {
  expired: {
    title: "That link has expired.",
    body: "Email links are single-use and time-limited. Request a fresh one and use it within a few minutes.",
  },
  link: {
    title: "That link did not work.",
    body: "It may have been used already, or opened in a different browser from the one that requested it.",
  },
  missing: {
    title: "The link is incomplete.",
    body: "Some of the link was lost — try copying the full address from the email into your browser.",
  },
  config: {
    title: "Authentication is not configured.",
    body: "Supabase keys are missing on the server. An administrator needs to add them (see SETUP.md).",
  },
};

export default async function AuthErrorPage({ searchParams }: PageProps<"/auth/error">) {
  const sp = await searchParams;
  const key = typeof sp.reason === "string" ? sp.reason : "link";
  const reason = reasons[key] ?? reasons.link!;

  return (
    <>
      <div className="mb-6 grid size-12 place-items-center rounded-2xl bg-danger/15">
        <CircleAlert className="size-6 text-danger" aria-hidden />
      </div>
      <AuthHeading eyebrow="Authentication" title={reason.title} description={reason.body} />
      <div className="flex flex-col gap-3 sm:flex-row">
        <ButtonLink href="/auth/sign-in">Back to sign in</ButtonLink>
        <ButtonLink href="/auth/forgot-password" variant="outline">
          Request a new link
        </ButtonLink>
      </div>
    </>
  );
}
