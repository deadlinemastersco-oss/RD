import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { ButtonLink } from "@/components/ui/button";
import { Logo } from "@/components/ui/logo";

export const metadata: Metadata = {
  title: "Page not found",
  robots: { index: false },
};

export default function NotFound() {
  return (
    <main id="main" className="noise relative grid min-h-dvh place-items-center overflow-hidden px-6">
      <div aria-hidden className="bg-grid bg-grid-fade absolute inset-0" />
      <div className="relative max-w-xl text-center">
        <Logo className="justify-center" />
        <p className="label-mono mt-16 text-lime">Error 404 · Route not found</p>
        <h1 className="mt-5 text-5xl font-semibold tracking-[-0.04em] sm:text-7xl">
          This page <span className="font-serif font-normal text-lime italic">missed</span> its deadline.
        </h1>
        <p className="mt-6 text-lg text-fg-muted">
          The link may be outdated or the page may have moved. Let&apos;s get you back on schedule.
        </p>
        <div className="mt-10 flex flex-col justify-center gap-3 sm:flex-row">
          <ButtonLink href="/">
            <ArrowLeft className="size-4" aria-hidden /> Back to home
          </ButtonLink>
          <ButtonLink href="/contact" variant="outline">
            Contact the team
          </ButtonLink>
        </div>
        <p className="mt-8 text-sm text-fg-subtle">
          Looking for something specific? Try{" "}
          <Link href="/services" className="text-fg underline underline-offset-4">
            services
          </Link>{" "}
          or{" "}
          <Link href="/work" className="text-fg underline underline-offset-4">
            work
          </Link>
          .
        </p>
      </div>
    </main>
  );
}
