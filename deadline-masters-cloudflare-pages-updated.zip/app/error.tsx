"use client";

import { useEffect } from "react";
import { RefreshCw } from "lucide-react";
import { Button, ButtonLink } from "@/components/ui/button";

export default function RootError({ error, retry }: { error: Error & { digest?: string }; retry: () => void }) {
  useEffect(() => {
    console.error("[route-error]", error.digest ?? "", error.message);
  }, [error]);

  return (
    <main id="main" className="relative grid min-h-[80dvh] place-items-center px-6 py-32">
      <div aria-hidden className="bg-grid bg-grid-fade absolute inset-0" />
      <div className="relative max-w-lg text-center" role="alert">
        <p className="label-mono text-danger">Unexpected error</p>
        <h1 className="mt-5 text-4xl font-semibold tracking-tight sm:text-5xl">Something went wrong.</h1>
        <p className="mt-5 text-fg-muted">
          We could not load this page. Please try again — if it keeps happening, let us know.
          {error.digest ? (
            <span className="mt-2 block font-mono text-xs text-fg-subtle">Reference: {error.digest}</span>
          ) : null}
        </p>
        <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
          <Button onClick={() => retry()}>
            <RefreshCw className="size-4" aria-hidden /> Try again
          </Button>
          <ButtonLink href="/" variant="outline">
            Go home
          </ButtonLink>
        </div>
      </div>
    </main>
  );
}
