import { ImageResponse } from "next/og";
import { siteConfig } from "@/lib/constants/site";

export const alt = `${siteConfig.name} — ${siteConfig.tagline}`;
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

/** Default Open Graph / Twitter card image, generated at build time. */
export default function OpengraphImage() {
  return new ImageResponse(
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        padding: 72,
        background: "#07080a",
        backgroundImage:
          "linear-gradient(to right, rgba(237,237,230,0.06) 1px, transparent 1px), linear-gradient(to bottom, rgba(237,237,230,0.06) 1px, transparent 1px)",
        backgroundSize: "64px 64px",
        color: "#edede6",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
        <div
          style={{
            width: 56,
            height: 56,
            borderRadius: 16,
            background: "#c8f34a",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <div style={{ width: 30, height: 30, borderRadius: 999, border: "4px solid #07080a" }} />
        </div>
        <div style={{ fontSize: 32, fontWeight: 600, letterSpacing: -1 }}>{siteConfig.name}</div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
        <div style={{ fontSize: 76, fontWeight: 600, lineHeight: 1.02, letterSpacing: -3, maxWidth: 980 }}>
          Digital systems for businesses that cannot afford to slow down.
        </div>
        <div style={{ fontSize: 26, color: "#a3a59d" }}>Design · Engineering · Growth & automation · Operations</div>
      </div>
      <div style={{ display: "flex", height: 6, width: 220, background: "#c8f34a", borderRadius: 999 }} />
    </div>,
    size,
  );
}
