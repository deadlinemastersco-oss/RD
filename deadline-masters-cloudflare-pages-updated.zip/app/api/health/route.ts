import { NextResponse } from "next/server";
import { isSupabaseConfigured } from "@/lib/env";

export const dynamic = "force-dynamic";

/**
 * Lightweight health check for uptime monitors and post-deploy checks.
 * Reports only booleans — never values of environment variables.
 */
export function GET() {
  return NextResponse.json(
    {
      status: "ok",
      supabaseConfigured: isSupabaseConfigured,
      serviceRoleConfigured: Boolean(process.env.SUPABASE_SERVICE_ROLE_KEY),
      emailConfigured: Boolean(process.env.RESEND_API_KEY),
      time: new Date().toISOString(),
    },
    { headers: { "Cache-Control": "no-store" } },
  );
}
