"use client";

import "./globals.css";

/** Last-resort boundary when the root layout itself fails. Must render <html>/<body>. */
export default function GlobalError({ error, retry }: { error: Error & { digest?: string }; retry: () => void }) {
  return (
    <html lang="en">
      <body style={{ background: "#07080a", color: "#edede6", fontFamily: "system-ui, sans-serif" }}>
        <main style={{ minHeight: "100dvh", display: "grid", placeItems: "center", padding: 24 }}>
          <div style={{ maxWidth: 480, textAlign: "center" }} role="alert">
            <p style={{ color: "#ff7a6b", letterSpacing: 2, fontSize: 12, textTransform: "uppercase" }}>
              Application error
            </p>
            <h1 style={{ fontSize: 36, margin: "16px 0" }}>Something went wrong.</h1>
            <p style={{ color: "#a3a59d" }}>Please reload the page.</p>
            {error.digest ? <p style={{ color: "#7c7e77", fontSize: 12 }}>Reference: {error.digest}</p> : null}
            <button
              type="button"
              onClick={() => retry()}
              style={{
                marginTop: 24,
                background: "#c8f34a",
                color: "#07080a",
                border: 0,
                borderRadius: 999,
                padding: "12px 22px",
                fontWeight: 600,
                cursor: "pointer",
              }}
            >
              Try again
            </button>
          </div>
        </main>
      </body>
    </html>
  );
}
