-- =============================================================================
-- Deadline Masters · seed-demo.sql
--
--   ██████  DEMO DATA — DO NOT RUN IN PRODUCTION  ██████
--
-- Creates clearly-labelled fake projects, tasks and leads so you can explore the
-- dashboard in a development/staging Supabase project. Every row is tagged:
--   * project titles start with "[DEMO]"
--   * lead emails end with "@example.com" and source = 'demo'
--
-- Requirements: run 0001–0003 migrations + seed.sql first, and have at least
-- one admin profile (see supabase/README.md → "Create the first admin").
--
-- Remove all demo data at any time with the CLEANUP block at the bottom.
-- =============================================================================

do $$
declare
  v_admin uuid;
  p1 uuid;
  p2 uuid;
begin
  select id into v_admin from public.profiles where role = 'admin' order by created_at limit 1;
  if v_admin is null then
    raise exception 'Create an admin profile before loading demo data (see supabase/README.md).';
  end if;

  insert into public.projects (title, client_name, description, status, progress, start_date, due_date, owner_id)
  values ('[DEMO] Website rebuild', 'Demo Client A', 'Sample project for exploring the dashboard.', 'active', 45,
          current_date - 14, current_date + 21, v_admin)
  returning id into p1;

  insert into public.projects (title, client_name, description, status, progress, start_date, due_date, owner_id)
  values ('[DEMO] Operations dashboard MVP', 'Demo Client B', 'Sample project for exploring the dashboard.', 'planning', 10,
          current_date, current_date + 60, v_admin)
  returning id into p2;

  insert into public.project_tasks (project_id, title, status, priority, assigned_to, due_date) values
    (p1, '[DEMO] Approve homepage wireframe', 'done', 'high', v_admin, current_date - 3),
    (p1, '[DEMO] Build service page template', 'in_progress', 'medium', v_admin, current_date + 4),
    (p1, '[DEMO] Connect contact form to pipeline', 'todo', 'urgent', v_admin, current_date - 1),
    (p2, '[DEMO] Data model workshop', 'todo', 'high', v_admin, current_date + 7);

  insert into public.contact_submissions (full_name, email, company, service_interest, budget_range, deadline, message, source)
  values
    ('Demo Lead One', 'demo.one@example.com', 'Demo Co', 'websites-and-web-applications', '1.5l-4l', '1-3-months',
     'DEMO: We need a faster website with a proper lead pipeline.', 'demo'),
    ('Demo Lead Two', 'demo.two@example.com', 'Sample Ltd', 'ai-workflow-and-business-automation', '50k-1.5l', '2-4-weeks',
     'DEMO: Our team spends hours copying data between tools.', 'demo');
end $$;

-- ---------------------------------------------------------------------------
-- CLEANUP — uncomment and run to remove every demo row.
-- ---------------------------------------------------------------------------
-- delete from public.projects where title like '[DEMO]%';
-- delete from public.contact_submissions where source = 'demo';
-- delete from public.project_inquiries where source = 'demo';
-- delete from public.notifications where message like '%Demo Lead%' or title like 'New task: [DEMO]%';
