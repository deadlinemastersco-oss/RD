-- =============================================================================
-- Deadline Masters · 0002_rls_policies.sql
-- Row Level Security for every table. Run AFTER 0001_schema.sql.
--
-- Principles
--  * RLS is enabled on EVERY table. No table is world-writable.
--  * Anonymous visitors may only INSERT leads/newsletter rows and READ
--    published marketing content. They can never read leads back.
--  * Roles live in public.profiles.role and are checked with SECURITY DEFINER
--    helpers (public.is_admin / public.is_staff). Client-supplied roles are
--    never trusted; users cannot change their own role (trigger in 0001).
-- =============================================================================

alter table public.profiles               enable row level security;
alter table public.contact_submissions    enable row level security;
alter table public.project_inquiries      enable row level security;
alter table public.inquiry_notes          enable row level security;
alter table public.newsletter_subscribers enable row level security;
alter table public.services               enable row level security;
alter table public.case_studies           enable row level security;
alter table public.testimonials           enable row level security;
alter table public.team_members           enable row level security;
alter table public.projects               enable row level security;
alter table public.project_tasks          enable row level security;
alter table public.notifications          enable row level security;
alter table public.site_settings          enable row level security;

-- Table privileges (RLS still applies on top of these).
grant usage on schema public to anon, authenticated;

revoke all on all tables in schema public from anon;
grant select on public.services, public.case_studies, public.testimonials,
                public.team_members, public.site_settings to anon;
grant insert on public.contact_submissions, public.project_inquiries,
                public.newsletter_subscribers to anon;

grant select, insert, update, delete on all tables in schema public to authenticated;

-- Helper to (re)create a policy idempotently.
-- Postgres has no CREATE POLICY IF NOT EXISTS, so we drop first.

-- -----------------------------------------------------------------------------
-- profiles
-- -----------------------------------------------------------------------------
drop policy if exists "profiles: read own" on public.profiles;
create policy "profiles: read own" on public.profiles
  for select to authenticated
  using (id = (select auth.uid()));

drop policy if exists "profiles: staff read teammates" on public.profiles;
create policy "profiles: staff read teammates" on public.profiles
  for select to authenticated
  using (public.is_staff());

drop policy if exists "profiles: update own" on public.profiles;
create policy "profiles: update own" on public.profiles
  for update to authenticated
  using (id = (select auth.uid()))
  with check (id = (select auth.uid()));

drop policy if exists "profiles: admin update any" on public.profiles;
create policy "profiles: admin update any" on public.profiles
  for update to authenticated
  using (public.is_admin())
  with check (public.is_admin());
-- No INSERT policy: profiles are created by the on_auth_user_created trigger.
-- No DELETE policy: profiles are removed when the auth user is deleted.

-- -----------------------------------------------------------------------------
-- contact_submissions
-- -----------------------------------------------------------------------------
drop policy if exists "contact: public insert" on public.contact_submissions;
create policy "contact: public insert" on public.contact_submissions
  for insert to anon, authenticated
  with check (status = 'new' and assigned_to is null);

drop policy if exists "contact: admin or assignee read" on public.contact_submissions;
create policy "contact: admin or assignee read" on public.contact_submissions
  for select to authenticated
  using (public.is_admin() or (public.is_staff() and assigned_to = (select auth.uid())));

drop policy if exists "contact: admin or assignee update" on public.contact_submissions;
create policy "contact: admin or assignee update" on public.contact_submissions
  for update to authenticated
  using (public.is_admin() or (public.is_staff() and assigned_to = (select auth.uid())))
  with check (public.is_admin() or (public.is_staff() and assigned_to = (select auth.uid())));

drop policy if exists "contact: admin delete" on public.contact_submissions;
create policy "contact: admin delete" on public.contact_submissions
  for delete to authenticated
  using (public.is_admin());

-- -----------------------------------------------------------------------------
-- project_inquiries
-- -----------------------------------------------------------------------------
drop policy if exists "inquiries: public insert" on public.project_inquiries;
create policy "inquiries: public insert" on public.project_inquiries
  for insert to anon, authenticated
  with check (status = 'new' and assigned_to is null);

drop policy if exists "inquiries: admin or assignee read" on public.project_inquiries;
create policy "inquiries: admin or assignee read" on public.project_inquiries
  for select to authenticated
  using (public.is_admin() or (public.is_staff() and assigned_to = (select auth.uid())));

drop policy if exists "inquiries: admin or assignee update" on public.project_inquiries;
create policy "inquiries: admin or assignee update" on public.project_inquiries
  for update to authenticated
  using (public.is_admin() or (public.is_staff() and assigned_to = (select auth.uid())))
  with check (public.is_admin() or (public.is_staff() and assigned_to = (select auth.uid())));

drop policy if exists "inquiries: admin delete" on public.project_inquiries;
create policy "inquiries: admin delete" on public.project_inquiries
  for delete to authenticated
  using (public.is_admin());

-- -----------------------------------------------------------------------------
-- inquiry_notes
-- -----------------------------------------------------------------------------
drop policy if exists "notes: read if lead accessible" on public.inquiry_notes;
create policy "notes: read if lead accessible" on public.inquiry_notes
  for select to authenticated
  using (public.can_access_lead(submission_type, submission_id));

drop policy if exists "notes: insert if lead accessible" on public.inquiry_notes;
create policy "notes: insert if lead accessible" on public.inquiry_notes
  for insert to authenticated
  with check (
    author_id = (select auth.uid())
    and public.can_access_lead(submission_type, submission_id)
  );

drop policy if exists "notes: author or admin delete" on public.inquiry_notes;
create policy "notes: author or admin delete" on public.inquiry_notes
  for delete to authenticated
  using (author_id = (select auth.uid()) or public.is_admin());

-- -----------------------------------------------------------------------------
-- newsletter_subscribers
-- -----------------------------------------------------------------------------
drop policy if exists "newsletter: public subscribe" on public.newsletter_subscribers;
create policy "newsletter: public subscribe" on public.newsletter_subscribers
  for insert to anon, authenticated
  with check (is_subscribed = true);

drop policy if exists "newsletter: admin read" on public.newsletter_subscribers;
create policy "newsletter: admin read" on public.newsletter_subscribers
  for select to authenticated
  using (public.is_admin());

drop policy if exists "newsletter: admin update" on public.newsletter_subscribers;
create policy "newsletter: admin update" on public.newsletter_subscribers
  for update to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "newsletter: admin delete" on public.newsletter_subscribers;
create policy "newsletter: admin delete" on public.newsletter_subscribers
  for delete to authenticated
  using (public.is_admin());

-- -----------------------------------------------------------------------------
-- Marketing content: services / case_studies / testimonials / team_members
-- Public read of published rows; admins manage everything.
-- -----------------------------------------------------------------------------
drop policy if exists "services: public read active" on public.services;
create policy "services: public read active" on public.services
  for select to anon, authenticated
  using (is_active or public.is_admin());

drop policy if exists "services: admin write" on public.services;
create policy "services: admin write" on public.services
  for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "case_studies: public read published" on public.case_studies;
create policy "case_studies: public read published" on public.case_studies
  for select to anon, authenticated
  using (is_published or public.is_admin());

drop policy if exists "case_studies: admin write" on public.case_studies;
create policy "case_studies: admin write" on public.case_studies
  for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "testimonials: public read published" on public.testimonials;
create policy "testimonials: public read published" on public.testimonials
  for select to anon, authenticated
  using (is_published or public.is_admin());

drop policy if exists "testimonials: admin write" on public.testimonials;
create policy "testimonials: admin write" on public.testimonials
  for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "team_members: public read published" on public.team_members;
create policy "team_members: public read published" on public.team_members
  for select to anon, authenticated
  using (is_published or public.is_admin());

drop policy if exists "team_members: admin write" on public.team_members;
create policy "team_members: admin write" on public.team_members
  for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- -----------------------------------------------------------------------------
-- projects
-- Admins: everything. Owners: read + update. Team members: read projects
-- where they own it or have at least one task assigned.
-- -----------------------------------------------------------------------------
drop policy if exists "projects: read" on public.projects;
create policy "projects: read" on public.projects
  for select to authenticated
  using (
    public.is_admin()
    or owner_id = (select auth.uid())
    or (public.is_staff() and public.has_task_in_project(id))
  );

drop policy if exists "projects: admin insert" on public.projects;
create policy "projects: admin insert" on public.projects
  for insert to authenticated
  with check (public.is_admin());

drop policy if exists "projects: admin or owner update" on public.projects;
create policy "projects: admin or owner update" on public.projects
  for update to authenticated
  using (public.is_admin() or (public.is_staff() and owner_id = (select auth.uid())))
  with check (public.is_admin() or (public.is_staff() and owner_id = (select auth.uid())));

drop policy if exists "projects: admin delete" on public.projects;
create policy "projects: admin delete" on public.projects
  for delete to authenticated
  using (public.is_admin());

-- -----------------------------------------------------------------------------
-- project_tasks
-- -----------------------------------------------------------------------------
drop policy if exists "tasks: read" on public.project_tasks;
create policy "tasks: read" on public.project_tasks
  for select to authenticated
  using (
    public.is_admin()
    or assigned_to = (select auth.uid())
    or (public.is_staff() and public.is_project_owner(project_id))
  );

drop policy if exists "tasks: admin or owner insert" on public.project_tasks;
create policy "tasks: admin or owner insert" on public.project_tasks
  for insert to authenticated
  with check (public.is_admin() or (public.is_staff() and public.is_project_owner(project_id)));

drop policy if exists "tasks: admin, owner or assignee update" on public.project_tasks;
create policy "tasks: admin, owner or assignee update" on public.project_tasks
  for update to authenticated
  using (
    public.is_admin()
    or (public.is_staff() and (public.is_project_owner(project_id) or assigned_to = (select auth.uid())))
  )
  with check (
    public.is_admin()
    or (public.is_staff() and (public.is_project_owner(project_id) or assigned_to = (select auth.uid())))
  );

drop policy if exists "tasks: admin or owner delete" on public.project_tasks;
create policy "tasks: admin or owner delete" on public.project_tasks
  for delete to authenticated
  using (public.is_admin() or (public.is_staff() and public.is_project_owner(project_id)));

-- -----------------------------------------------------------------------------
-- notifications  (each user sees only their own)
-- -----------------------------------------------------------------------------
drop policy if exists "notifications: read own" on public.notifications;
create policy "notifications: read own" on public.notifications
  for select to authenticated
  using (user_id = (select auth.uid()));

drop policy if exists "notifications: update own" on public.notifications;
create policy "notifications: update own" on public.notifications
  for update to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

drop policy if exists "notifications: delete own" on public.notifications;
create policy "notifications: delete own" on public.notifications
  for delete to authenticated
  using (user_id = (select auth.uid()));

drop policy if exists "notifications: admin insert" on public.notifications;
create policy "notifications: admin insert" on public.notifications
  for insert to authenticated
  with check (public.is_admin());

-- -----------------------------------------------------------------------------
-- site_settings  (keys prefixed "public." are readable by everyone)
-- -----------------------------------------------------------------------------
drop policy if exists "settings: public keys readable" on public.site_settings;
create policy "settings: public keys readable" on public.site_settings
  for select to anon, authenticated
  using (key like 'public.%' or public.is_admin());

drop policy if exists "settings: admin write" on public.site_settings;
create policy "settings: admin write" on public.site_settings
  for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
