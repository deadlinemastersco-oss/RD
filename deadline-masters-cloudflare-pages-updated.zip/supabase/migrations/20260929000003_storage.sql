-- =============================================================================
-- Deadline Masters · 0003_storage.sql   (OPTIONAL)
-- Two Storage buckets:
--   public-assets : case-study covers, team photos, service imagery.
--                   Anyone can read; only admins can upload/replace/delete.
--   avatars       : dashboard user avatars. Anyone can read; each signed-in user
--                   may write only inside a folder named after their user id:
--                   avatars/<auth.uid()>/avatar.png
-- =============================================================================

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('public-assets', 'public-assets', true, 5242880,
    array['image/png', 'image/jpeg', 'image/webp', 'image/avif', 'image/svg+xml']),
  ('avatars', 'avatars', true, 2097152,
    array['image/png', 'image/jpeg', 'image/webp'])
on conflict (id) do nothing;

-- public-assets ---------------------------------------------------------------
drop policy if exists "public-assets: read" on storage.objects;
create policy "public-assets: read" on storage.objects
  for select to anon, authenticated
  using (bucket_id = 'public-assets');

drop policy if exists "public-assets: admin insert" on storage.objects;
create policy "public-assets: admin insert" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'public-assets' and public.is_admin());

drop policy if exists "public-assets: admin update" on storage.objects;
create policy "public-assets: admin update" on storage.objects
  for update to authenticated
  using (bucket_id = 'public-assets' and public.is_admin())
  with check (bucket_id = 'public-assets' and public.is_admin());

drop policy if exists "public-assets: admin delete" on storage.objects;
create policy "public-assets: admin delete" on storage.objects
  for delete to authenticated
  using (bucket_id = 'public-assets' and public.is_admin());

-- avatars ---------------------------------------------------------------------
drop policy if exists "avatars: read" on storage.objects;
create policy "avatars: read" on storage.objects
  for select to anon, authenticated
  using (bucket_id = 'avatars');

drop policy if exists "avatars: own folder insert" on storage.objects;
create policy "avatars: own folder insert" on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'avatars'
    and (storage.foldername(name))[1] = (select auth.uid())::text
  );

drop policy if exists "avatars: own folder update" on storage.objects;
create policy "avatars: own folder update" on storage.objects
  for update to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = (select auth.uid())::text)
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = (select auth.uid())::text);

drop policy if exists "avatars: own folder delete" on storage.objects;
create policy "avatars: own folder delete" on storage.objects
  for delete to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = (select auth.uid())::text);
