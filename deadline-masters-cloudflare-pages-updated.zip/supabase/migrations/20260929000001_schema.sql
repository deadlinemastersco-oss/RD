-- =============================================================================
-- Deadline Masters · 0001_schema.sql
-- Tables, enums, constraints, indexes, helper functions and triggers.
-- Run this file FIRST in the Supabase SQL editor (or via `supabase db push`).
-- Safe to re-run: every object uses IF NOT EXISTS / OR REPLACE where possible.
-- =============================================================================

create extension if not exists pgcrypto with schema extensions;

-- -----------------------------------------------------------------------------
-- Enums
-- -----------------------------------------------------------------------------
do $$ begin
  create type public.user_role as enum ('admin', 'team_member', 'viewer');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.lead_status as enum (
    'new', 'contacted', 'qualified', 'proposal_sent', 'won', 'lost', 'archived'
  );
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.project_status as enum (
    'planning', 'active', 'on_hold', 'review', 'completed', 'cancelled'
  );
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.task_status as enum ('todo', 'in_progress', 'blocked', 'review', 'done');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.task_priority as enum ('low', 'medium', 'high', 'urgent');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.notification_type as enum (
    'info', 'success', 'warning', 'inquiry', 'task', 'system'
  );
exception when duplicate_object then null; end $$;

-- -----------------------------------------------------------------------------
-- Generic updated_at trigger
-- -----------------------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- -----------------------------------------------------------------------------
-- 1. profiles  (1:1 with auth.users)
-- -----------------------------------------------------------------------------
create table if not exists public.profiles (
  id          uuid primary key references auth.users (id) on delete cascade,
  full_name   text check (char_length(full_name) <= 120),
  email       text check (char_length(email) <= 254),
  avatar_url  text check (char_length(avatar_url) <= 1000),
  role        public.user_role not null default 'viewer',
  bio         text check (char_length(bio) <= 2000),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists profiles_role_idx on public.profiles (role);

-- -----------------------------------------------------------------------------
-- Role helpers (SECURITY DEFINER so they can be used inside RLS policies
-- without recursive policy evaluation on profiles).
-- -----------------------------------------------------------------------------
create or replace function public.current_user_role()
returns public.user_role
language sql
stable
security definer
set search_path = ''
as $$
  select role from public.profiles where id = (select auth.uid());
$$;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.profiles
    where id = (select auth.uid()) and role = 'admin'
  );
$$;

create or replace function public.is_staff()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.profiles
    where id = (select auth.uid()) and role in ('admin', 'team_member')
  );
$$;

-- Create a profile automatically for every new auth user.
-- New users are ALWAYS 'viewer'. Promotion happens only by an admin or via SQL.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, email, full_name, avatar_url, role)
  values (
    new.id,
    new.email,
    left(coalesce(new.raw_user_meta_data ->> 'full_name', new.raw_user_meta_data ->> 'name'), 120),
    left(new.raw_user_meta_data ->> 'avatar_url', 1000),
    'viewer'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Keep profiles.email in sync when a user changes their email.
create or replace function public.handle_user_email_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.email is distinct from old.email then
    update public.profiles set email = new.email where id = new.id;
  end if;
  return new;
end;
$$;

drop trigger if exists on_auth_user_email_changed on auth.users;
create trigger on_auth_user_email_changed
  after update of email on auth.users
  for each row execute function public.handle_user_email_change();

-- Users may edit their own profile, but only admins (or the SQL editor /
-- service role, where auth.uid() is null) may change a role.
create or replace function public.protect_profile_role()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.role is distinct from old.role
     and (select auth.uid()) is not null
     and not public.is_admin() then
    raise exception 'Only admins can change roles' using errcode = '42501';
  end if;
  -- An admin cannot demote themselves (prevents locking the workspace out).
  if new.role is distinct from old.role
     and old.id = (select auth.uid())
     and old.role = 'admin' then
    raise exception 'Admins cannot change their own role' using errcode = '42501';
  end if;
  -- email is managed by auth.users
  if new.email is distinct from old.email and (select auth.uid()) is not null then
    new.email = old.email;
  end if;
  return new;
end;
$$;

drop trigger if exists profiles_protect_role on public.profiles;
create trigger profiles_protect_role
  before update on public.profiles
  for each row execute function public.protect_profile_role();

drop trigger if exists profiles_updated_at on public.profiles;
create trigger profiles_updated_at
  before update on public.profiles
  for each row execute function public.set_updated_at();

-- -----------------------------------------------------------------------------
-- 2. contact_submissions
-- -----------------------------------------------------------------------------
create table if not exists public.contact_submissions (
  id                uuid primary key default gen_random_uuid(),
  full_name         text not null check (char_length(full_name) between 2 and 120),
  email             text not null check (
                      char_length(email) <= 254
                      and email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'
                    ),
  phone             text check (char_length(phone) <= 40),
  company           text check (char_length(company) <= 160),
  service_interest  text check (char_length(service_interest) <= 120),
  budget_range      text check (char_length(budget_range) <= 60),
  deadline          text check (char_length(deadline) <= 60),
  message           text not null check (char_length(message) between 10 and 5000),
  source            text not null default 'contact_form' check (char_length(source) <= 60),
  status            public.lead_status not null default 'new',
  assigned_to       uuid references public.profiles (id) on delete set null,
  consent_at        timestamptz,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);
create index if not exists contact_submissions_status_idx on public.contact_submissions (status);
create index if not exists contact_submissions_created_idx on public.contact_submissions (created_at desc);
create index if not exists contact_submissions_assigned_idx on public.contact_submissions (assigned_to);
create index if not exists contact_submissions_email_idx on public.contact_submissions (lower(email));

drop trigger if exists contact_submissions_updated_at on public.contact_submissions;
create trigger contact_submissions_updated_at
  before update on public.contact_submissions
  for each row execute function public.set_updated_at();

-- -----------------------------------------------------------------------------
-- 3. project_inquiries  (diagnostic flow + other structured inquiries)
-- -----------------------------------------------------------------------------
create table if not exists public.project_inquiries (
  id                   uuid primary key default gen_random_uuid(),
  name                 text not null check (char_length(name) between 2 and 120),
  email                text not null check (
                         char_length(email) <= 254
                         and email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'
                       ),
  phone                text check (char_length(phone) <= 40),
  company              text check (char_length(company) <= 160),
  project_type         text check (char_length(project_type) <= 120),
  project_description  text check (char_length(project_description) <= 5000),
  estimated_budget     text check (char_length(estimated_budget) <= 60),
  desired_timeline     text check (char_length(desired_timeline) <= 60),
  source               text not null default 'diagnostic' check (char_length(source) <= 60),
  diagnostic           jsonb not null default '{}'::jsonb check (pg_column_size(diagnostic) <= 8192),
  recommended_service  text check (char_length(recommended_service) <= 120),
  status               public.lead_status not null default 'new',
  assigned_to          uuid references public.profiles (id) on delete set null,
  consent_at           timestamptz,
  created_at           timestamptz not null default now(),
  updated_at           timestamptz not null default now()
);
create index if not exists project_inquiries_status_idx on public.project_inquiries (status);
create index if not exists project_inquiries_created_idx on public.project_inquiries (created_at desc);
create index if not exists project_inquiries_assigned_idx on public.project_inquiries (assigned_to);

drop trigger if exists project_inquiries_updated_at on public.project_inquiries;
create trigger project_inquiries_updated_at
  before update on public.project_inquiries
  for each row execute function public.set_updated_at();

-- Team members assigned to a lead may change its status only.
create or replace function public.protect_lead_fields()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if (select auth.uid()) is not null and not public.is_admin() then
    if (to_jsonb(new) - 'status' - 'updated_at') is distinct from (to_jsonb(old) - 'status' - 'updated_at') then
      raise exception 'Only admins can edit lead details' using errcode = '42501';
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists contact_submissions_protect on public.contact_submissions;
create trigger contact_submissions_protect
  before update on public.contact_submissions
  for each row execute function public.protect_lead_fields();

drop trigger if exists project_inquiries_protect on public.project_inquiries;
create trigger project_inquiries_protect
  before update on public.project_inquiries
  for each row execute function public.protect_lead_fields();

-- -----------------------------------------------------------------------------
-- Internal notes on leads (the "notes area" in the dashboard)
-- -----------------------------------------------------------------------------
create table if not exists public.inquiry_notes (
  id               uuid primary key default gen_random_uuid(),
  submission_type  text not null check (submission_type in ('contact', 'project')),
  submission_id    uuid not null,
  author_id        uuid references public.profiles (id) on delete set null,
  body             text not null check (char_length(body) between 1 and 4000),
  created_at       timestamptz not null default now()
);
create index if not exists inquiry_notes_submission_idx
  on public.inquiry_notes (submission_type, submission_id, created_at desc);

create or replace function public.can_access_lead(p_type text, p_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select public.is_admin() or (
    public.is_staff() and (
      (p_type = 'contact' and exists (
        select 1 from public.contact_submissions
        where id = p_id and assigned_to = (select auth.uid())
      ))
      or
      (p_type = 'project' and exists (
        select 1 from public.project_inquiries
        where id = p_id and assigned_to = (select auth.uid())
      ))
    )
  );
$$;

-- -----------------------------------------------------------------------------
-- 4. newsletter_subscribers
-- -----------------------------------------------------------------------------
create table if not exists public.newsletter_subscribers (
  id             uuid primary key default gen_random_uuid(),
  email          text not null check (
                   char_length(email) <= 254
                   and email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'
                 ),
  source         text not null default 'website' check (char_length(source) <= 60),
  is_subscribed  boolean not null default true,
  created_at     timestamptz not null default now()
);
-- Prevent duplicate subscriptions regardless of letter case.
create unique index if not exists newsletter_subscribers_email_key
  on public.newsletter_subscribers (lower(email));

-- -----------------------------------------------------------------------------
-- 5. services
-- -----------------------------------------------------------------------------
create table if not exists public.services (
  id                 uuid primary key default gen_random_uuid(),
  slug               text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  title              text not null check (char_length(title) <= 160),
  short_description  text check (char_length(short_description) <= 400),
  full_description   text check (char_length(full_description) <= 8000),
  icon               text check (char_length(icon) <= 60),
  starting_price     numeric(12, 2) check (starting_price >= 0),   -- null = custom quote
  delivery_time      text check (char_length(delivery_time) <= 80),
  features           text[] not null default '{}',
  details            jsonb not null default '{}'::jsonb,           -- problem, idealClient, process, deliverables
  is_active          boolean not null default true,
  sort_order         integer not null default 0,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);
create index if not exists services_active_sort_idx on public.services (is_active, sort_order);

drop trigger if exists services_updated_at on public.services;
create trigger services_updated_at
  before update on public.services
  for each row execute function public.set_updated_at();

-- -----------------------------------------------------------------------------
-- 6. case_studies
-- -----------------------------------------------------------------------------
create table if not exists public.case_studies (
  id             uuid primary key default gen_random_uuid(),
  slug           text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  title          text not null check (char_length(title) <= 200),
  client_name    text check (char_length(client_name) <= 160),
  industry       text check (char_length(industry) <= 120),
  summary        text check (char_length(summary) <= 1000),
  challenge      text check (char_length(challenge) <= 8000),
  approach       text check (char_length(approach) <= 8000),
  solution       text check (char_length(solution) <= 8000),
  outcome        text check (char_length(outcome) <= 8000),
  cover_image    text check (char_length(cover_image) <= 1000),
  gallery        text[] not null default '{}',
  technologies   text[] not null default '{}',
  service_slugs  text[] not null default '{}',
  is_published   boolean not null default false,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index if not exists case_studies_published_idx on public.case_studies (is_published, created_at desc);

drop trigger if exists case_studies_updated_at on public.case_studies;
create trigger case_studies_updated_at
  before update on public.case_studies
  for each row execute function public.set_updated_at();

-- -----------------------------------------------------------------------------
-- 7. testimonials  (publish only real, permissioned quotes)
-- -----------------------------------------------------------------------------
create table if not exists public.testimonials (
  id            uuid primary key default gen_random_uuid(),
  client_name   text not null check (char_length(client_name) <= 120),
  client_role   text check (char_length(client_role) <= 120),
  company       text check (char_length(company) <= 160),
  quote         text not null check (char_length(quote) between 10 and 1200),
  avatar_url    text check (char_length(avatar_url) <= 1000),
  rating        smallint check (rating between 1 and 5),
  is_published  boolean not null default false,
  created_at    timestamptz not null default now()
);
create index if not exists testimonials_published_idx on public.testimonials (is_published, created_at desc);

-- -----------------------------------------------------------------------------
-- 8. team_members  (public-facing team profiles, independent of auth users)
-- -----------------------------------------------------------------------------
create table if not exists public.team_members (
  id            uuid primary key default gen_random_uuid(),
  name          text not null check (char_length(name) <= 120),
  role          text not null check (char_length(role) <= 160),
  short_bio     text check (char_length(short_bio) <= 400),
  full_bio      text check (char_length(full_bio) <= 4000),
  avatar_url    text check (char_length(avatar_url) <= 1000),
  skills        text[] not null default '{}',
  social_links  jsonb not null default '{}'::jsonb,
  sort_order    integer not null default 0,
  is_published  boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists team_members_published_sort_idx on public.team_members (is_published, sort_order);

drop trigger if exists team_members_updated_at on public.team_members;
create trigger team_members_updated_at
  before update on public.team_members
  for each row execute function public.set_updated_at();

-- -----------------------------------------------------------------------------
-- 9. projects
-- -----------------------------------------------------------------------------
create table if not exists public.projects (
  id           uuid primary key default gen_random_uuid(),
  title        text not null check (char_length(title) between 2 and 200),
  client_name  text check (char_length(client_name) <= 160),
  description  text check (char_length(description) <= 8000),
  status       public.project_status not null default 'planning',
  progress     smallint not null default 0 check (progress between 0 and 100),
  start_date   date,
  due_date     date,
  owner_id     uuid references public.profiles (id) on delete set null,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  constraint projects_dates_chk check (due_date is null or start_date is null or due_date >= start_date)
);
create index if not exists projects_status_idx on public.projects (status);
create index if not exists projects_owner_idx on public.projects (owner_id);
create index if not exists projects_due_idx on public.projects (due_date);

drop trigger if exists projects_updated_at on public.projects;
create trigger projects_updated_at
  before update on public.projects
  for each row execute function public.set_updated_at();

-- -----------------------------------------------------------------------------
-- 10. project_tasks
-- -----------------------------------------------------------------------------
create table if not exists public.project_tasks (
  id           uuid primary key default gen_random_uuid(),
  project_id   uuid not null references public.projects (id) on delete cascade,
  title        text not null check (char_length(title) between 2 and 200),
  description  text check (char_length(description) <= 4000),
  status       public.task_status not null default 'todo',
  priority     public.task_priority not null default 'medium',
  assigned_to  uuid references public.profiles (id) on delete set null,
  due_date     date,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index if not exists project_tasks_project_idx on public.project_tasks (project_id);
create index if not exists project_tasks_assigned_idx on public.project_tasks (assigned_to, status);
create index if not exists project_tasks_due_idx on public.project_tasks (due_date);

drop trigger if exists project_tasks_updated_at on public.project_tasks;
create trigger project_tasks_updated_at
  before update on public.project_tasks
  for each row execute function public.set_updated_at();

-- Helper used by policies: is the current user the owner of this project?
create or replace function public.is_project_owner(p_project_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.projects
    where id = p_project_id and owner_id = (select auth.uid())
  );
$$;

-- Helper: does the current user have any task in this project?
create or replace function public.has_task_in_project(p_project_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.project_tasks
    where project_id = p_project_id and assigned_to = (select auth.uid())
  );
$$;

-- Assignees who are not admins / project owners may only change the status.
create or replace function public.protect_task_fields()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if (select auth.uid()) is not null
     and not public.is_admin()
     and not public.is_project_owner(old.project_id) then
    if (to_jsonb(new) - 'status' - 'updated_at') is distinct from (to_jsonb(old) - 'status' - 'updated_at') then
      raise exception 'Only the project owner or an admin can edit task details' using errcode = '42501';
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists project_tasks_protect on public.project_tasks;
create trigger project_tasks_protect
  before update on public.project_tasks
  for each row execute function public.protect_task_fields();

-- -----------------------------------------------------------------------------
-- 11. notifications
-- -----------------------------------------------------------------------------
create table if not exists public.notifications (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references public.profiles (id) on delete cascade,
  title       text not null check (char_length(title) <= 200),
  message     text check (char_length(message) <= 1000),
  type        public.notification_type not null default 'info',
  link        text check (char_length(link) <= 500),
  is_read     boolean not null default false,
  created_at  timestamptz not null default now()
);
create index if not exists notifications_user_idx on public.notifications (user_id, is_read, created_at desc);

-- -----------------------------------------------------------------------------
-- 12. site_settings  (keys starting with "public." are world-readable)
-- -----------------------------------------------------------------------------
create table if not exists public.site_settings (
  id          uuid primary key default gen_random_uuid(),
  key         text not null unique check (key ~ '^[a-z0-9_.-]{2,80}$'),
  value       jsonb not null default 'null'::jsonb,
  updated_at  timestamptz not null default now()
);

drop trigger if exists site_settings_updated_at on public.site_settings;
create trigger site_settings_updated_at
  before update on public.site_settings
  for each row execute function public.set_updated_at();

-- -----------------------------------------------------------------------------
-- Notification triggers
-- -----------------------------------------------------------------------------
create or replace function public.notify_admins_new_lead()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_name  text;
  v_kind  text;
begin
  if tg_table_name = 'contact_submissions' then
    v_name := new.full_name;
    v_kind := 'contact';
  else
    v_name := new.name;
    v_kind := 'project';
  end if;

  insert into public.notifications (user_id, title, message, type, link)
  select p.id,
         'New ' || case when v_kind = 'contact' then 'contact request' else 'project inquiry' end,
         left(coalesce(v_name, 'Someone') || ' just reached out.', 1000),
         'inquiry',
         '/dashboard/inquiries?type=' || v_kind || '&id=' || new.id
  from public.profiles p
  where p.role = 'admin';
  return new;
end;
$$;

drop trigger if exists contact_submissions_notify on public.contact_submissions;
create trigger contact_submissions_notify
  after insert on public.contact_submissions
  for each row execute function public.notify_admins_new_lead();

drop trigger if exists project_inquiries_notify on public.project_inquiries;
create trigger project_inquiries_notify
  after insert on public.project_inquiries
  for each row execute function public.notify_admins_new_lead();

create or replace function public.notify_lead_assignee()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_kind text := case when tg_table_name = 'contact_submissions' then 'contact' else 'project' end;
begin
  if new.assigned_to is not null
     and new.assigned_to is distinct from old.assigned_to
     and new.assigned_to is distinct from (select auth.uid()) then
    insert into public.notifications (user_id, title, message, type, link)
    values (
      new.assigned_to,
      'A lead was assigned to you',
      'Open the inquiry pipeline to review it.',
      'inquiry',
      '/dashboard/inquiries?type=' || v_kind || '&id=' || new.id
    );
  end if;
  return new;
end;
$$;

drop trigger if exists contact_submissions_assign_notify on public.contact_submissions;
create trigger contact_submissions_assign_notify
  after update of assigned_to on public.contact_submissions
  for each row execute function public.notify_lead_assignee();

drop trigger if exists project_inquiries_assign_notify on public.project_inquiries;
create trigger project_inquiries_assign_notify
  after update of assigned_to on public.project_inquiries
  for each row execute function public.notify_lead_assignee();

create or replace function public.notify_task_assignee()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.assigned_to is not null
     and (tg_op = 'INSERT' or new.assigned_to is distinct from old.assigned_to)
     and new.assigned_to is distinct from (select auth.uid()) then
    insert into public.notifications (user_id, title, message, type, link)
    values (
      new.assigned_to,
      'New task: ' || left(new.title, 160),
      'You have been assigned a task.',
      'task',
      '/dashboard/projects/' || new.project_id
    );
  end if;
  return new;
end;
$$;

drop trigger if exists project_tasks_assign_notify on public.project_tasks;
create trigger project_tasks_assign_notify
  after insert or update of assigned_to on public.project_tasks
  for each row execute function public.notify_task_assignee();

-- Lock down helper functions: callable by signed-in users only (used inside RLS).
revoke execute on function public.current_user_role() from public, anon;
revoke execute on function public.is_admin() from public;
revoke execute on function public.is_staff() from public;
grant execute on function public.current_user_role() to authenticated;
grant execute on function public.is_admin() to anon, authenticated;
grant execute on function public.is_staff() to anon, authenticated;
grant execute on function public.can_access_lead(text, uuid) to authenticated;
grant execute on function public.is_project_owner(uuid) to authenticated;
grant execute on function public.has_task_in_project(uuid) to authenticated;
