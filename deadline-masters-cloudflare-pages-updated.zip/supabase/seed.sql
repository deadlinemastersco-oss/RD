-- =============================================================================
-- Deadline Masters · seed.sql
-- PRODUCTION-SAFE content seed. Contains only your own marketing content —
-- no fake clients, testimonials, projects or results.
--
--   * services      → the seven service lines (mirrors lib/constants/services.ts)
--   * team_members  → four PLACEHOLDER seats. Replace names/bios before launch.
--   * site_settings → a couple of harmless defaults
--
-- Case studies and testimonials are intentionally NOT seeded. Publish real,
-- permissioned ones from the Supabase Table editor.
--
-- Safe to re-run: uses ON CONFLICT on unique keys.
-- For DEMO dashboard data (fake projects/tasks), see seed-demo.sql — never run
-- that against production.
-- =============================================================================

insert into public.services
  (slug, title, short_description, full_description, icon, starting_price, delivery_time, features, details, is_active, sort_order)
values
(
  'websites-and-web-applications',
  'Websites & web applications',
  'Fast, accessible marketing sites and web apps that explain what you do and turn visitors into conversations.',
  'We plan, design and engineer websites and web applications on a modern Next.js stack — structured for search, easy for your team to update, and built to load quickly on real phones and real networks.',
  'globe', 60000, '3–6 weeks',
  array['Information architecture and conversion-focused page structure','Custom visual design aligned to your brand','Next.js build with a content workflow your team can use','Technical SEO, analytics and lead-capture forms','Performance, accessibility and security baseline'],
  '{"category":"build"}'::jsonb, true, 10
),
(
  'saas-dashboards-and-mvp-development',
  'SaaS dashboards & MVP development',
  'From validated idea to a working product: authentication, data model, dashboards and the first release your users can log into.',
  'We scope a focused first version, design the core workflows and build a production-grade MVP with authentication, roles, a clean database design and the dashboards your users or internal team need.',
  'layout-dashboard', 400000, '6–12 weeks',
  array['Scope workshop and a written MVP definition','Product design for core user journeys','Next.js + Supabase application with auth and role-based access','Database schema with Row Level Security','Admin dashboard, reporting and deployment pipeline'],
  '{"category":"build"}'::jsonb, true, 20
),
(
  'ui-ux-and-product-design',
  'UI/UX & product design',
  'Research-backed interface design that makes complex products feel obvious — delivered as a usable design system, not just screens.',
  'We untangle confusing flows, design new products and build design systems that keep teams consistent. Every design decision is tied to a user task and a business goal.',
  'pen-tool', 50000, '2–6 weeks',
  array['UX audit with prioritised findings','User flows and wireframes','High-fidelity UI for web and mobile','Design system with reusable components','Developer-ready specifications'],
  '{"category":"design"}'::jsonb, true, 30
),
(
  'ai-workflow-and-business-automation',
  'AI workflow & business automation',
  'Remove repetitive work: connect your tools, automate hand-offs and apply AI where it saves real hours — with human review built in.',
  'We map how work actually moves through your business, then automate the repetitive steps using integrations, scripts and carefully scoped AI assistance, with logging and human checkpoints.',
  'workflow', 40000, '2–5 weeks',
  array['Process mapping and automation opportunity list','Integrations between your existing tools','AI-assisted drafting, classification or extraction steps','Error handling, logging and human-in-the-loop review','Runbooks your team can maintain'],
  '{"category":"operations"}'::jsonb, true, 40
),
(
  'seo-content-and-digital-growth',
  'SEO, content & digital growth',
  'Technical SEO, content systems and social distribution designed to compound — measured against inquiries, not vanity metrics.',
  'We fix the technical foundations, build a content plan around what your buyers search for, and set up a repeatable production system — including AI-assisted drafting with editorial review.',
  'trending-up', 35000, 'Ongoing · monthly',
  array['Technical SEO audit and fixes','Keyword and topic strategy mapped to buyer intent','Editorial calendar and content production workflow','Social distribution system','Monthly reporting tied to leads'],
  '{"category":"growth"}'::jsonb, true, 50
),
(
  'lead-generation-systems',
  'Lead-generation systems',
  'A connected pipeline — landing pages, offers, outreach and CRM — so inquiries are captured, followed up and never lost in an inbox.',
  'We design the full path from first touch to booked call: positioning, landing pages, outbound sequences, qualification and a CRM setup that shows where every lead stands.',
  'magnet', 75000, '3–6 weeks',
  array['Offer and positioning refinement','Conversion-focused landing pages','Outbound and follow-up sequences','CRM pipeline, stages and automations','Weekly pipeline reporting'],
  '{"category":"growth"}'::jsonb, true, 60
),
(
  'operations-and-compliance-coordination',
  'Operations & compliance coordination',
  'Documentation, process design and compliance coordination — organised by us, with licensed professionals engaged wherever the law requires.',
  'We bring order to the operational side of growth: SOPs, vendor and contract trackers, finance workflows, and coordination of statutory and compliance tasks with qualified chartered accountants, company secretaries and lawyers.',
  'shield-check', null, '2–4 weeks, then optional retainer',
  array['Standard operating procedures and checklists','Compliance and renewals calendar','Document templates and organised records','Finance workflow setup (invoicing, approvals, reporting)','Coordination with your licensed professionals'],
  '{"category":"operations","needsProfessionalDisclaimer":true}'::jsonb, true, 70
)
on conflict (slug) do update set
  title = excluded.title,
  short_description = excluded.short_description,
  full_description = excluded.full_description,
  icon = excluded.icon,
  starting_price = excluded.starting_price,
  delivery_time = excluded.delivery_time,
  features = excluded.features,
  details = public.services.details || excluded.details,
  sort_order = excluded.sort_order;

-- Placeholder team seats. `name` is intentionally a role title — replace with real names.
-- Only inserted when the table is empty so re-running never overwrites your edits.
insert into public.team_members (name, role, short_bio, full_bio, skills, sort_order, is_published)
select * from (values
  ('Product Design Lead', 'UI/UX & Product Design',
   'Turns complex requirements into clear interfaces, flows and design systems that engineering can build without guesswork.',
   'Leads research, information architecture, interface design and design systems.',
   array['UX research','Interface design','Design systems','Prototyping','Accessibility'], 10, true),
  ('Engineering Lead', 'Full-stack & SaaS Development',
   'Builds the websites, dashboards and MVPs — Next.js, React, TypeScript and Supabase, engineered for production from day one.',
   'Owns architecture, data modelling, security and delivery.',
   array['Next.js','React','TypeScript','Supabase / PostgreSQL','API integrations'], 20, true),
  ('Digital Strategy Lead', 'Strategy, Content & Automation',
   'Designs the systems that bring attention and remove busywork — SEO, content operations, social and AI-assisted workflows.',
   'Connects positioning, search, content and automation.',
   array['SEO','Content systems','Social media','AI workflows','Automation'], 30, true),
  ('Business Operations Lead', 'Sales, Operations & Compliance Coordination',
   'Keeps pipelines, operations, finance workflows and compliance coordination organised — working with licensed professionals where required.',
   'Owns lead generation, client operations, finance processes and compliance coordination.',
   array['Lead generation','Sales operations','Finance workflows','Compliance coordination','Documentation'], 40, true)
) as t(name, role, short_bio, full_bio, skills, sort_order, is_published)
where not exists (select 1 from public.team_members);

insert into public.site_settings (key, value) values
  ('public.announcement', 'null'::jsonb),
  ('leads.default_response_hours', '24'::jsonb)
on conflict (key) do nothing;
