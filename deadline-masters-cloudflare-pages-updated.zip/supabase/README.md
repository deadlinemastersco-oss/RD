# Supabase — database setup

This folder contains everything the database needs. Nothing here contains secrets.

```
supabase/
├── migrations/
│   ├── 20260929000001_schema.sql        tables, enums, constraints, indexes, helper functions, triggers
│   ├── 20260929000002_rls_policies.sql  Row Level Security for every table
│   └── 20260929000003_storage.sql       (optional) storage buckets + policies
├── seed.sql         production-safe content: 7 services, 4 placeholder team seats, 2 settings
└── seed-demo.sql    DEMO projects/tasks/leads for development only — never run in production
```

## Option A — Supabase SQL editor (no CLI needed)

1. Open your project at <https://supabase.com/dashboard> → **SQL Editor** → **New query**.
2. Paste the contents of `migrations/20260929000001_schema.sql` → **Run**.
3. New query → paste `migrations/20260929000002_rls_policies.sql` → **Run**.
4. (Optional, for image uploads) New query → paste `migrations/20260929000003_storage.sql` → **Run**.
5. New query → paste `seed.sql` → **Run**.

All files are idempotent: running them again is safe.

## Option B — Supabase CLI

```bash
npx supabase login
npx supabase link --project-ref YOUR-PROJECT-REF
npx supabase db push            # applies everything in supabase/migrations
npx supabase db execute --file supabase/seed.sql   # or paste seed.sql in the SQL editor
```

(Older CLI versions: use `psql "$DATABASE_URL" -f supabase/seed.sql` with the connection string from
Project Settings → Database.)

## Create the first admin

New accounts always start as `viewer` — the database ignores any role a browser sends. Promote your
first admin from the SQL editor (the SQL editor runs with owner privileges, so this is allowed):

```sql
-- 1. Sign up at /auth/sign-up (or invite yourself in Authentication → Users) and confirm the email.
-- 2. Then run:
update public.profiles set role = 'admin' where email = 'you@yourcompany.com';

-- Check:
select email, role from public.profiles order by created_at;
```

After that, admins manage everyone else from **Dashboard → Team** (role dropdown). Safeguards:

- a trigger blocks non-admins from changing any role (including their own);
- admins cannot change their own role (prevents accidentally locking the workspace);
- roles are read from the database on every request — never from the client.

## Roles

| Role          | Can do                                                                                        |
| ------------- | --------------------------------------------------------------------------------------------- |
| `admin`       | Everything: all leads, projects, tasks, team roles, content tables, site settings, newsletter |
| `team_member` | Leads assigned to them (status + notes), projects they own or have tasks in, their tasks      |
| `viewer`      | Sign in and edit their own profile only                                                       |
| anonymous     | Submit contact / diagnostic / newsletter; read active services and published content          |

## What the policies guarantee (tested)

- Visitors can **insert** leads and newsletter sign-ups but can never read them back.
- Inserted leads are forced to `status = 'new'` and unassigned.
- Duplicate newsletter emails are rejected by a case-insensitive unique index.
- Only active services and published case studies / testimonials / team members are public.
- Team members may change only the **status** of leads and tasks assigned to them; other edits are
  blocked by triggers.
- Everyone sees only their own notifications.
- Storage: anyone can read `public-assets` and `avatars`; only admins write `public-assets`; users write
  only inside `avatars/<their-user-id>/`.

## Automatic notifications

Database triggers create dashboard notifications when:

- a contact form or diagnostic is submitted → every admin;
- a lead is assigned → the assignee;
- a task is assigned → the assignee.

## Regenerating TypeScript types

`lib/types/database.ts` is hand-written to match these migrations. After changing the schema:

```bash
npx supabase gen types typescript --project-id YOUR-PROJECT-REF --schema public > lib/types/database.ts
```

## Demo data

`seed-demo.sql` inserts rows prefixed `[DEMO]` / `@example.com` for exploring the dashboard in a
**development** project. It refuses to run until an admin exists, and includes a cleanup block at the
bottom. Never run it against production.
